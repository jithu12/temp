#!/usr/bin/env python3
"""
Standalone entrypoint for Account Lifecycle Event Bus Consumer.

This script runs the lifecycle consumer as a standalone process,
separate from the main Celery CP worker. It should be deployed
in its own Kubernetes pod with dedicated resources.

Usage:
    python -m dataviz_async.lifecycle_consumer_main
"""

import logging
import os
import sys

from sg_cacert_file import load_sg_certs

# Configure logging before importing app components
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)

logger = logging.getLogger(__name__)

# Load SG certificates.
load_sg_certs()

# Import app components (moved to module level for testability).
from dataviz_async import core  # noqa: E402
from dataviz_async.app import app, _validate_eventbus_credentials  # noqa: E402
from dataviz_async.app import (  # noqa: E402
    _get_eventbus_regions,
    _create_lifecycle_consumers,
)
from event_bus_client import Consumer, Queue, Client  # noqa: E402


def main() -> None:
    """
    Main entrypoint for standalone lifecycle consumer.

    This initializes the Celery app context and runs the consumer
    directly (not as a Celery task), so it doesn't tie up worker resources.
    """
    logger.info("=== Starting Standalone Account Lifecycle Consumer ===")

    consumers = []
    started_consumers = []

    try:
        # Initialize core services
        core.init_app(app)
        logger.info("Core services initialized")

        # Get lifecycle service from core
        lifecycle_service = core.get_core(app).account_lifecycle_consumer

        # Validate Event Bus credentials
        eventbus_username = os.environ.get("EVENTBUS_USERNAME", "")
        eventbus_password = os.environ.get("EVENTBUS_PASSWORD", "")
        regions = _get_eventbus_regions()
        _validate_eventbus_credentials(eventbus_username, eventbus_password, regions)

        logger.info(f"Event Bus credentials validated for regions: {', '.join(regions)}")

        consumers = _create_lifecycle_consumers(
            lifecycle_service,
            eventbus_username,
            eventbus_password,
            regions,
            client_class=Client,
            queue_class=Queue,
            consumer_class=Consumer,
        )
        logger.info(
            (
                "Lifecycle consumer started. Listening for account lifecycle events "
                f"in regions: {', '.join(regions)}"
            )
        )

        if len(consumers) == 1:
            consumers[0].run()
        else:
            for consumer in consumers:
                consumer.start()
                started_consumers.append(consumer)

            for consumer in started_consumers:
                consumer.join()

    except KeyboardInterrupt:
        logger.info("Lifecycle consumer interrupted by user")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Fatal error in lifecycle consumer: {e}", exc_info=True)
        sys.exit(1)
    finally:
        for consumer in started_consumers:
            try:
                consumer.stop()
            except Exception:
                logger.warning("Failed to stop lifecycle consumer thread cleanly", exc_info=True)
        logger.info("Lifecycle consumer stopped")


if __name__ == "__main__":
    main()