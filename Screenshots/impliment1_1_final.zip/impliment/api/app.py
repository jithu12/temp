import os

from flask import Flask
from platform_api import PlatformApi
from sg_metrology.extensions import flask as metrology

from dataviz_api.config.conf import APP_NAME, ERROR_DETAILS
from dataviz_api import config, core

BASE_DIR = os.path.dirname(__file__)
SPEC_DIR = os.path.join(BASE_DIR, "specifications")
CONFIG_FILE = os.path.join(BASE_DIR, "config", "config.yaml")


def create_api(
    name: str = __name__,
    specification_dir: str = SPEC_DIR,
    config_file_path: str = CONFIG_FILE,
    error_details: bool = ERROR_DETAILS,
) -> PlatformApi:
    """
    Create and configure the Platform API
    """

    api = PlatformApi(
        import_name=name,
        specification_dir=specification_dir,
        config_file_path=config_file_path,
    )

    # Public Dataviz APIs
    api.add_api(
        "api_v1.yaml",
        base_path="/v1",
        name="dataviz_v1",
        arguments={"title": "Dataviz API v1"},
    )

    # Admin / Accounts APIs
    api.add_api(
        "api_admin_v1.yaml",
        base_path="/admin/v1",
        name="dataviz_admin_v1",
        arguments={"title": "Dataviz Admin API v1"},
    )

    if not error_details:
        api.disable_stack_trace()

    return api


def init_app(app: Flask) -> None:
    """
    Initialize Flask extensions
    """

    config.init_app(app)
    metrology.init_app(app)
    core.init_app(app)


if APP_NAME.startswith("dataviz"):
    api = create_api()
    init_app(api.flask_app)


if __name__ == "__main__":
    api.run(host="127.0.0.1", port=5000)