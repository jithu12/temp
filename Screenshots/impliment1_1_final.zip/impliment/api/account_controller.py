import os
import json
from typing import Tuple, Dict, Any
from uuid import UUID

from werkzeug.exceptions import HTTPException
from flask import current_app, abort

from dataviz_api.core import get_core
from platform_api.permissions import get_current_account_id


# -------------------------------------------------------------------
# Admin accounts configuration
# -------------------------------------------------------------------
# ADMIN_ACCOUNTS is set in env.sh as a JSON array:
# export ADMIN_ACCOUNTS='["uuid-1", "uuid-2"]'
# No hardcoding here - single source of truth is env.sh
# Same env var that Core uses for its admin gate check.

# ADMIN_ACCOUNTS is loaded into global environment from env.sh on startup.
# We read it directly - no hardcoding needed.
# env.sh format: export ADMIN_ACCOUNTS='["uuid-1", "uuid-2"]'
_raw_admin_accounts = json.loads(os.environ.get("ADMIN_ACCOUNTS", "[]"))
ALLOWED_ACCOUNT_IDS = {UUID(account_id.strip()) for account_id in _raw_admin_accounts}

ALLOWED_ACTIONS = {"activate", "deactivate"}

# Statuses that mean an operation is already running
_IN_PROGRESS_STATUSES = {"UPDATE REQUESTED", "UPDATING"}


# -------------------------------------------------------------------
# Helpers
# -------------------------------------------------------------------
def _get_accounts_service(core: Any) -> Any:
    service = getattr(core, "accounts", None) or getattr(core, "account", None)
    if service is None:
        raise RuntimeError("Account service is not available in core")
    return service


def _validate_allowed_account() -> UUID:
    """
    Block the request unless the logged-in account is one of the
    hardcoded admin accounts. Returns the caller UUID on success.
    """
    caller_account_id = get_current_account_id()
    try:
        caller_uuid = UUID(str(caller_account_id))
    except (ValueError, TypeError):
        abort(403, description="You are not authorized to perform this action")

    if caller_uuid not in ALLOWED_ACCOUNT_IDS:
        abort(403, description="You are not authorized to perform this action")

    return caller_uuid


def _parse_uuid(value: Any, field_name: str) -> UUID:
    try:
        return UUID(str(value))
    except Exception:
        raise ValueError(
            f"Invalid UUID provided for '{field_name}'. "
            f"Expected format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
        )


def _get_target_account_id(kwargs: Dict[str, Any]) -> UUID:
    raw = kwargs.get("target_account_id")
    if raw is None:
        raise ValueError("Missing required path parameter 'target_account_id'.")
    return _parse_uuid(raw, "target_account_id")


def _get_caller_account_id(kwargs: Dict[str, Any]) -> UUID:
    raw = kwargs.get("account_id")
    if raw is None:
        raise ValueError("Missing caller account_id from token")
    return _parse_uuid(raw, "account_id")


def _get_account_status(account: Any) -> str:
    """Extract status string from AccountDetails object."""
    raw_status = getattr(account, "status", None)
    if raw_status is None:
        return "UNKNOWN"
    if hasattr(raw_status, "value"):
        return str(raw_status.value)
    return str(raw_status)


def _account_to_response(account: Any) -> Dict[str, Any]:
    response: Dict[str, Any] = {
        "id": str(getattr(account, "id", "")),
        "status": _get_account_status(account),
    }
    owner = getattr(account, "owner_account_id", None)
    if owner is not None:
        response["owner_account_id"] = str(owner)
    name = getattr(account, "name", None)
    if name:
        response["name"] = name
    return response


def _check_account_exists(accounts_service: Any, owner_account_id: UUID) -> Any:
    try:
        return accounts_service.get_by_owner_id(str(owner_account_id))
    except Exception as e:
        if type(e).__name__ == "AccountNotFoundException":
            raise
        raise


def _handle_core_exception(e: Exception) -> Tuple[Dict[str, Any], int]:
    name = type(e).__name__

    if name == "NotOwnerError":
        return {
            "error": "You are not authorized to perform admin operations.",
            "code": "ADMIN_ACCESS_REQUIRED",
        }, 403

    if name == "AccountNotFoundException":
        return {
            "error": ("Account not found. Please check the owner_account_id and try again."),
            "code": "ACCOUNT_NOT_FOUND",
        }, 404

    if name == "AccountNotInActiveException":
        return {
            "error": "Account is not in the required state for this operation.",
            "code": "ACCOUNT_INVALID_STATE",
        }, 409

    return {
        "error": f"An unexpected error occurred: {str(e)}",
        "code": "INTERNAL_ERROR",
    }, 500


# -------------------------------------------------------------------
# Pre-flight status checks
# -------------------------------------------------------------------
def _assert_account_is_active(account: Any, owner_account_id: UUID) -> None:
    """
    Raise a clear 409 if the account cannot be deactivated.
    Allowed from: ACTIVE, FAILED (retry after failed deactivation)
    Blocked if:   INACTIVE, DELETED, UPDATE REQUESTED, UPDATING
    """
    status = _get_account_status(account)

    if status in _IN_PROGRESS_STATUSES:
        raise ValueError(
            f"ACCOUNT_OPERATION_IN_PROGRESS:"
            f"Account '{owner_account_id}' already has an operation in progress. "
            f"Current status: '{status}'. Please wait for it to complete and try again."
        )

    if status == "INACTIVE":
        raise ValueError(
            f"ACCOUNT_ALREADY_INACTIVE:"
            f"Account '{owner_account_id}' is already inactive. "
            f"No changes were made."
        )

    if status == "DELETED":
        raise ValueError(
            f"ACCOUNT_ALREADY_DELETED:"
            f"Account '{owner_account_id}' has already been deleted. "
            f"No changes were made."
        )

    # Allow ACTIVE and FAILED (FAILED = retry after failed deactivation)
    if status not in ("ACTIVE", "FAILED"):
        raise ValueError(
            f"ACCOUNT_INVALID_STATE:"
            f"Account '{owner_account_id}' is in state '{status}' "
            f"and cannot be deactivated. "
            f"Only ACTIVE or FAILED accounts can be deactivated."
        )


def _assert_account_is_inactive(account: Any, owner_account_id: UUID) -> None:
    """
    Raise a clear 409 if the account cannot be reactivated.
    Allowed from: INACTIVE, FAILED (retry after failed reactivation)
    Blocked if:   ACTIVE, DELETED, UPDATE REQUESTED, UPDATING
    """
    status = _get_account_status(account)

    if status in _IN_PROGRESS_STATUSES:
        raise ValueError(
            f"ACCOUNT_OPERATION_IN_PROGRESS:"
            f"Account '{owner_account_id}' already has an operation in progress. "
            f"Current status: '{status}'. Please wait for it to complete and try again."
        )

    if status == "ACTIVE":
        raise ValueError(
            f"ACCOUNT_ALREADY_ACTIVE:"
            f"Account '{owner_account_id}' is already active. "
            f"No changes were made."
        )

    if status == "DELETED":
        raise ValueError(
            f"ACCOUNT_ALREADY_DELETED:"
            f"Account '{owner_account_id}' has been deleted and cannot be reactivated. "
            f"No changes were made."
        )

    # Allow INACTIVE and FAILED (FAILED = retry after failed reactivation)
    if status not in ("INACTIVE", "FAILED"):
        raise ValueError(
            f"ACCOUNT_INVALID_STATE:"
            f"Account '{owner_account_id}' is in state '{status}' "
            f"and cannot be reactivated. "
            f"Only INACTIVE or FAILED accounts can be reactivated."
        )


def _assert_account_is_deletable(account: Any, owner_account_id: UUID) -> None:
    """
    Raise a clear 409 if the account cannot be deleted.
    Allowed from: ACTIVE, INACTIVE, FAILED
    Blocked if:   DELETED, UPDATE REQUESTED, UPDATING
    """
    status = _get_account_status(account)

    if status in _IN_PROGRESS_STATUSES:
        raise ValueError(
            f"ACCOUNT_OPERATION_IN_PROGRESS:"
            f"Account '{owner_account_id}' already has an operation in progress. "
            f"Current status: '{status}'. Please wait for it to complete and try again."
        )

    if status == "DELETED":
        raise ValueError(
            f"ACCOUNT_ALREADY_DELETED:"
            f"Account '{owner_account_id}' has already been deleted. "
            f"No changes were made."
        )

    # Allow ACTIVE, INACTIVE, FAILED
    if status not in ("ACTIVE", "INACTIVE", "FAILED"):
        raise ValueError(
            f"ACCOUNT_INVALID_STATE:"
            f"Account '{owner_account_id}' is in state '{status}' "
            f"and cannot be deleted. "
            f"Only ACTIVE, INACTIVE or FAILED accounts can be deleted."
        )


def _handle_state_error(e: ValueError) -> Tuple[Dict[str, Any], int]:
    """
    Parse structured ValueError messages from pre-flight checks
    and return clean JSON responses with correct HTTP status codes.
    """
    message = str(e)

    code_map = {
        "ACCOUNT_OPERATION_IN_PROGRESS": (
            "An operation is already in progress on this account. "
            "Please wait for it to complete and try again.",
            409,
        ),
        "ACCOUNT_ALREADY_INACTIVE": (
            "Account is already inactive. No changes were made.",
            409,
        ),
        "ACCOUNT_ALREADY_ACTIVE": (
            "Account is already active. No changes were made.",
            409,
        ),
        "ACCOUNT_ALREADY_DELETED": (
            "Account has been deleted and cannot be modified.",
            409,
        ),
        "ACCOUNT_INVALID_STATE": (
            "Account is not in the required state for this operation.",
            409,
        ),
    }

    for prefix, (friendly_message, status_code) in code_map.items():
        if message.startswith(f"{prefix}:"):
            detail = message.split(":", 1)[1].strip()
            return {
                "error": friendly_message,
                "detail": detail,
                "code": prefix,
            }, status_code

    return {"error": message, "code": "VALIDATION_ERROR"}, 400


# -------------------------------------------------------------------
# Admin lifecycle endpoints
# -------------------------------------------------------------------
def account_update_status(**kwargs: Any) -> Tuple[Dict[str, Any], int]:
    """
    PATCH /admin/v1/accounts/{target_account_id}/{action}

    Action dropdown in Swagger:
        deactivate - deactivates the account and all its workspaces
                     account shows UPDATE REQUESTED while in progress
                     then INACTIVE when complete
        activate   - reactivates the account and all its workspaces
                     account shows UPDATE REQUESTED while in progress
                     then ACTIVE when complete

    Allowed transitions:
        deactivate: ACTIVE -> UPDATE REQUESTED -> INACTIVE
                    FAILED -> UPDATE REQUESTED -> INACTIVE (retry)
        activate:   INACTIVE -> UPDATE REQUESTED -> ACTIVE
                    FAILED -> UPDATE REQUESTED -> ACTIVE (retry)

    Blocked if account is already in the target state,
    already DELETED, or has an operation in progress.
    """
    core = get_core(current_app)

    try:
        _validate_allowed_account()

        accounts_service = _get_accounts_service(core)
        target_owner_account_id = _get_target_account_id(kwargs)
        caller_account_id = _get_caller_account_id(kwargs)

        action = kwargs.get("action", "").lower()

        if action not in ALLOWED_ACTIONS:
            return {
                "error": (
                    f"Invalid action '{action}'. "
                    f"Must be one of: {', '.join(sorted(ALLOWED_ACTIONS))}"
                ),
                "code": "INVALID_ACTION",
            }, 400

        # Pre-flight check - fetch account and validate current state
        account = _check_account_exists(accounts_service, target_owner_account_id)

        if action == "deactivate":
            _assert_account_is_active(account, target_owner_account_id)
            account = accounts_service.request_account_deactivation(
                owner_account_id=target_owner_account_id,
                account_id=caller_account_id,
            )
        elif action == "activate":
            _assert_account_is_inactive(account, target_owner_account_id)
            account = accounts_service.request_account_reactivation(
                owner_account_id=target_owner_account_id,
                account_id=caller_account_id,
            )

        return _account_to_response(account), 202

    except ValueError as e:
        return _handle_state_error(e)
    except HTTPException:
        raise
    except Exception as e:
        return _handle_core_exception(e)


def account_delete(**kwargs: Any) -> Tuple[Dict[str, Any], int]:
    """
    DELETE /admin/v1/accounts/{target_account_id}

    Soft deletes the target account and all its associated workspaces.
    Records remain in the database with status DELETED.

    Allowed from: ACTIVE, INACTIVE, FAILED
    Blocked if:   DELETED, UPDATE REQUESTED (in progress), UPDATING

    The account status is set to DELETED immediately.
    Workspace deletion happens asynchronously via Celery.
    """
    core = get_core(current_app)

    try:
        _validate_allowed_account()

        accounts_service = _get_accounts_service(core)
        target_owner_account_id = _get_target_account_id(kwargs)
        caller_account_id = _get_caller_account_id(kwargs)

        account = _check_account_exists(accounts_service, target_owner_account_id)
        _assert_account_is_deletable(account, target_owner_account_id)

        account = accounts_service.request_account_deletion(
            owner_account_id=target_owner_account_id,
            account_id=caller_account_id,
        )

        return _account_to_response(account), 202

    except ValueError as e:
        return _handle_state_error(e)
    except HTTPException:
        raise
    except Exception as e:
        return _handle_core_exception(e)


def account_status(**kwargs: Any) -> Tuple[Dict[str, Any], int]:
    """
    GET /admin/v1/accounts/{target_account_id}/status

    Returns the current lifecycle status of the specified account
    along with workspace count and details.
    Available to any authenticated user (no admin gate).

    Possible status values:
        ACTIVE           - account is running normally
        UPDATE REQUESTED - deactivation or reactivation in progress
        INACTIVE         - account and workspaces are suspended
        DELETED          - account has been soft deleted
        FAILED           - last operation failed, retry is allowed
    """
    core = get_core(current_app)

    try:
        accounts_service = _get_accounts_service(core)
        target_account_id = _get_target_account_id(kwargs)

        account = accounts_service.get_by_owner_id(str(target_account_id))
        response = _account_to_response(account)

        # Fetch workspace details - best effort, never fails the request
        try:
            workspace_service = getattr(core, "workspace", None)
            if workspace_service is not None:
                from dataviz_core.services.filtering import FilteringCriterion

                filters = [FilteringCriterion("owner_account_id", str(target_account_id))]
                workspaces = workspace_service.repositories.workspace.list(filters=filters)
                response["workspace_count"] = len(workspaces)
                response["workspaces"] = [
                    {
                        "id": str(getattr(ws, "id", "")),
                        "name": str(getattr(ws, "name", "")),
                        "status": (
                            str(ws.status.value)
                            if hasattr(ws.status, "value")
                            else str(getattr(ws, "status", ""))
                        ),
                    }
                    for ws in workspaces
                ]
            else:
                response["workspace_count"] = 0
                response["workspaces"] = []
        except Exception:
            response["workspace_count"] = 0
            response["workspaces"] = []

        return response, 200

    except ValueError as e:
        return _handle_state_error(e)
    except HTTPException:
        raise
    except Exception as e:
        return _handle_core_exception(e)