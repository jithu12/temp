from __future__ import annotations
import logging
import uuid
from typing import TYPE_CHECKING, Dict, Union

from event_bus_client import CloudEventMessage, Publisher
from sg_cloud_event import LifecycleEvent

from dataviz_core.models import Status
from dataviz_core.models.utils import utcnow
from dataviz_core.utils.logging import get_default_logger

if TYPE_CHECKING:  # pragma: no cover
    from typing import Any, Optional

    from event_bus_client import Client

LoggerType = Union[logging.Logger, logging.LoggerAdapter]

STATUS_TO_LIFECYCLE_EVENT_TYPE = {
    Status.CREATION_REQUESTED: "LifecycleEvent.ResourceCreating",
    Status.CREATING: "LifecycleEvent.ResourceCreating",
    Status.ACTIVE: "LifecycleEvent.ResourceReady",
    Status.UPDATE_REQUESTED: "LifecycleEvent.ResourceModifying",
    Status.UPDATING: "LifecycleEvent.ResourceModifying",
    Status.DELETION_REQUESTED: "LifecycleEvent.ResourceDeleting",
    Status.DELETING: "LifecycleEvent.ResourceDeleting",
    Status.DELETED: "LifecycleEvent.ResourceDeleted",
    Status.FAILED: "LifecycleEvent.ResourceError",
    # Fix #14: INACTIVE is an intentional deactivation, not an error.
    # Using ResourceInactive instead of ResourceError to reflect the correct semantics.
    Status.INACTIVE: "LifecycleEvent.ResourceInactive",
}

DEFAULT_LIFECYCLE_DATASCHEMA = "srn:sgcp:refdata:schema:schema-resource-json-1.0.0"


def get_lifecycle_event_type(old_status: Status, new_status: Status) -> Union[str, None]:
    if new_status == Status.ACTIVE and old_status == Status.UPDATING:
        return "LifecycleEvent.ResourceModified"

    return STATUS_TO_LIFECYCLE_EVENT_TYPE.get(new_status)


class EventBusAdapter:
    def __init__(
        self,
        eventbus_account: Client,
        account_id: str,
        fqdn_source: str,
        logger: Optional[LoggerType] = None,
    ) -> None:
        self.__account = eventbus_account
        self._account_id = account_id
        self._fqdn_source = fqdn_source
        self.logger = logger if logger else get_default_logger(__name__)

    def send_status(
        self,
        resource_type: str,
        resource_id: str,
        old_status: Status,
        new_status: Status,
        data: Dict[str, Any],
    ) -> None:
        lifecycle_event_type = get_lifecycle_event_type(old_status, new_status)
        if not lifecycle_event_type:
            self.logger.warning(
                "Skipping Event Bus publish for unsupported status transition: %s -> %s",
                old_status,
                new_status,
            )
            return

        headers = {
            "specversion": "1.0",
            "id": str(uuid.uuid4()),
            "type": lifecycle_event_type,
            "source": self._fqdn_source,
            "time": utcnow().isoformat(),
            "subject": resource_id,
            "datacontenttype": "application/hal+json",
            "dataschema": DEFAULT_LIFECYCLE_DATASCHEMA,
        }

        self.logger.info(f"Event cycle header data: {headers}")

        extensions = {
            "resourceOwner": self._account_id,
            "resourceService": self._fqdn_source,
            "resourceType": resource_type,
            "resourceSubType": "",
        }

        self.logger.info(f"Event cycle extensions data: {extensions}")

        self.logger.info(f"Event cycle data: {data}")

        event = LifecycleEvent(headers=headers, extensions=extensions, data=data)

        message = CloudEventMessage.build_from_event(event)

        self.logger.info(f"Cloud Event message data: {message}")

        publisher = Publisher(client=self.__account, topic="lifecycle")
        publisher.publish(message)