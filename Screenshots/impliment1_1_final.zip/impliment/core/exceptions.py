import uuid
from typing import Any, Dict, Optional, Union
from dataviz_core.errors.error_codes import CoreErrorCode



class APIError(Exception):
    """ "Base exception for the services"""

    #: This is the default fallback code when we don't know much about an error, usually unexpected
    #: exceptions. As such it is not very informative so please try to use a more specific code
    #: whenever possible.
    #: Each subclass should have its own error code.
    code: str = CoreErrorCode.DEFAULT_ERROR.value

    #: This is the default fallback message when we don't know much about an error,
    #: usually unexpected exceptions. As such it is not very informative so please try to use a
    #: more specific message whenever possible.
    #: Each subclass should have its own error message.
    default_message: str = "An unknown error has occurred"

    @property
    def int_code(self) -> int:
        """
        :return: the int part or the error code suitable as an exit code
        """
        return int(self.code[4:])

    # Fix #7: properly call super().__init__ so args are preserved on the exception
    def __init__(self, *args):
        if not args:
            super().__init__(self.default_message)
        else:
            super().__init__(*args)


class CannotDeleteResourceError(APIError):
    """Unspecified error while trying to delete a resource"""

    code = CoreErrorCode.CANNOT_DELETE_RESOURCE.value

    def __init__(self, resource_type: str, identifier: str):
        self.resource_type = resource_type
        self.identifier = identifier

    def __str__(self):
        return f"Cannot delete {self.resource_type} with id '{self.identifier}'"


# Fix #8: WorkspaceActivationFailedError should NOT inherit CannotDeleteResourceError —
# activation failure is not a deletion error. Changed base class to APIError.
class WorkspaceActivationFailedError(APIError):
    "The Activation of the Workspace Failed"

    code = CoreErrorCode.WORKSPACE_STATUS_ACTIVE_FAILED_ERROR.value

    def __init__(self, identifier: uuid.UUID):
        super().__init__(f"Workspace activation failed for id '{identifier}'")


class WorkspaceDeActivationFailedError(APIError):
    "The Deactivation of the Workspace Failed"

    code = CoreErrorCode.WORKSPACE_STATUS_INACTIVE_FAILED_ERROR.value

    def __init__(self, identifier: uuid.UUID):
        super().__init__(f"Workspace deactivation failed for id '{identifier}'")


# Fix #2: KubeStackCreationError was missing — imported in kube.py but never defined here
class KubeStackCreationError(APIError):
    """Raised when a Kube stack creation or reactivation fails."""

    def __init__(self, identifier):
        super().__init__(f"Kube stack creation/reactivation failed for id '{identifier}'")


# Account Errors
class AccountNotFoundException(APIError):
    "Requested account does not exist"

    # Fix #10: updated constant name (was ACCOUNT_NOT_FOUNT_ERROR — typo)
    code = CoreErrorCode.ACCOUNT_NOT_FOUND_ERROR.value


class AccountNotInActiveException(APIError):
    "Requested account is not active"

    code = CoreErrorCode.ACCOUNT_NOT_IN_ACTIVE_ERROR.value
