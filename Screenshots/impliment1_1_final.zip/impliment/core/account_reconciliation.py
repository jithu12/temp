"""
Account Reconciliation Service

Daily scheduled job to reconcile account status between DataViz and Accounts Team.

Purpose:
- Event Bus may occasionally miss events or have delivery failures
- This service provides eventual consistency by polling Accounts Team API
- Runs daily to catch any discrepancies

Architecture:
- Scheduled by Celery Beat (daily execution)
- Fetches all DataViz accounts
- Compares with Accounts Team status via their API
- Updates any mismatches
- Logs discrepancies for monitoring

This is a SYNC/RECONCILIATION service, not an event consumer.
"""

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone
from uuid import UUID

from dataviz_core.models.shared_enums import Status
from dataviz_core.models.account_details import AccountDetails
from dataviz_core.services.session import SessionManagerMixin
from dataviz_core.services.filtering import FilteringCriterion

logger = logging.getLogger(__name__)


class AccountReconciliationService(SessionManagerMixin):
    """
    Daily reconciliation job to sync account status with Accounts Team.

    Ensures eventual consistency between DataViz and Accounts Team by:
    1. Fetching all non-deleted accounts from DataViz
    2. Checking their status with Accounts Team API
    3. Updating any discrepancies
    4. Logging all changes for monitoring

    This catches cases where Event Bus events were missed or failed.
    """

    def __init__(self, session_provider, repository_context, accounts_api_client=None):
        """
        Initialize reconciliation service.

        Args:
            session_provider: Database session provider
            repository_context: Repository context for data access
            accounts_api_client: Client for calling Accounts Team API (to be implemented)
        """
        super().__init__(session_provider, repository_context)
        self._accounts_api_client = accounts_api_client
        self._lifecycle_consumer = None
        self._workspace_service = None
        logger.info("AccountReconciliationService initialized")

    def set_lifecycle_consumer(self, lifecycle_consumer):
        """
        Set lifecycle consumer for reusing event handling logic.

        Args:
            lifecycle_consumer: AccountService instance (handles account lifecycle events)
        """
        self._lifecycle_consumer = lifecycle_consumer
        logger.info("AccountService injected into reconciliation service")

    def set_workspace_service(self, workspace_service):
        """
        Set workspace service for cascade deletion.

        Args:
            workspace_service: WorkspaceService instance
        """
        self._workspace_service = workspace_service
        logger.info("WorkspaceService injected into reconciliation service")

    def run(self) -> Dict[str, Any]:
        """
        Main entry point for daily reconciliation job.

        Execution flow:
        1. Fetch all DataViz accounts (excluding DELETED)
        2. For each account, check status with Accounts Team
        3. If status differs, update DataViz to match Accounts Team
        4. If account deleted on Accounts Team side, delete from DataViz
        5. Return summary of changes

        Returns:
            Dict with reconciliation summary:
                - started_at: ISO timestamp
                - completed_at: ISO timestamp
                - accounts_checked: int
                - accounts_updated: int
                - accounts_deleted: int
                - errors: List[str]
                - details: List[Dict] (account-level details)
        """
        start_time = datetime.now(timezone.utc)
        logger.info("Starting daily account reconciliation")

        summary = {
            "started_at": start_time.isoformat(),
            "accounts_checked": 0,
            "accounts_updated": 0,
            "accounts_deleted": 0,
            "errors": [],
            "details": [],
        }

        try:
            # Get all DataViz accounts (exclude DELETED)
            accounts = self._get_dataviz_accounts()
            summary["accounts_checked"] = len(accounts)

            logger.info(f"Found {len(accounts)} accounts to reconcile")

            # Reconcile each account
            for account in accounts:
                try:
                    result = self._reconcile_account(account)
                    summary["details"].append(result)

                    if result.get("updated"):
                        summary["accounts_updated"] += 1
                    if result.get("deleted"):
                        summary["accounts_deleted"] += 1

                except Exception as e:
                    error_msg = f"Error reconciling account {account.owner_account_id}: {str(e)}"
                    logger.error(error_msg, exc_info=True)
                    summary["errors"].append(error_msg)

            end_time = datetime.now(timezone.utc)
            summary["completed_at"] = end_time.isoformat()
            duration = (end_time - start_time).total_seconds()

            logger.info(
                f"Reconciliation completed in {duration}s: "
                f"{summary['accounts_checked']} checked, "
                f"{summary['accounts_updated']} updated, "
                f"{summary['accounts_deleted']} deleted, "
                f"{len(summary['errors'])} errors"
            )

            return summary

        except Exception as e:
            error_msg = f"Fatal error during reconciliation: {str(e)}"
            logger.error(error_msg, exc_info=True)
            summary["errors"].append(error_msg)
            summary["completed_at"] = datetime.now(timezone.utc).isoformat()
            return summary

    def _get_dataviz_accounts(self) -> List[AccountDetails]:
        """
        Fetch all non-deleted accounts from DataViz database.

        Returns:
            List of AccountDetails objects
        """
        filters = [FilteringCriterion("status", Status.DELETED, op="ne")]
        accounts = self.repositories.account_details.list(filters=filters)
        logger.debug(f"Fetched {len(accounts)} non-deleted accounts from DataViz")
        return accounts

    def _reconcile_account(self, account: AccountDetails) -> Dict[str, Any]:
        """
        Reconcile a single account with Accounts Team.

        Compares DataViz status with Accounts Team status and updates if needed.

        Args:
            account: AccountDetails object from DataViz

        Returns:
            Dict with reconciliation result:
                - account_id: UUID
                - dataviz_status: str
                - accounts_team_status: str
                - updated: bool
                - deleted: bool
                - action_taken: str (optional)
        """

        account_id = account.owner_account_id
        dataviz_status = account.status

        logger.debug(f"Reconciling account {account_id} (DataViz status: {dataviz_status})")

        # Skip accounts already marked as deleted in DataViz
        if dataviz_status == Status.DELETED:
            logger.debug(f"Account {account_id} already deleted in DataViz, skipping")
            return {
                "account_id": str(account_id),
                "dataviz_status": str(dataviz_status),
                "accounts_team_status": "UNKNOWN",
                "updated": False,
                "deleted": False,
                "action_taken": "Skipped - account already deleted in DataViz",
            }

        try:
            return self._do_reconcile_account(account, account_id, dataviz_status)
        except Exception as e:
            logger.error(f"Error reconciling account {account_id}: {str(e)}", exc_info=True)
            return {
                "account_id": str(account_id),
                "dataviz_status": str(dataviz_status),
                "accounts_team_status": "UNKNOWN",
                "updated": False,
                "deleted": False,
                "error": str(e),
            }

    def _do_reconcile_account(self, account, account_id, dataviz_status) -> dict:
        """Internal reconciliation logic extracted for error handling."""
        # Fetch status from Accounts Team
        accounts_team_status = self._fetch_account_status_from_accounts_team(account_id)

        if accounts_team_status is None:
            logger.warning(f"Could not fetch status for account {account_id} from Accounts Team")
            return {
                "account_id": str(account_id),
                "dataviz_status": str(dataviz_status),
                "accounts_team_status": "UNKNOWN",
                "updated": False,
                "deleted": False,
                "error": "Failed to fetch status from Accounts Team",
            }

        # Compare statuses
        if accounts_team_status == "DELETED" or accounts_team_status == "NOT_FOUND":
            # Account deleted on Accounts Team side but still exists in DataViz
            logger.warning(f"Account {account_id} deleted on Accounts Team but exists in DataViz")
            self._delete_account_from_dataviz(account_id)
            return {
                "account_id": str(account_id),
                "dataviz_status": str(dataviz_status),
                "accounts_team_status": accounts_team_status,
                "updated": False,
                "deleted": True,
                "action_taken": "Deleted account from DataViz (was deleted on Accounts Team)",
            }

        # Map Accounts Team status to DataViz status
        expected_status = self._map_accounts_team_status_to_dataviz(accounts_team_status)

        if expected_status != dataviz_status:
            # Status mismatch - update DataViz to match Accounts Team
            logger.warning(
                f"Status mismatch for account {account_id}: "
                f"DataViz={dataviz_status}, Accounts Team={accounts_team_status}"
            )
            self._update_account_status(account, expected_status, accounts_team_status)
            return {
                "account_id": str(account_id),
                "dataviz_status": str(dataviz_status),
                "accounts_team_status": accounts_team_status,
                "updated": True,
                "deleted": False,
                "action_taken": f"Updated status from {dataviz_status} to {expected_status}",
            }

        # Status matches - no action needed
        return {
            "account_id": str(account_id),
            "dataviz_status": str(dataviz_status),
            "accounts_team_status": accounts_team_status,
            "updated": False,
            "deleted": False,
            "action_taken": "No action - statuses match",
        }

    def _fetch_account_status_from_accounts_team(self, account_id: UUID) -> Optional[str]:
        """
        Fetch account status from Accounts Team API.

        Args:
            account_id: Account UUID

        Returns:
            Account status string from Accounts Team, or None if fetch failed
        """
        # TODO: Implement actual API call when Accounts Team provides API endpoint

        if self._accounts_api_client is None:
            logger.warning("Accounts Team API client not configured - skipping status fetch")
            return None

        # Fix #13: removed the dead `except` block — logger.warning + return None
        # never raises, so the except was unreachable. If a real API call is added
        # later, re-add the try/except around it.
        logger.warning(
            f"Accounts Team API not implemented yet - cannot fetch status for {account_id}"
        )
        return None

    def _map_accounts_team_status_to_dataviz(self, accounts_team_status: str) -> Status:
        """
        Map Accounts Team status to DataViz Status enum.

        Args:
            accounts_team_status: Status string from Accounts Team

        Returns:
            DataViz Status enum value
        """
        status_mapping = {
            "ACTIVE": Status.ACTIVE,
            "INACTIVE": Status.INACTIVE,
            "DEACTIVATED": Status.INACTIVE,
            "DELETING": Status.DELETING,
            "DELETED": Status.DELETED,
        }

        mapped_status = status_mapping.get(accounts_team_status.upper())
        if mapped_status is None:
            logger.warning(
                f"Unknown Accounts Team status: {accounts_team_status}, defaulting to INACTIVE"
            )
            return Status.INACTIVE

        return mapped_status

    def _update_account_status(
        self, account: AccountDetails, new_status: Status, accounts_team_status: str
    ) -> None:
        """
        Update DataViz account status and trigger appropriate lifecycle actions.

        Args:
            account: AccountDetails object
            new_status: New status to set
            accounts_team_status: Original status from Accounts Team (for event simulation)
        """
        account_id = account.owner_account_id
        old_status = account.status

        logger.info(f"Updating account {account_id} status: {old_status} -> {new_status}")

        # If lifecycle consumer is available, use it to handle status changes
        # This reuses the event handling logic
        if self._lifecycle_consumer is not None:
            event_type = None

            if new_status == Status.INACTIVE and old_status == Status.ACTIVE:
                event_type = "ResourceDisabled"
            elif new_status == Status.ACTIVE and old_status == Status.INACTIVE:
                event_type = "ResourceActive"
            elif new_status == Status.DELETED or new_status == Status.DELETING:
                event_type = "ResourceDeleting"

            if event_type:
                logger.info(f"Triggering lifecycle handler: {event_type} for account {account_id}")
                try:
                    self._lifecycle_consumer.handle_event(
                        event_type=event_type,
                        account_id=account_id,
                        event_data={
                            "source": "reconciliation",
                            "accounts_team_status": accounts_team_status,
                        },
                    )
                except Exception as e:
                    logger.error(f"Lifecycle handler failed for {account_id}: {e}")
                    # Fall back to direct status update
                    with self.autocommit():
                        self.repositories.account_details.update(
                            id=account.id,
                            status=new_status,
                        )
            else:
                # No event mapping - direct update
                with self.autocommit():
                    self.repositories.account_details.update(
                        id=account.id,
                        status=new_status,
                    )
        else:
            # No lifecycle consumer - direct update
            with self.autocommit():
                self.repositories.account_details.update(
                    id=account.id,
                    status=new_status,
                )

        logger.info(f"Account {account_id} status updated to {new_status}")

    def _delete_account_from_dataviz(self, account_id: UUID) -> None:
        """
        Delete account from DataViz (was deleted on Accounts Team side).

        Args:
            account_id: Account UUID to delete
        """
        logger.info(f"Deleting account {account_id} from DataViz (deleted on Accounts Team)")

        # Use lifecycle consumer if available
        if self._lifecycle_consumer is not None:
            try:
                self._lifecycle_consumer.handle_event(
                    event_type="ResourceDeleting",
                    account_id=account_id,
                    event_data={"source": "reconciliation"},
                )
            except Exception as e:
                logger.error(f"Failed to delete account {account_id} via lifecycle consumer: {e}")
        else:
            # Fallback: direct deletion
            with self.autocommit():
                account = self.repositories.account_details.get(owner_account_id=account_id)
                if account:
                    self.repositories.account_details.update(
                        id=account.id,
                        status=Status.DELETED,
                    )

        logger.info(f"Account {account_id} deleted from DataViz")