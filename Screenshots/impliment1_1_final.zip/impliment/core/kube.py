import time  # Fix #12: moved from inside function body to top of file
import uuid

from core.exceptions import KubeStackCreationError  # Fix #2: now defined in exceptions.py
from dataviz_core.models.kube_stack import KubeStack
from dataviz_core.models.shared_enums import Status
from dataviz_core.utils import logname
from dataviz_core.config.const import RETRY_SLEEP
from dataviz_core.services.kube import KubeService as _BaseKubeService


# Fix #1: reactivate_stack was a bare module-level function using `self`.
# It must be a method inside a class. Defined here as a mixin / extension so it
# can be used as:  KubeService.reactivate_stack = KubeServiceExtension.reactivate_stack
# or by having KubeService inherit from this class.
class KubeServiceExtension(_BaseKubeService):
    """
    Extension of KubeService that adds the reactivate_stack method.

    If KubeService is not directly sub-classable, use monkey-patching:
        from core.kube import reactivate_stack
        KubeService.reactivate_stack = reactivate_stack
    """

    def reactivate_stack(
        self,
        stack_id: uuid.UUID,
        temp_ns_check: bool = False,
    ) -> KubeStack:
        """
        Recreates all Kubernetes resources for an existing stack
        WITHOUT resetting the Grafana admin password.

        Used during account reactivation to preserve the vault password
        and avoid the reset-admin pod 409 conflict on retries.

        Identical to _create_stack except _reset_grafana_admin_password
        is deliberately skipped.
        """
        kube_stack = self.repositories.kube_stack.get_by_id(stack_id)
        kube_stack = self._refresh_stack(kube_stack)

        if kube_stack.status not in [
            Status.CREATION_REQUESTED,
            Status.CREATING,
            Status.RETRYING,
        ]:
            if kube_stack.status == Status.ACTIVE:
                self.logger.info(f"{logname(kube_stack)}: Kube stack already active!")
                return kube_stack
            self.logger.info(
                f"{logname(kube_stack)}: Kube Stack has status "
                f"'{kube_stack.status}', can't reactivate!"
            )
            raise KubeStackCreationError(kube_stack)

        self._poll_res_created(self.repositories.kube_namespace, kube_stack.kube_namespace_id)
        kube_stack = self._update_stack_with_and_return(kube_stack, status=Status.CREATING)
        self.logger.info(f"{logname(kube_stack)}: Start reactivation")

        try:
            self._wait_for_dependencies(kube_stack, temp_ns_check)
            self._poll_res_created(self.repositories.sg_connect, kube_stack.workspace.sg_connect_id)
            self._create_tls_secret(kube_stack)
            self._create_nginx_conf(kube_stack, temp_ns_check)
            self._create_grafana_secret(kube_stack)
            self._create_ldap_conf(kube_stack)
            self._create_fluent_config(kube_stack)
            self._create_metrology_log_secret(kube_stack)
            self._create_metric_fluentd_conf(kube_stack)
            self._create_metric_secret(kube_stack)
            self._create_metric_cert_secret(kube_stack)
            deployment = self._create_deployment(
                kube_stack, grafana_image=kube_stack.workspace.grafana_image
            )
            self._create_service(kube_stack)
            self._create_ingress(kube_stack)
            self._create_hpa(kube_stack)
            self._create_metric_deployment(kube_stack)
            self._check_deployment_pods_running(deployment, kube_stack)

            # NOTE: _reset_grafana_admin_password deliberately skipped
            # Vault password is preserved from original stack creation
            # Reset-admin pod is not touched during activate/deactivate

            self.sg_connect_service.update_redirect_url(
                kube_stack.workspace.sg_connect, kube_stack.dns.fqdn
            )

            time.sleep(RETRY_SLEEP)  # Fix #12: import time now at top of file

        except Exception as e:
            self.logger.exception(f"{logname(kube_stack)}: Reactivation failed")
            self.logger.info(f"{logname(kube_stack)} Celery retry process will start soon...")
            kube_stack = self._update_stack_with_and_return(
                kube_stack, status=self.failed_or_retrying_status
            )
            deployments = self._get_deployments(stack=kube_stack)
            workspace_count = len(deployments)
            self._update_namespace_with(kube_stack.kube_namespace, workspace_count=workspace_count)
            raise KubeStackCreationError(kube_stack.id) from e

        else:
            deployments = self._get_deployments(stack=kube_stack)
            workspace_count = len(deployments)
            self._update_namespace_with(kube_stack.kube_namespace, workspace_count=workspace_count)
            return self._update_stack_with_and_return(kube_stack, status=Status.ACTIVE)
