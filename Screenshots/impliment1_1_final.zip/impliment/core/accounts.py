import json
import logging
import os
import uuid
from typing import Callable, Dict, Optional, Union, Any

from dataviz_core.adapters.account_client import AccountClient, Account
from dataviz_core.utils import logname, update_resource_with
from dataviz_core.models import Status
from dataviz_core.models.workspace import Workspace
from dataviz_core.models.account_details import AccountDetails
from dataviz_core.services.interfaces import SessionProvider
from dataviz_core.services.session import SessionManagerMixin
from dataviz_core.repositories.context import RepositoryContext
from dataviz_core.utils.logging import get_default_logger
from dataviz_core.config.const import WORKSPACE_LIMIT_PER_ACCOUNT
# NOTE: ADMIN_ACCOUNTS import removed — now parsed from env as a set (see below)
from dataviz_core.services.filtering import FilteringCriterion
from dataviz_core.errors.exceptions import (
    AccountNotFoundException,
    NotOwnerError,
    AccountNotInActiveException,
)

LoggerType = Union[logging.Logger, logging.LoggerAdapter]

# ─── ADMIN ACCOUNTS — parse once at module load ───────────────────────────────
# os.environ.get returns a raw string like '["uuid-1","uuid-2"]'
# json.loads converts it to an actual Python list.
# We store it as a set for O(1) membership checks.
# Fix: previously ADMIN_ACCOUNTS was imported as a plain string, so
# `str(account_id) not in ADMIN_ACCOUNTS` was a substring check, not an exact
# match — a shorter UUID could match inside a longer one.
_raw_admin_env = os.environ.get("ADMIN_ACCOUNTS", "[]")
try:
    ADMIN_ACCOUNT_IDS: set = set(json.loads(_raw_admin_env))
except (json.JSONDecodeError, TypeError, ValueError):
    logging.getLogger(__name__).error(
        "Failed to parse ADMIN_ACCOUNTS env variable — defaulting to empty set. "
        "Raw value: %s",
        _raw_admin_env,
    )
    ADMIN_ACCOUNT_IDS: set = set()
# ─────────────────────────────────────────────────────────────────────────────

# Statuses that mean an operation is already in progress
_IN_PROGRESS_STATUSES = (Status.UPDATE_REQUESTED, Status.UPDATING)

# Statuses from which deactivation is allowed
_DEACTIVATABLE_STATUSES = (Status.ACTIVE, Status.FAILED)

# Statuses from which reactivation is allowed
_REACTIVATABLE_STATUSES = (Status.INACTIVE, Status.FAILED)

# Statuses from which deletion is allowed
_DELETABLE_STATUSES = (Status.ACTIVE, Status.INACTIVE, Status.FAILED)


class AccountService(SessionManagerMixin):

    def __init__(
        self,
        account_client: AccountClient,
        session_provider: SessionProvider,
        repository_context: Optional[RepositoryContext] = None,
        is_retrying_func: Callable[[], bool] = lambda: False,
        logger: Optional[LoggerType] = None,
        workflow_executor=None,
    ) -> None:

        super().__init__(
            session_provider,
            repository_context=repository_context,
        )

        self.is_retrying_func = is_retrying_func
        self.account_client = account_client
        self.logger = logger if logger else get_default_logger(__name__)
        self.workspace_service = None
        self.monitoring_service = None        # injected via set_monitoring_service
        self.garbage_collector_service = None # injected via set_garbage_collector_service
        self.workflow_executor = workflow_executor

    # ── Dependency injection setters ─────────────────────────────────────────

    def set_workspace_service(self, workspace_service) -> None:
        """Inject workspace service to avoid circular dependency."""
        self.workspace_service = workspace_service

    def set_monitoring_service(self, monitoring_service) -> None:
        """Inject monitoring service for sending notifications."""
        self.monitoring_service = monitoring_service

    def set_garbage_collector_service(self, garbage_collector_service) -> None:
        """Inject garbage collector service for grace period tracking."""
        self.garbage_collector_service = garbage_collector_service

    def set_workflow_executor(self, workflow_executor) -> None:
        """Inject workflow executor for async Celery tasks."""
        self.workflow_executor = workflow_executor

    # ── Admin guard — uses set membership, not substring check ───────────────

    def _assert_is_admin(self, account_id: uuid.UUID) -> None:
        """
        Raise NotOwnerError if account_id is not in the predefined
        admin accounts set.

        Uses set membership (O(1) exact match) — NOT substring search.
        Previously: `str(account_id) not in ADMIN_ACCOUNTS`  ← substring check
        Fixed:      `str(account_id) not in ADMIN_ACCOUNT_IDS` ← set membership
        """
        if str(account_id) not in ADMIN_ACCOUNT_IDS:
            raise NotOwnerError(
                f"Account {account_id} is not an authorized admin account."
            )

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _update_account_with_and_return(
        self,
        account: AccountDetails,
        **changes: Any,
    ) -> AccountDetails:
        if self._update_account_with(account, **changes):
            return self.repositories.account_details.get_by_id(account.id)
        return account

    def _update_account_with(
        self,
        account: AccountDetails,
        **changes: Any,
    ) -> Dict[str, Any]:
        return update_resource_with(
            ctx_manager=self.autocommit(),
            repository=self.repositories.account_details,
            resource=account,
            logger=self.logger,
            **changes,
        )

    def _assert_not_in_progress(
        self, account: AccountDetails, owner_account_id: uuid.UUID
    ) -> None:
        """
        Raise AccountNotInActiveException if an operation is already
        in progress on this account. Prevents concurrent modifications.
        """
        if account.status in _IN_PROGRESS_STATUSES:
            self.logger.warning(
                f"Account {owner_account_id} is already in progress. "
                + f"Current status: {account.status}"
            )
            raise AccountNotInActiveException(account.id)

    # ── External account queries ──────────────────────────────────────────────

    def get_account_details_by_id(self, workspace: Workspace) -> Account:
        """
        Retrieves account details from the external platform client.
        NOTE: This calls an external API, not the local Dataviz DB.
        For local DB lookup use get_by_owner_id instead.
        """
        self.logger.info("Collecting account information")
        return self.account_client.get_account_by_id(str(workspace.owner_account_id))

    def get_by_owner_id(self, owner_account_id: str) -> AccountDetails:
        """
        Look up AccountDetails by owner_account_id in the local DB.
        Raises AccountNotFoundException if not found.
        """
        filters = [FilteringCriterion("owner_account_id", owner_account_id)]
        results = self.repositories.account_details.list(filters=filters)

        if not results:
            self.logger.error(
                "AccountDetails not found for owner_account_id: " + f"{owner_account_id}"
            )
            raise AccountNotFoundException(
                f"AccountDetails with owner_account_id: {owner_account_id} not found"
            )

        return results[0]

    def get_soft_limit(self, owner_account_id: str):
        """Retrieves the soft limit for the specified owner account."""

        try:
            account_obj: Optional[AccountDetails] = (
                self.repositories.account_details.get_by_owner_account_id(owner_account_id)
            )
            if account_obj:
                return account_obj.soft_limit
        except Exception:
            self.logger.info(
                f"No existing account details found. Creating new for: {owner_account_id}"
            )

        account_details_from_client = self.account_client.get_account_by_id(str(owner_account_id))

        if not account_details_from_client:
            self.logger.warning(
                "Account details not found from client for ID: " + f"{owner_account_id}"
            )
            raise AccountNotFoundException(
                f"Account details with id: {owner_account_id} not found"
            )

        account_details = AccountDetails(
            name=account_details_from_client.name,
            owner_account_id=account_details_from_client.id,
            soft_limit=WORKSPACE_LIMIT_PER_ACCOUNT,
        )

        # Fix #4: was `if self.autocommit()` — a context manager is always truthy so the insert
        # ran but was never committed. Must use `with` to call __enter__/__exit__.
        with self.autocommit():
            self.repositories.account_details.insert(account_details)

        return account_details.soft_limit

    # ── Admin-gated lifecycle mutations ──────────────────────────────────────

    def request_account_deactivation(
        self,
        owner_account_id: uuid.UUID,
        account_id: uuid.UUID,
    ) -> AccountDetails:
        """
        Request deactivation of an account and all its active workspaces.

        Allowed from: ACTIVE, FAILED (retry after failed deactivation)
        Blocked if:   INACTIVE, DELETED, UPDATE_REQUESTED (in progress)

        Flow:
        - No active workspaces -> immediately INACTIVE
        - Has active workspaces -> UPDATE_REQUESTED -> async -> INACTIVE
        - On async failure -> FAILED
        """
        # Fix: replaced `str(account_id) not in ADMIN_ACCOUNTS` substring check
        # with set membership via _assert_is_admin
        self._assert_is_admin(account_id)

        try:
            account = self.get_by_owner_id(owner_account_id)
        except Exception:
            self.logger.error(f"Account with id: {owner_account_id} not found")
            raise AccountNotFoundException(f"Account with id: {owner_account_id} not found")

        # Block if already in progress
        self._assert_not_in_progress(account, owner_account_id)

        if account.status is Status.INACTIVE:
            self.logger.info(f"Account {owner_account_id} is already inactive.")
            raise AccountNotInActiveException(account.id)

        if account.status is Status.DELETED:
            self.logger.info(f"Account {owner_account_id} is already deleted.")
            raise AccountNotInActiveException(account.id)

        if account.status not in _DEACTIVATABLE_STATUSES:
            self.logger.info(
                f"Account {owner_account_id} cannot be deactivated. "
                + f"Current status: {account.status}"
            )
            raise AccountNotInActiveException(account.id)

        # Only look for ACTIVE workspaces for deactivation
        filters = [
            FilteringCriterion("owner_account_id", owner_account_id),
            FilteringCriterion("status", Status.ACTIVE),
        ]
        workspaces = self.repositories.workspace.list(filters=filters)

        if len(workspaces) == 0:
            self.logger.info(
                "No active workspaces found for owner_account_id: " + f"{owner_account_id}"
            )
            return self._update_account_with_and_return(account, status=Status.INACTIVE)

        self.logger.info(f"Requesting {logname(account)} deactivation")

        # Set UPDATE_REQUESTED immediately so status endpoint shows progress
        # deactivate_account (async) will set INACTIVE when all workspaces done
        result = self._update_account_with_and_return(account, status=Status.UPDATE_REQUESTED)

        self.workflow_executor.async_exec_core_function(
            service="account",
            function="deactivate_account",
            kwargs={"owner_account_id": owner_account_id},
        )

        return result

    def deactivate_account(self, owner_account_id: uuid.UUID) -> AccountDetails:
        """
        Async target: deactivates all workspaces then marks account INACTIVE.
        Called by Celery worker. Sets FAILED if anything goes wrong.
        """
        try:
            account = self.get_by_owner_id(owner_account_id)
        except Exception:
            self.logger.error(f"Account with id: {owner_account_id} not found")
            raise AccountNotFoundException(f"Account with id: {owner_account_id} not found")

        self.logger.info(
            "All workspaces deactivation requested for " + f"{owner_account_id}"
        )

        try:
            workspace_details = self.workspace_service.deactivate_workspaces_by_owner_account_id(
                owner_account_id
            )
            self.logger.info(
                f"Deactivation completed for {owner_account_id} | " + f"{workspace_details}"
            )
            return self._update_account_with_and_return(account, status=Status.INACTIVE)

        except Exception as e:
            self.logger.error(f"Deactivation failed for {owner_account_id}. Error: {e}")
            self._update_account_with(account, status=Status.FAILED)
            raise

    def request_account_reactivation(
        self,
        owner_account_id: uuid.UUID,
        account_id: uuid.UUID,
    ) -> AccountDetails:
        """
        Request reactivation of an account and all its inactive workspaces.

        Allowed from: INACTIVE, FAILED (retry after failed reactivation)
        Blocked if:   ACTIVE, DELETED, UPDATE_REQUESTED (in progress)

        Flow:
        - No inactive workspaces -> immediately ACTIVE
        - Has inactive workspaces -> UPDATE_REQUESTED -> async -> ACTIVE
        - On async failure -> FAILED
        """
        # Fix: replaced `str(account_id) not in ADMIN_ACCOUNTS` substring check
        # with set membership via _assert_is_admin
        self._assert_is_admin(account_id)

        try:
            account = self.get_by_owner_id(owner_account_id)
        except Exception:
            raise AccountNotFoundException(f"Account with id: {owner_account_id} not found")

        # Block if already in progress
        self._assert_not_in_progress(account, owner_account_id)

        if account.status is Status.ACTIVE:
            self.logger.info(f"Account {owner_account_id} is already active.")
            raise AccountNotInActiveException(account.id)

        if account.status is Status.DELETED:
            self.logger.info(f"Account {owner_account_id} is already deleted.")
            raise AccountNotInActiveException(account.id)

        if account.status not in _REACTIVATABLE_STATUSES:
            self.logger.info(
                f"Account {owner_account_id} cannot be reactivated. "
                + f"Current status: {account.status}"
            )
            raise AccountNotInActiveException(account.id)

        # Only look for INACTIVE workspaces for reactivation
        filters = [
            FilteringCriterion("owner_account_id", owner_account_id),
            FilteringCriterion("status", Status.INACTIVE),
        ]
        workspaces = self.repositories.workspace.list(filters=filters)

        if len(workspaces) == 0:
            self.logger.info(
                f"No inactive workspaces found for owner_account_id: {owner_account_id}"
            )
            return self._update_account_with_and_return(account, status=Status.ACTIVE)

        self.logger.info(f"Requesting {logname(account)} reactivation")

        # Set UPDATE_REQUESTED immediately so status endpoint shows progress
        # reactivate_account (async) will set ACTIVE when all workspaces done
        result = self._update_account_with_and_return(account, status=Status.UPDATE_REQUESTED)

        self.workflow_executor.async_exec_core_function(
            service="account",
            function="reactivate_account",
            kwargs={"owner_account_id": owner_account_id},
        )

        return result

    def reactivate_account(self, owner_account_id: uuid.UUID) -> AccountDetails:
        """
        Async target: reactivates all workspaces then marks account ACTIVE.
        Called by Celery worker. Sets FAILED if anything goes wrong.
        """
        try:
            account = self.get_by_owner_id(owner_account_id)
        except Exception:
            self.logger.error(f"Account with id: {owner_account_id} not found")
            raise AccountNotFoundException(f"Account with id: {owner_account_id} not found")

        try:
            workspace_details = self.workspace_service.reactivate_workspaces_by_owner_account_id(
                owner_account_id
            )
            self.logger.info(
                f"Reactivation completed for {owner_account_id} | " + f"{workspace_details}"
            )
            return self._update_account_with_and_return(account, status=Status.ACTIVE)

        except Exception as e:
            self.logger.error(f"Reactivation failed for {owner_account_id}. Error: {e}")
            self._update_account_with(account, status=Status.FAILED)
            raise

    def request_account_deletion(
        self,
        owner_account_id: uuid.UUID,
        account_id: uuid.UUID,
    ) -> AccountDetails:
        """
        Request deletion of an account and ALL its workspaces.

        Allowed from: ACTIVE, INACTIVE, FAILED
        Blocked if:   DELETED, UPDATE_REQUESTED (in progress)

        Flow:
        - No pending workspaces -> immediately DELETED
        - Has workspaces -> async -> DELETED
        - On async failure -> FAILED
        """
        # Fix: replaced `str(account_id) not in ADMIN_ACCOUNTS` substring check
        # with set membership via _assert_is_admin
        self._assert_is_admin(account_id)

        account = self.get_by_owner_id(owner_account_id)

        # Block if already in progress
        self._assert_not_in_progress(account, owner_account_id)

        if account.status is Status.DELETED:
            self.logger.info(f"Account {owner_account_id} is already deleted.")
            raise AccountNotInActiveException(account.id)

        if account.status not in _DELETABLE_STATUSES:
            self.logger.info(
                f"Account {owner_account_id} is in state {account.status} "
                + "and cannot be deleted."
            )
            raise AccountNotInActiveException(account.id)

        # Fetch ALL non-deleted workspaces
        filters = [FilteringCriterion("owner_account_id", owner_account_id)]
        all_workspaces = self.repositories.workspace.list(filters=filters)
        pending_workspaces = [w for w in all_workspaces if w.status is not Status.DELETED]

        if len(pending_workspaces) == 0:
            self.logger.info(
                "No workspaces to delete for owner_account_id: " + f"{owner_account_id}"
            )
            return self._update_account_with_and_return(account, status=Status.DELETED)

        self.logger.info(
            f"Requesting {logname(account)} deletion - "
            + f"{len(pending_workspaces)} workspace(s) to delete"
        )

        # Fix #9: was marking account DELETED immediately (before workspaces are gone).
        # Set DELETING now so the status correctly reflects work in progress.
        # delete_account() (async Celery task) will set DELETED once all workspaces
        # are cleaned up.
        result = self._update_account_with_and_return(account, status=Status.DELETING)

        self.workflow_executor.async_exec_core_function(
            service="account",
            function="delete_account",
            kwargs={"owner_account_id": owner_account_id},
        )

        return result

    def delete_account(self, owner_account_id: uuid.UUID) -> AccountDetails:
        """
        Async target: deletes all workspaces then marks account DELETED.
        Called by Celery worker. Sets FAILED if anything goes wrong.
        """
        try:
            account = self.get_by_owner_id(owner_account_id)
        except Exception:
            self.logger.error(f"Account with id: {owner_account_id} not found")
            raise AccountNotFoundException(f"Account with id: {owner_account_id} not found")

        try:
            workspace_details = self.workspace_service.delete_workspaces_by_owner_account_id(
                owner_account_id
            )
            self.logger.info(
                f"Deletion completed for {owner_account_id} | " + f"{workspace_details}"
            )
            return self._update_account_with_and_return(account, status=Status.DELETED)

        except Exception as e:
            self.logger.error(f"Deletion failed for {owner_account_id}. Error: {e}")
            self._update_account_with(account, status=Status.FAILED)
            raise

    # ── Lifecycle Event Handlers (moved from AccountLifecycleConsumer) ────────

    def handle_resource_disabled(
        self,
        account_id: uuid.UUID,
        event_data: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Handle LifecycleEvent.ResourceDisabled from Accounts Team.

        When Accounts Team deactivates an account (starts grace period),
        they publish this event. We:
        1. Set deletion date via garbage collector (for grace period tracking)
        2. Trigger async deactivation of all active workspaces
        3. Update account status to INACTIVE

        Args:
            account_id: The account UUID
            event_data: Optional additional data from the event
        """
        try:
            self.logger.info(
                "AccountService: Received ResourceDisabled event for account "
                + f"{account_id} (grace period starts)"
            )

            account = self.repositories.account_details.get(owner_account_id=account_id)

            if not account:
                self.logger.warning(
                    f"AccountService: Account {account_id} not found. "
                    + "Skipping ResourceDisabled event."
                )
                return

            if account.status == Status.INACTIVE:
                self.logger.info(
                    f"AccountService: Account {account_id} already INACTIVE. No action needed."
                )
                return

            if account.status == Status.DELETED:
                self.logger.info(
                    f"AccountService: Account {account_id} already DELETED. Skipping."
                )
                return

            filters = [
                FilteringCriterion("owner_account_id", account_id),
                FilteringCriterion("status", Status.ACTIVE),
            ]
            active_workspaces = self.repositories.workspace.list(filters=filters)

            if len(active_workspaces) == 0:
                self.logger.info(
                    f"AccountService: No active workspaces for {account_id}. "
                    + "Setting INACTIVE immediately."
                )
                with self.autocommit():
                    self.repositories.account_details.update(
                        id=account.id,
                        status=Status.INACTIVE,
                    )
                self.logger.info(f"AccountService: Account {account_id} set to INACTIVE")
                return

            if self.garbage_collector_service is not None:
                grace_period_days = getattr(account, "grace_period_days", 30)
                self.logger.info(
                    f"AccountService: Setting deletion date for {account_id} "
                    + f"(grace period: {grace_period_days} days)"
                )
                self.garbage_collector_service.set_deletion_date_for_account(
                    account=account,
                    grace_period_days=grace_period_days,
                )
            else:
                self.logger.warning(
                    "AccountService: garbage_collector_service not set - "
                    + f"skipping deletion date for {account_id}"
                )

            with self.autocommit():
                self.repositories.account_details.update(
                    id=account.id,
                    status=Status.UPDATE_REQUESTED,
                )

            if self.workflow_executor is not None:
                self.logger.info(
                    "AccountService: Triggering async deactivation of "
                    + f"{len(active_workspaces)} workspace(s) for {account_id}"
                )
                self.workflow_executor.async_exec_core_function(
                    service="account",
                    function="deactivate_account",
                    kwargs={"owner_account_id": account_id},
                )
            else:
                self.logger.error(
                    "AccountService: workflow_executor not set - cannot trigger async "
                    + f"deactivation for {account_id}"
                )

            self.logger.info(
                f"AccountService: Account {account_id} deactivation "
                + "started (status: UPDATE_REQUESTED -> async task will set INACTIVE)"
            )

        except Exception as e:
            self.logger.error(
                f"AccountService: Failed to handle ResourceDisabled for account {account_id}: {e}",
                exc_info=True,
            )
            raise

    def handle_resource_active(
        self,
        account_id: uuid.UUID,
        event_data: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Handle LifecycleEvent.ResourceActive from Accounts Team.

        When Accounts Team reactivates an account during grace period,
        they publish this event. We:
        1. Cancel the deletion date (grace period cancelled)
        2. Trigger async reactivation of all inactive workspaces
        3. Update account status to ACTIVE

        Args:
            account_id: The account UUID
            event_data: Optional additional data from the event
        """
        try:
            self.logger.info(
                "AccountService: Received ResourceActive event for account "
                + f"{account_id} (reactivation, grace period cancelled)"
            )

            account = self.repositories.account_details.get(owner_account_id=account_id)

            if not account:
                self.logger.warning(
                    f"AccountService: Account {account_id} not found. "
                    + "Skipping ResourceActive event."
                )
                return

            if account.status == Status.ACTIVE:
                self.logger.info(
                    f"AccountService: Account {account_id} already ACTIVE. No action needed."
                )
                return

            if account.status == Status.DELETED:
                self.logger.warning(
                    f"AccountService: Account {account_id} is DELETED. Cannot reactivate."
                )
                return

            if self.garbage_collector_service is not None:
                if hasattr(self.garbage_collector_service, "cancel_deletion_date_for_account"):
                    self.garbage_collector_service.cancel_deletion_date_for_account(account)
                else:
                    self.logger.warning(
                        "AccountService: garbage_collector_service does not support "
                        + "cancel_deletion_date_for_account for %s",
                        account_id,
                    )

            filters = [
                FilteringCriterion("owner_account_id", account_id),
                FilteringCriterion("status", Status.INACTIVE),
            ]
            inactive_workspaces = self.repositories.workspace.list(filters=filters)

            if len(inactive_workspaces) == 0:
                self.logger.info(
                    f"AccountService: No inactive workspaces for {account_id}. "
                    + "Setting ACTIVE immediately."
                )
                with self.autocommit():
                    self.repositories.account_details.update(
                        id=account.id,
                        status=Status.ACTIVE,
                    )
                self.logger.info(f"AccountService: Account {account_id} set to ACTIVE")
                return

            with self.autocommit():
                self.repositories.account_details.update(
                    id=account.id,
                    status=Status.UPDATE_REQUESTED,
                )

            if self.workflow_executor is not None:
                self.logger.info(
                    "AccountService: Triggering async reactivation of "
                    + f"{len(inactive_workspaces)} workspace(s) for {account_id}"
                )
                self.workflow_executor.async_exec_core_function(
                    service="account",
                    function="reactivate_account",
                    kwargs={"owner_account_id": account_id},
                )
            else:
                self.logger.error(
                    "AccountService: workflow_executor not set - cannot trigger async "
                    + f"reactivation for {account_id}"
                )

            self.logger.info(
                f"AccountService: Account {account_id} reactivation started "
                + "(status: UPDATE_REQUESTED -> async task will set ACTIVE)"
            )

        except Exception as e:
            self.logger.error(
                f"AccountService: Failed to handle ResourceActive for account {account_id}: {e}",
                exc_info=True,
            )
            raise

    def handle_resource_deleting(
        self,
        account_id: uuid.UUID,
        event_data: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Handle LifecycleEvent.ResourceDeleting from Accounts Team.

        When Accounts Team permanently deletes an account (after grace period),
        they publish this event. We:
        1. Trigger async deletion of all workspaces
        2. Update account status to DELETED

        Args:
            account_id: The account UUID
            event_data: Optional additional data from the event
        """
        try:
            self.logger.info(
                "AccountService: Received ResourceDeleting event for account "
                + f"{account_id} (pending deletion)"
            )

            account = self.repositories.account_details.get(owner_account_id=account_id)

            if not account:
                self.logger.warning(
                    f"AccountService: Account {account_id} not found. "
                    + "Skipping ResourceDeleting event."
                )
                return

            if account.status == Status.DELETED:
                self.logger.info(
                    f"AccountService: Account {account_id} already DELETED. No action needed."
                )
                return

            filters = [FilteringCriterion("owner_account_id", account_id)]
            all_workspaces = self.repositories.workspace.list(filters=filters)
            pending_workspaces = [w for w in all_workspaces if w.status != Status.DELETED]

            if len(pending_workspaces) == 0:
                self.logger.info(
                    f"AccountService: No workspaces to delete for {account_id}. "
                    + "Marking account as DELETED."
                )
                with self.autocommit():
                    self.repositories.account_details.update(
                        id=account.id,
                        status=Status.DELETED,
                    )
                self.logger.info(f"AccountService: Account {account_id} set to DELETED")
                return

            if self.workflow_executor is not None:
                self.logger.info(
                    "AccountService: Triggering async deletion of "
                    + f"{len(pending_workspaces)} workspace(s) for {account_id}"
                )
                # Set DELETING (not DELETED) while the async task runs.
                # delete_account() sets DELETED itself once all workspaces
                # are gone. Marking DELETED here prematurely would cause
                # handle_resource_deleted to see a 'clean' account even
                # though workspaces are still being destroyed.
                with self.autocommit():
                    self.repositories.account_details.update(
                        id=account.id,
                        status=Status.DELETING,
                    )
                self.workflow_executor.async_exec_core_function(
                    service="account",
                    function="delete_account",
                    kwargs={"owner_account_id": account_id},
                )
                return

            if self.workspace_service is not None:
                self.logger.info(
                    "AccountService: Using workspace_service to delete "
                    + f"{len(pending_workspaces)} workspace(s) for {account_id}"
                )
                self.workspace_service.delete_workspaces_by_owner_account_id(
                    account.owner_account_id
                )
                with self.autocommit():
                    self.repositories.account_details.update(
                        id=account.id,
                        status=Status.DELETED,
                    )
                return

            raise RuntimeError(
                f"AccountService: Cannot delete workspaces for {account_id} - "
                + "no workflow_executor or workspace_service available"
            )

        except Exception as e:
            self.logger.error(
                f"AccountService: Failed to handle ResourceDeleting for account {account_id}: {e}",
                exc_info=True,
            )
            raise

    def handle_resource_deleted(
        self,
        account_id: uuid.UUID,
        event_data: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Handle LifecycleEvent.ResourceDeleted from Accounts Team.

        When Accounts Team confirms account deletion is complete,
        they publish this event. We:
        1. Verify all workspaces are deleted
        2. If resources remain, send notification email to Dataviz team

        Args:
            account_id: The account UUID
            event_data: Optional additional data from the event
        """
        try:
            self.logger.info(
                "AccountService: Received ResourceDeleted event for account "
                + f"{account_id} (deletion verification)"
            )

            account = self.repositories.account_details.get(owner_account_id=account_id)

            if not account:
                self.logger.warning(
                    f"AccountService: Account {account_id} not found in DB. "
                    + "Skipping ResourceDeleted event."
                )
                return

            # Check for remaining resources.
            # Exclude DELETED (done) and DELETING (async still in flight — expected to finish).
            # Only flag workspaces stuck in any other state as requiring manual cleanup.
            filters = [FilteringCriterion("owner_account_id", account_id)]
            all_workspaces = self.repositories.workspace.list(filters=filters)
            remaining_workspaces = [
                w for w in all_workspaces
                if w.status not in (Status.DELETED, Status.DELETING)
            ]

            if len(remaining_workspaces) == 0:
                self.logger.info(
                    f"AccountService: Account {account_id} deletion verified - "
                    + "no remaining resources."
                )
                self.logger.info(
                    "Lifecycle final cleanup report: account_id=%s remaining_resources=0 status=OK",
                    account_id,
                )
                return

            # Resources still exist — send notification to Dataviz team
            self.logger.error(
                f"AccountService: Account {account_id} marked DELETED but "
                + f"{len(remaining_workspaces)} workspace(s) remain: "
                + f"{[w.id for w in remaining_workspaces]}"
            )
            self.logger.error(
                "Lifecycle final cleanup report: account_id=%s remaining_resources=%s status=MANUAL_ACTION_REQUIRED",
                account_id,
                len(remaining_workspaces),
            )

            workspace_details = "\n".join(
                [
                    f"  - Workspace ID: {w.id}, Name: {w.name}, Status: {w.status}"
                    for w in remaining_workspaces
                ]
            )

            email_subject = f"Manual Cleanup Required: Account {account_id}"
            email_body = (
                f"Account {account_id} has been marked as DELETED by Accounts Team, "
                + f"but {len(remaining_workspaces)} workspace(s) could not be deleted "
                + "automatically.\n\n"
                + "Remaining workspaces:\n"
                + workspace_details
                + "\n\nPlease investigate and manually clean up these resources."
            )

            # Fix: monitoring_service now initialised in __init__ and injected
            # via set_monitoring_service — no longer relies on hasattr check
            if self.monitoring_service is not None:
                try:
                    self.monitoring_service.send_notification(
                        error_level="ERROR",
                        email_subject=email_subject,
                        email_body=email_body,
                    )
                    self.logger.info(
                        f"AccountService: Sent notification email for account {account_id}"
                    )
                except Exception as e:
                    self.logger.error(
                        f"AccountService: Failed to send notification email: {e}",
                        exc_info=True,
                    )
            else:
                self.logger.warning(
                    "AccountService: monitoring_service not available - "
                    + f"cannot send notification for {account_id}"
                )

        except Exception as e:
            self.logger.error(
                f"AccountService: Failed to handle ResourceDeleted for account {account_id}: {e}",
                exc_info=True,
            )
            raise

    def handle_event(
        self,
        event_type: str,
        account_id: uuid.UUID,
        event_data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Route incoming account lifecycle events to handler methods.

        Fix: return type changed from None -> Dict so callers can safely do
        result.get("success") without AttributeError.

        Args:
            event_type: The type of lifecycle event
            account_id: The account UUID
            event_data: Optional additional data from the event

        Returns:
            {"success": True} on success,
            {"success": False, "reason": str} on unrecognised event or error.
        """
        handlers = {
            "LifecycleEvent.ResourceDisabled": self.handle_resource_disabled,
            "ResourceDisabled":                self.handle_resource_disabled,
            "LifecycleEvent.ResourceActive":   self.handle_resource_active,
            "ResourceActive":                  self.handle_resource_active,
            "LifecycleEvent.ResourceDeleting": self.handle_resource_deleting,
            "ResourceDeleting":                self.handle_resource_deleting,
            "LifecycleEvent.ResourceDeleted":  self.handle_resource_deleted,
            "ResourceDeleted":                 self.handle_resource_deleted,
        }

        handler = handlers.get(event_type)
        if handler is None:
            self.logger.warning(
                f"AccountService: Unknown event type '{event_type}' for "
                + f"account {account_id}. Ignoring."
            )
            return {"success": False, "reason": f"Unrecognized event type: {event_type}"}

        try:
            handler(account_id, event_data)
            return {"success": True}
        except AccountNotFoundException as exc:
            self.logger.error(
                "Account not found while handling %s for account %s: %s",
                event_type, account_id, exc,
            )
            return {"success": False, "reason": str(exc)}
        except Exception as exc:
            self.logger.error(
                "Handler for %s raised an unexpected error for account %s: %s",
                event_type, account_id, exc,
                exc_info=True,
            )
            return {"success": False, "reason": str(exc)}