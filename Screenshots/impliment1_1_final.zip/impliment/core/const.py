import os


ADMIN_ACCOUNTS = os.environ.get("ADMIN_ACCOUNTS", "[]")