# Redis Local Setup & Testing Guide

> **Project:** `dataviz` health service  
> **Purpose:** Run Redis locally so you can develop and test the health service without needing the real infrastructure.

---

## Table of Contents

1. [How Redis is Used in This Project](#how-redis-is-used-in-this-project)
2. [Prerequisites](#prerequisites)
3. [Step 1 – Start Redis via Docker](#step-1--start-redis-via-docker)
4. [Step 2 – Install the Python Redis Client](#step-2--install-the-python-redis-client)
5. [Step 3 – Set Environment Variables](#step-3--set-environment-variables)
6. [Step 4 – Run the Test Script](#step-4--run-the-test-script)
7. [Step 5 – Run the Local /health Flask App](#step-5--run-the-local-health-flask-app)
8. [What the Test Script Verifies](#what-the-test-script-verifies)
9. [Test Output (Expected)](#test-output-expected)
10. [/health Endpoint Live Output](#health-endpoint-live-output)
11. [Stopping / Cleaning Up](#stopping--cleaning-up)
12. [How It Maps to Production](#how-it-maps-to-production)
13. [Troubleshooting](#troubleshooting)

---

## How Redis is Used in This Project

```
┌──────────────────────────────────────────────────────────────────┐
│  Celery Beat Worker  (async/health_registration.py)              │
│  → runs all health checkers every 180 s                          │
│  → writes result JSON  →  Redis key: dataviz:health:result       │
└─────────────────────────────┬────────────────────────────────────┘
                              │  Redis (localhost:6379 locally)
┌─────────────────────────────▼────────────────────────────────────┐
│  Flask API  (api/health_controller.py)                           │
│  → GET /health                                                   │
│  → calls core.health.get_health()                                │
│  → reads pre-computed result from Redis                          │
└──────────────────────────────────────────────────────────────────┘
```

**Key files:**

| File | Redis role |
|------|-----------|
| `Core/health.py` | Builds Redis connection from env vars (`_build_datastore_details`), initialises `PlatformHealthService` |
| `Core/health_checkers.py` | Includes `RedisHealthChecker` — checks Redis itself is reachable |
| `async/health_registration.py` | Registers the Celery beat task that writes to Redis |
| `api/health_controller.py` | Flask endpoint that reads from Redis via `get_health()` |

---

## Prerequisites

| Tool | Check |
|------|-------|
| Docker Desktop (running) | `docker ps` |
| Python 3.8+ | `python --version` |
| pip | `pip --version` |

---

## Step 1 – Start Redis via Docker

```powershell
docker run -d --name redis-local -p 6379:6379 redis:7-alpine
```

**What this does:**
- Pulls the official lightweight `redis:7-alpine` image
- Runs it as a background container named `redis-local`
- Exposes Redis on `localhost:6379` (same default port the project uses)
- No password (matching local dev defaults)

**Verify it is running:**

```powershell
docker ps --filter name=redis-local
```

Expected output:
```
CONTAINER ID   IMAGE            COMMAND                  STATUS          PORTS
8757b7eefc95   redis:7-alpine   "docker-entrypoint.s…"  Up 14 seconds   0.0.0.0:6379->6379/tcp   redis-local
```

---

## Step 2 – Install the Python Redis Client

```powershell
pip install redis
```

The project uses **redis-py** (the standard Python client for Redis). Version installed: **8.0.1**.

Verify:
```powershell
python -c "import redis; print(redis.__version__)"
# 8.0.1
```

---

## Step 3 – Set Environment Variables

The project reads Redis config from environment variables (see `Core/health.py`):

```powershell
# Windows CMD
set REDIS_HOST=localhost
set REDIS_PORT=6379
set REDIS_PASSWORD=

# PowerShell
$env:REDIS_HOST="localhost"
$env:REDIS_PORT="6379"
$env:REDIS_PASSWORD=""
```

> **Note:** For local dev, `REDIS_HOST` defaults to `localhost` and `REDIS_PORT` defaults to `6379` if not set — so for the test script alone these are optional.  
> However, **`REDIS_HOST` is required** (`os.environ["REDIS_HOST"]`) when running the actual app, so always set it.

---

## Step 4 – Run the Test Script

```powershell
python redis_local_test.py
```

---

## Step 5 – Run the Local /health Flask App

`local_health_app.py` is a fully integrated local version of the health service. It starts:

- A **background thread** (simulates Celery beat) that runs all health checkers every 30 seconds and writes the result to Redis under the key `dataviz:health:result`
- A **Flask server** on port 5000 that reads from Redis and serves the result — exactly like `api/health_controller.py`

```powershell
python local_health_app.py
```

**Available endpoints:**

| Endpoint | Description |
|----------|-------------|
| `GET http://localhost:5000/health` | Full health result (mirrors `core.health.get_health()`) |
| `GET http://localhost:5000/health/live` | Liveness probe — just checks Redis is reachable |
| `GET http://localhost:5000/health/redis` | Raw JSON stored in Redis by the writer thread |

**Test from PowerShell:**
```powershell
Invoke-RestMethod -Uri http://localhost:5000/health       | ConvertTo-Json -Depth 5
Invoke-RestMethod -Uri http://localhost:5000/health/live
Invoke-RestMethod -Uri http://localhost:5000/health/redis | ConvertTo-Json -Depth 5
```

---

## What the Test Script Verifies

The script (`redis_local_test.py`) mirrors **exactly** how the project uses Redis:

| Step | What is tested | Mirrors |
|------|---------------|---------|
| **1 / 5** | Connect to Redis and `PING` | `_build_datastore_details()` in `health.py` |
| **2 / 5** | `SET` and `GET` a key with TTL | Basic Redis sanity check |
| **3 / 5** | Write a fake `dataviz:health:result` JSON payload | Celery beat task (`register_task_to_celery`) |
| **4 / 5** | Read back the payload and parse it | `core.health.get_health()` called by Flask API |
| **5 / 5** | Env variable presence check | `REDIS_HOST` / `REDIS_PORT` usage in `health_checkers.py` |

---

## Test Output (Expected)

```
============================================================
  Redis Local Test  –  dataviz health service
============================================================
  Host     : localhost
  Port     : 6379
  Password : (none)
============================================================

[1/5] Connecting to Redis …
      PING → True  ✓

[2/5] SET / GET …
      SET dataviz:test:key = 'hello-redis'  ✓
      GET dataviz:test:key = 'hello-redis'  ✓

[3/5] Simulating platform_health result write (Celery beat side) …
      Wrote fake health payload to 'dataviz:health:result'  ✓

[4/5] Simulating get_health() read (Flask API side) …
      Read back key 'dataviz:health:result'  ✓
      Status  : OK
      App     : dataviz  v1.0.0
      Checks  : ['redis_checker', 'postgres_connectivity', 'kube_cp_connectivity',
                 'myvault_connectivity', 'celery_connectivity', 'dns_connectivity', 'pki_connectivity']

[5/5] Environment variable check (mirrors health_checkers.py) …
      REDIS_HOST  not set → will default to 'localhost' locally ✓
      REDIS_PORT  not set → will default to 6379 locally ✓
      REDIS_PASSWORD not set → no auth (fine for local dev) ✓

============================================================
  ALL TESTS PASSED  ✓  Redis is working correctly.
============================================================
```

---

## /health Endpoint Live Output

These are the **actual responses** from the running `local_health_app.py`:

### `GET /health/live`
```json
{
    "redis": "localhost:6379",
    "status": "UP"
}
```

### `GET /health`
```json
{
    "application": "dataviz",
    "checks": {
        "celery_connectivity": {
            "message": "Not available in local dev environment",
            "status": "SKIPPED",
            "tags": [ "messaging" ]
        },
        "dns_connectivity": {
            "status": "OK",
            "tags": [ "dns", "network" ]
        },
        "kube_cp_connectivity": {
            "message": "Not available in local dev environment",
            "status": "SKIPPED",
            "tags": [ "kube" ]
        },
        "myvault_connectivity": {
            "message": "Not available in local dev environment",
            "status": "SKIPPED",
            "tags": [ "vault" ]
        },
        "pki_connectivity": {
            "message": "Not available in local dev environment",
            "status": "SKIPPED",
            "tags": [ "security", "pki" ]
        },
        "postgres_connectivity": {
            "message": "Not available in local dev environment",
            "status": "SKIPPED",
            "tags": [ "database" ]
        },
        "redis_checker": {
            "status": "OK",
            "tags": [ "redis" ]
        }
    },
    "environment": "local-dev",
    "status": "OK",
    "timestamp": "2026-06-24T16:05:53Z",
    "version": "1.0.0"
}
```

> **SKIPPED** checkers (kube, vault, postgres, celery, pki) are infrastructure services not available locally.  
> **OK** checkers (redis, dns) are the ones that can actually be tested locally.  
> Overall status is **OK** since no checker is `KO` or `DEGRADED`.

---

## Stopping / Cleaning Up

When you are done with local development:

```powershell
docker stop redis-local
docker rm   redis-local
```

To restart later:
```powershell
docker start redis-local
```

---

## How It Maps to Production

| Config | Local (dev) | Production |
|--------|------------|------------|
| `REDIS_HOST` | `localhost` | `dataviz-dev-redis-master` (or similar) |
| `REDIS_PORT` | `6379` | `6379` |
| `REDIS_PASSWORD` | _(empty)_ | Set via secret/env injection |
| Image | `redis:7-alpine` (Docker) | Managed Redis (Kubernetes) |

The code path is identical — only the environment variables change.

---

## Reverting – Going Back to the Previous Way

If you want to completely undo the local Redis setup and go back to the original state (no local Redis, no local Flask app, no extra files), follow these steps:

### 1. Stop and Remove the Redis Docker Container

```powershell
docker stop redis-local
docker rm   redis-local
```

Verify it is gone:
```powershell
docker ps -a --filter name=redis-local
# Should return empty output
```

### 2. Stop the local Flask App

If `local_health_app.py` is still running in a terminal window, close that window or press **Ctrl+C** in it.

### 3. Remove the Local Dev Files (Optional)

These files were created only for local testing — they are **not** part of the real application:

```powershell
Remove-Item "g:\codes\health\local_health_app.py"
Remove-Item "g:\codes\health\redis_local_test.py"
Remove-Item "g:\codes\health\REDIS_LOCAL_SETUP.md"
```

> **Note:** Removing these files has **zero impact** on the actual project source code under `My code/`. They are standalone helper files only.

### 4. Unset the Environment Variables

```powershell
# PowerShell
Remove-Item Env:REDIS_HOST    -ErrorAction SilentlyContinue
Remove-Item Env:REDIS_PORT    -ErrorAction SilentlyContinue
Remove-Item Env:REDIS_PASSWORD -ErrorAction SilentlyContinue
```

```cmd
REM Windows CMD
set REDIS_HOST=
set REDIS_PORT=
set REDIS_PASSWORD=
```

### 5. (Optional) Uninstall redis-py

Only do this if you don't need the redis Python package anywhere else:

```powershell
pip uninstall redis -y
```

### Summary of what is reverted

| What | Action |
|------|--------|
| Redis container | `docker stop redis-local && docker rm redis-local` |
| Local Flask app | Close the terminal running `local_health_app.py` |
| Test/helper files | Delete `local_health_app.py`, `redis_local_test.py`, `REDIS_LOCAL_SETUP.md` |
| Env vars | Unset `REDIS_HOST`, `REDIS_PORT`, `REDIS_PASSWORD` |
| Python package | `pip uninstall redis -y` *(optional)* |

The project source files under `My code/` are **unchanged** throughout — the local setup only adds files alongside them and runs Docker/Python processes externally.

---

## Troubleshooting

### `failed to connect to the docker API`
Docker Desktop is not running. Start it from the Start menu or:
```powershell
Start-Process "C:\Program Files\Docker\Docker\Docker Desktop.exe"
```
Wait ~30 seconds for it to fully start, then retry.

### `ModuleNotFoundError: No module named 'redis'`
```powershell
pip install redis
```

### `[FAIL] Cannot reach Redis at localhost:6379`
The container is not running. Check:
```powershell
docker ps -a --filter name=redis-local
```
If status is `Exited`, start it:
```powershell
docker start redis-local
```
If it doesn't exist yet, run the `docker run` command from Step 1.

### Port 6379 already in use
Another Redis instance may already be running locally. Either stop it, or map a different port:
```powershell
docker run -d --name redis-local -p 6380:6379 redis:7-alpine
# then set:
set REDIS_PORT=6380
```

### `KeyError: 'REDIS_HOST'` when running the actual app
The production code uses `os.environ["REDIS_HOST"]` (not `os.getenv`), so it **will crash** if the variable is missing. Always set it before starting the app:
```powershell
set REDIS_HOST=localhost
```
