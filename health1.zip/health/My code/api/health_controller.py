"""
My code/api/health_controller.py
==================================
Flask /health endpoint — reads pre-computed health data from Redis.

The data is written by the async side (My code/async/app.py) via
PlatformHealthService.write_health().

This controller mirrors the Platform Health Standard format exactly.
"""
from __future__ import annotations

import logging
import os
import sys

# ── Make Core importable ─────────────────────────────────────────────────────
_HERE = os.path.dirname(os.path.abspath(__file__))
_MY_CODE = os.path.dirname(_HERE)          # …/My code
if _MY_CODE not in sys.path:
    sys.path.insert(0, _MY_CODE)

from flask import Flask, jsonify, current_app
from typing import Any, Dict, Tuple

import redis as _redis_lib
from Core.health import PlatformHealthService, _make_redis_client, _build_datastore_details, _HEALTH_KEY

logger = logging.getLogger(__name__)


# ── Reader health service (reads from Redis, no checks) ─────────────────────
_reader_service: PlatformHealthService = None


def _get_reader() -> PlatformHealthService:
    global _reader_service
    if _reader_service is None:
        from Core.health_checkers import HZCheckBase
        _reader_service = PlatformHealthService(
            checkers=[],        # reader needs no checkers
            account_id=os.environ.get("ACCOUNT_ID", "dataviz-local"),
            mode="read",        # never writes, just reads from Redis
        )
    return _reader_service


def health() -> Tuple[Dict[str, Any], int]:
    """GET /health — return Platform Health Standard JSON from Redis."""
    try:
        svc = _get_reader()
        logger.info("Reading health from Redis...")
        health_result = svc.get_health()

        if not health_result:
            logger.warning("Health result is empty — async writer may not have run yet.")
            return {
                "status": "UNKNOWN",
                "message": "Health result not yet available. "
                           "Make sure the async writer (My code/async/app.py) is running.",
            }, 503

        status = health_result.get("status", "UP")
        http_code = 503 if status == "DOWN" else 200
        return health_result, http_code

    except Exception as e:
        logger.error("Error in health endpoint: %s", e, exc_info=True)
        return {"status": "ERROR", "message": str(e)}, 500


def health_live() -> Tuple[Dict[str, Any], int]:
    """GET /health/live — liveness probe, just pings Redis."""
    redis_host = os.environ.get("REDIS_HOST", "localhost")
    redis_port = int(os.getenv("REDIS_PORT", "6379"))
    redis_password = os.getenv("REDIS_PASSWORD", "") or None
    try:
        r = _redis_lib.Redis(
            host=redis_host, port=redis_port,
            password=redis_password,
            socket_connect_timeout=3, decode_responses=True,
        )
        r.ping()
        return {"status": "UP", "redis": f"{redis_host}:{redis_port}"}, 200
    except Exception as exc:
        return {"status": "DOWN", "error": str(exc)}, 503
