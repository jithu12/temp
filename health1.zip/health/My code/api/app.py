"""
My code/api/app.py
===================
Dataviz API entry point — Flask app that exposes the /health endpoint.

The health data is written to Redis by the async side (My code/async/app.py).
This app reads it back and returns Platform Health Standard JSON.

Run (after async/app.py is already writing to Redis):
    set REDIS_HOST=localhost
    python "My code/api/app.py"

Then open: http://localhost:5050/health
"""
from __future__ import annotations

import logging
import os
import sys

# ── Make Core importable ─────────────────────────────────────────────────────
_HERE = os.path.dirname(os.path.abspath(__file__))
_MY_CODE = os.path.dirname(_HERE)          # …/My code
if _MY_CODE not in sys.path:
    sys.path.insert(0, _MY_CODE)

from flask import Flask, jsonify
from api.health_controller import health, health_live   # noqa: E402

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s  %(name)s  %(message)s",
)
logger = logging.getLogger("dataviz_api.app")

# ── Flask app ────────────────────────────────────────────────────────────────
app = Flask("dataviz_api")


@app.route("/health", methods=["GET"])
def health_endpoint():
    result, status_code = health()
    return jsonify(result), status_code


@app.route("/health/live", methods=["GET"])
def health_live_endpoint():
    result, status_code = health_live()
    return jsonify(result), status_code


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    port = int(os.environ.get("API_PORT", "5050"))
    logger.info("=" * 60)
    logger.info("  dataviz API starting")
    logger.info("  Redis  : %s:%s", os.environ.get("REDIS_HOST", "localhost"), os.environ.get("REDIS_PORT", "6379"))
    logger.info("  Endpoints:")
    logger.info("    GET http://localhost:%d/health", port)
    logger.info("    GET http://localhost:%d/health/live", port)
    logger.info("  NOTE: Start async/app.py first so health data is in Redis!")
    logger.info("=" * 60)
    app.run(host="0.0.0.0", port=port, debug=False)
