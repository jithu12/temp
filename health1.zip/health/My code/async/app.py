"""
My code/async/app.py
=====================
Dataviz ASYNC entry point — runs health checks and writes results to Redis.

In production:  This would be a Celery app with beat tasks.
In local dev:   Starts a background thread that runs write_health() every 30s.

Run:
    set REDIS_HOST=localhost
    python "My code/async/app.py"

The health data will appear in Redis under key: dataviz:health:result
The Flask API (My code/api/app.py) reads from this key.
"""
from __future__ import annotations

import logging
import os
import sys
import time

# ── Make Core importable ─────────────────────────────────────────────────────
_HERE = os.path.dirname(os.path.abspath(__file__))
_MY_CODE = os.path.dirname(_HERE)          # …/My code
if _MY_CODE not in sys.path:
    sys.path.insert(0, _MY_CODE)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s  %(name)s  %(message)s",
)
logger = logging.getLogger("dataviz_async.app")

# ── Start the health writer ───────────────────────────────────────────────────
# `async` is a reserved Python keyword, so we load health_registration by path.
import importlib.util as _ilu

_hr_path = os.path.join(_HERE, "health_registration.py")
_spec = _ilu.spec_from_file_location("health_registration", _hr_path)
_hr = _ilu.module_from_spec(_spec)
_spec.loader.exec_module(_hr)
register_platform_health = _hr.register_platform_health

# `app=None` → local dev mode → background thread writer
register_platform_health(app=None)

logger.info("=" * 60)
logger.info("  dataviz async — health writer running")
logger.info("  Redis : %s:%s", os.environ.get("REDIS_HOST", "localhost"), os.environ.get("REDIS_PORT", "6379"))
logger.info("  Key   : dataviz:health:result")
logger.info("  Press Ctrl+C to stop.")
logger.info("=" * 60)

# Keep alive (background thread is daemon=True)
try:
    while True:
        time.sleep(3600)
except KeyboardInterrupt:
    logger.info("dataviz_async stopped.")
    sys.exit(0)
