"""Wire the platform_health writer into the Dataviz async app.

The background writer runs all health checkers on a schedule and writes
the result to Redis — exactly what the Celery beat task does in production.

Usage (called from async/app.py):
    from async.health_registration import register_platform_health
    register_platform_health()
"""
from __future__ import annotations

import logging
import os
import threading
import time

logger = logging.getLogger(__name__)


def register_platform_health(app=None) -> None:
    """Start the platform_health writer.

    If a real Celery ``app`` is provided, registers the task on it.
    Otherwise starts a background thread (local dev mode).
    """
    # Import here to avoid circular imports
    from Core.health import PlatformHealthService
    from Core.health_checkers import (
        ParentStatus,
        RedisHealthChecker,
        SyncAdapterChecker,
    )
    import socket

    redis_host = os.environ.get("REDIS_HOST", "localhost")
    redis_port = int(os.getenv("REDIS_PORT", "6379"))
    redis_password = os.getenv("REDIS_PASSWORD", "")

    def _dns_check():
        socket.gethostbyname("google.com")

    checkers = [
        RedisHealthChecker(
            app_health_status=ParentStatus.DEGRADED,
            module_health_status=ParentStatus.DEGRADED,
            checker_name="redis_checker",
            module_name="application",
            redis_host=redis_host,
            redis_port=redis_port,
            redis_password=redis_password,
            checker_timeout=5,
            tags=["redis"],
        ),
        SyncAdapterChecker(
            check_fn=_dns_check,
            app_health_status=ParentStatus.DEGRADED,
            module_health_status=ParentStatus.DEGRADED,
            checker_name="dns_connectivity",
            module_name="application",
            module_description="DNS resolution",
            checker_timeout=5,
            tags=["dns", "network"],
        ),
    ]

    # Infra checkers — not available locally, always UP (no-op)
    for checker_name, tags, desc in [
        ("kube_cp_connectivity",  ["kube"],             "Kubernetes CP"),
        ("myvault_connectivity",  ["vault"],            "MyVault secret management"),
        ("postgres_connectivity", ["database"],         "PostgreSQL database"),
        ("celery_connectivity",   ["messaging"],        "Celery/RabbitMQ"),
        ("pki_connectivity",      ["security", "pki"],  "PKI/Certificate service"),
    ]:
        checkers.append(
            SyncAdapterChecker(
                check_fn=lambda: None,
                app_health_status=ParentStatus.DEGRADED,
                module_health_status=ParentStatus.DEGRADED,
                checker_name=checker_name,
                module_name="application",
                module_description=f"{desc} (local dev — not available)",
                checker_timeout=5,
                tags=tags,
            )
        )

    health_service = PlatformHealthService(
        checkers=checkers,
        account_id=os.environ.get("ACCOUNT_ID", "dataviz-local"),
        mode="write",   # immediately runs first write on init
    )

    # Try Celery registration
    if app is not None and hasattr(app, "task"):
        try:
            health_service.register_task_to_celery(app)
            logger.info(
                "platform_health periodic task registered on Celery app %r",
                getattr(app, "main", str(app)),
            )
            return health_service
        except Exception as exc:
            logger.warning("Celery registration failed (%s) — using thread writer.", exc)

    # Local dev fallback: background thread
    interval = int(os.getenv("HEALTH_INTERVAL", "30"))

    def _writer():
        logger.info("Health writer thread started (interval=%ds)", interval)
        while True:
            time.sleep(interval)
            try:
                health_service.write_health()
            except Exception as e:
                logger.error("Health writer error: %s", e)

    t = threading.Thread(target=_writer, daemon=True, name="health-writer")
    t.start()
    logger.info(
        "platform_health writer thread started (interval=%ds, redis=%s:%s)",
        interval, redis_host, redis_port,
    )
    return health_service
