"""Health service for Dataviz — Platform Health Standard implementation.

Replaces the ``platform_health`` library with a self-contained implementation
that produces the Platform Health Standard JSON format:

  {
    "description": "...",
    "version":     "...",
    "status":      "UP | DEGRADED | DOWN",
    "time":        "<ISO-8601 timestamp>",
    "comment":     "...",
    "modules": [
      {
        "name":        "<app-name>:<module-name>",
        "description": "...",
        "status":      "UP | DEGRADED | DOWN",
        "tags":        [...],
        "rootcause":   "..."   // only when status != UP
      },
      ...
    ]
  }

Note: Individual checker results are NOT exposed in the JSON.
      Only module-level and application-level status are reported.

Architecture (mirrors the real platform_health library):

  Celery beat worker  →  Health.run_checks()  →  writes JSON  →  Redis
  Flask API           →  Health.get_health()  ←  reads JSON   ←  Redis

Redis configuration is read from environment variables:
  REDIS_HOST     - Redis hostname (default: localhost for local dev)
  REDIS_PORT     - Redis port    (default: 6379)
  REDIS_PASSWORD - Redis password (empty string if no auth)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time as _time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Dict, List, Optional

import redis as _redis_lib

# Import our local checker base-classes (no platform_health needed)
from .health_checkers import HZCheckBase, HZStatus, ParentStatus, create_health_checkers

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from celery import Celery

APP_NAME = "dataviz"
APP_VERSION = "1.0.0"

# Redis key where the health result JSON is stored
_HEALTH_KEY = f"{APP_NAME}:health:result"
# How long (seconds) the key lives before expiring (safety net for stale data)
_HEALTH_TTL = 600


# ─── Redis helpers ────────────────────────────────────────────────────────────

def _build_datastore_details() -> Dict[str, Any]:
    """Build Redis connection config from environment variables."""
    return {
        "backend": "redis",
        "redis_host": os.environ.get("REDIS_HOST", "localhost"),
        "redis_port": int(os.getenv("REDIS_PORT", "6379")),
        "redis_password": os.getenv("REDIS_PASSWORD", ""),
    }


def _make_redis_client(ds: Dict[str, Any]) -> _redis_lib.Redis:
    """Create a redis-py client from datastore_details dict."""
    pwd = ds.get("redis_password") or None
    return _redis_lib.Redis(
        host=ds["redis_host"],
        port=ds["redis_port"],
        password=pwd,
        decode_responses=True,
        socket_connect_timeout=5,
        socket_timeout=5,
    )


# ─── Status roll-up logic ─────────────────────────────────────────────────────

_STATUS_RANK = {ParentStatus.DOWN: 2, ParentStatus.DEGRADED: 1, ParentStatus.UP: 0}


def _worse(a: str, b: str) -> str:
    """Return the more severe of two ParentStatus values."""
    return a if _STATUS_RANK.get(a, 0) >= _STATUS_RANK.get(b, 0) else b


def _hz_to_parent(hz_status: str, on_fail: str) -> str:
    """Map HZStatus result + on_fail policy to a ParentStatus value."""
    if hz_status == HZStatus.OK:
        return ParentStatus.UP
    return on_fail  # DEGRADED or DOWN


# ─── Core Health class ────────────────────────────────────────────────────────

class Health:
    """Platform Health Standard — runs checkers, aggregates by module, stores in Redis.

    Mirrors the public API of the platform_health.Health class so that
    PlatformHealthService (and callers) are unchanged.
    """

    def __init__(
        self,
        application_name: str,
        account_id: str,
        datastore_details: Dict[str, Any],
        version: str = "1.0.0",
    ):
        self._app_name = application_name
        self._account_id = account_id
        self._version = version
        self._datastore = datastore_details
        self._checkers: List[HZCheckBase] = []
        self.logger = logging.getLogger(self.__class__.__name__)

    def register_checks(self, checkers: List[HZCheckBase]) -> None:
        """Register health checker instances."""
        self._checkers = list(checkers)
        self.logger.info("Registered %d health checker(s)", len(self._checkers))

    # ── Internal: run all checks and return aggregated JSON ──────────────────

    async def _run_all_checks(self) -> Dict[str, Any]:
        """Run all checkers concurrently and aggregate into Platform Health JSON."""

        async def _run_one(checker: HZCheckBase):
            try:
                status, message = await asyncio.wait_for(
                    checker.get_hz_health(),
                    timeout=checker.checker_timeout or 30,
                )
            except asyncio.TimeoutError:
                status = HZStatus.KO
                message = f"Checker '{checker.checker_name}' timed out after {checker.checker_timeout}s"
            except Exception as exc:
                status = HZStatus.KO
                message = str(exc)
            return checker, status, message

        results = await asyncio.gather(*[_run_one(c) for c in self._checkers])

        # ── Aggregate per module ──────────────────────────────────────────────
        # modules_map: module_name → {"status": ..., "rootcause": [...], "tags": [...], "description": ...}
        modules_map: Dict[str, Dict[str, Any]] = {}

        app_status = ParentStatus.UP

        for checker, hz_status, message in results:
            # Determine which modules this checker affects
            affected_modules = checker.modules_list if checker.modules_list else [checker.module_name]

            checker_parent_status = _hz_to_parent(hz_status, checker.module_health_status)
            checker_app_impact = _hz_to_parent(hz_status, checker.app_health_status)

            # Roll up app-level status
            app_status = _worse(app_status, checker_app_impact)

            for mod_name in affected_modules:
                if mod_name not in modules_map:
                    modules_map[mod_name] = {
                        "status": ParentStatus.UP,
                        "rootcauses": [],
                        "tags": set(),
                        "description": checker.module_description or mod_name,
                    }

                # Roll up module-level status
                modules_map[mod_name]["status"] = _worse(
                    modules_map[mod_name]["status"], checker_parent_status
                )
                # Collect tags from all checkers in this module
                modules_map[mod_name]["tags"].update(checker.tags)
                # Collect root-cause messages when not OK
                if hz_status != HZStatus.OK and message:
                    modules_map[mod_name]["rootcauses"].append(
                        f"[{checker.checker_name}] {message}"
                    )

        # ── Build the Platform Health Standard payload ────────────────────────
        modules_list = []
        for mod_name, mod_data in sorted(modules_map.items()):
            entry: Dict[str, Any] = {
                "name": f"{self._app_name}:{mod_name}",
                "description": mod_data["description"],
                "status": mod_data["status"],
                "tags": sorted(mod_data["tags"]),
            }
            rootcauses = mod_data["rootcauses"]
            if rootcauses:
                entry["rootcause"] = "; ".join(rootcauses)
            modules_list.append(entry)

        payload: Dict[str, Any] = {
            "description": f"{self._app_name} health status",
            "version": self._version,
            "status": app_status,
            "time": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "comment": f"Computed by {self._app_name} health service (account: {self._account_id})",
            "modules": modules_list,
        }

        return payload

    # ── Public: write health result to Redis ─────────────────────────────────

    def write_health(self) -> None:
        """Run all checks and write the result to Redis.

        This is what the Celery beat task calls on every tick.
        """
        try:
            payload = asyncio.run(self._run_all_checks())
        except RuntimeError:
            # If there's already a running event loop (e.g. inside Celery), use a new thread
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(asyncio.run, self._run_all_checks())
                payload = future.result()

        raw = json.dumps(payload)
        try:
            r = _make_redis_client(self._datastore)
            r.set(_HEALTH_KEY, raw, ex=_HEALTH_TTL)
            self.logger.info(
                "Health written to Redis key '%s' [status=%s, modules=%d]",
                _HEALTH_KEY, payload.get("status"), len(payload.get("modules", [])),
            )
        except _redis_lib.exceptions.RedisError as exc:
            self.logger.error("Failed to write health to Redis: %s", exc)
            raise

    # ── Public: read health result from Redis ────────────────────────────────

    def get_health(self) -> Dict[str, Any]:
        """Read the pre-computed health status from Redis.

        This is what the Flask API calls on every /health request.
        Returns an empty dict (falsy) if no data is available yet.
        """
        try:
            r = _make_redis_client(self._datastore)
            raw = r.get(_HEALTH_KEY)
            if raw is None:
                self.logger.warning(
                    "Health key '%s' not found in Redis — writer may not have run yet.", _HEALTH_KEY
                )
                return {}
            return json.loads(raw)
        except _redis_lib.exceptions.RedisError as exc:
            self.logger.error("Failed to read health from Redis: %s", exc)
            return {}

    # ── Celery integration ────────────────────────────────────────────────────

    def register_task_to_celery(self, app: "Celery", interval: int = 180) -> None:
        """Register the health-check task as a Celery beat periodic task.

        The task runs every ``interval`` seconds and calls ``write_health()``.
        """
        health_instance = self

        @app.task(name="platform_health.run_health_checks", bind=True)
        def _health_task(self_task):
            health_instance.write_health()

        app.conf.beat_schedule = getattr(app.conf, "beat_schedule", {}) or {}
        app.conf.beat_schedule["platform_health_run"] = {
            "task": "platform_health.run_health_checks",
            "schedule": interval,
        }
        self.logger.info(
            "platform_health task registered on Celery app '%s' (interval=%ds)",
            getattr(app, "main", str(app)),
            interval,
        )


# ─── PlatformHealthService ────────────────────────────────────────────────────

class PlatformHealthService:
    """Health service for Dataviz.

    Wraps the ``Health`` class and wires up the checkers.
    Exposes the same public API as before so health_controller.py and core.py
    require no changes.

    Args:
        checkers: List of HZCheckBase instances from health_checkers.py.
        account_id: Service account identifier.
        mode: "read" for Flask API, "write" for Celery worker.
    """

    def __init__(
        self,
        checkers: List[HZCheckBase],
        account_id: str = APP_NAME,
        mode: str = "read",
    ):
        self.logger = logging.getLogger(self.__class__.__name__)
        self._mode = mode

        datastore_details = _build_datastore_details()

        self._health = Health(
            application_name=APP_NAME,
            account_id=account_id,
            datastore_details=datastore_details,
            version=APP_VERSION,
        )

        self._health.register_checks(checkers)
        self.logger.info(
            "PlatformHealthService initialized (mode=%s, redis_host=%s)",
            mode,
            datastore_details["redis_host"],
        )

        # In "write" mode (local dev / testing), do an immediate run so Redis
        # is populated right away without waiting for the first Celery beat tick.
        if mode == "write":
            self.logger.info("mode=write: running initial health check now...")
            try:
                self._health.write_health()
            except Exception as exc:
                self.logger.warning("Initial health write failed (will retry): %s", exc)

    def get_health(self) -> Dict[str, Any]:
        """Return the pre-computed health status from Redis.

        Called by api/health_controller.py on every GET /health request.
        """
        return self._health.get_health()

    def write_health(self) -> None:
        """Run all checks and write result to Redis.

        Called by the Celery beat task registered via register_task_to_celery().
        Can also be called directly for testing.
        """
        self._health.write_health()

    def register_task_to_celery(self, app: "Celery", interval: int = 180) -> None:
        """Register the platform_health periodic task to a Celery app."""
        self._health.register_task_to_celery(app, interval=interval)
