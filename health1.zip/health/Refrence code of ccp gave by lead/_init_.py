#as the file is too large only the part related to platform health is added here    
from typing import Any, Dict, List, Optional

REGIONS: Optional[List[str]] = None,
PLATFORM_HEALTH_DATASTORE_BACKEND: str = "redis",
PLATFORM_HEALTH_REDIS_MASTER_HOST: str = "",
PLATFORM_HEALTH_REDIS_REPLICA_HOST: str = "",
PLATFORM_HEALTH_REDIS_PORT: int = 6379,
PLATFORM_HEALTH_REDIS_PASSWORD: str = "",
self.REGIONS: List[str] = REGIONS if REGIONS is not None else [self.RP_REGION]
self.PLATFORM_HEALTH_DATASTORE_BACKEND = PLATFORM_HEALTH_DATASTORE_BACKEND
self.PLATFORM_HEALTH_REDIS_MASTER_HOST = PLATFORM_HEALTH_REDIS_MASTER_HOST
self.PLATFORM_HEALTH_REDIS_REPLICA_HOST = PLATFORM_HEALTH_REDIS_REPLICA_HOST
self.PLATFORM_HEALTH_REDIS_PORT = PLATFORM_HEALTH_REDIS_PORT
self.PLATFORM_HEALTH_REDIS_PASSWORD = PLATFORM_HEALTH_REDIS_PASSWORD
REGIONS=_parse_regions(data.get("REGIONS", ""), data["RP_REGION"]),
PLATFORM_HEALTH_DATASTORE_BACKEND=data.get(
    "PLATFORM_HEALTH_DATASTORE_BACKEND", "redis"
),
PLATFORM_HEALTH_REDIS_MASTER_HOST=data.get("PLATFORM_HEALTH_REDIS_MASTER_HOST", ""),
PLATFORM_HEALTH_REDIS_REPLICA_HOST=data.get("PLATFORM_HEALTH_REDIS_REPLICA_HOST", ""),
PLATFORM_HEALTH_REDIS_PORT=int(data.get("PLATFORM_HEALTH_REDIS_PORT", "6379")),
PLATFORM_HEALTH_REDIS_PASSWORD=data.get("PLATFORM_HEALTH_REDIS_PASSWORD", ""),

def _parse_regions(regions_str: str, rp_region: str) -> List[str]:
    """Parse comma-separated REGIONS env var, falling back to RP_REGION."""
    if regions_str:
        return [r.strip() for r in regions_str.split(",") if r.strip()]
    return [rp_region]