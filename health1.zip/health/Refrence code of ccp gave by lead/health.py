from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from platform_health import Health, HZCheckBase

from ccp_core.utils.logging import get_default_logger

if TYPE_CHECKING:
    from celery import Celery

    from ccp_core.config import CCPConfig
    from ccp_core.utils.logging import LoggerType


def _build_datastore_details(config: CCPConfig, mode: str) -> Dict[str, Any]:
    """Build datastore configuration based on backend type and read/write mode.

    Args:
        config: CCP configuration.
        mode: "read" to use replica host (Flask API), "write" to use master host (Celery worker).
    """
    if config.PLATFORM_HEALTH_DATASTORE_BACKEND == "memory":
        return {"backend": "memory"}

    redis_host = (
        config.PLATFORM_HEALTH_REDIS_REPLICA_HOST
        if mode == "read"
        else config.PLATFORM_HEALTH_REDIS_MASTER_HOST
    )
    return {
        "backend": "redis",
        "redis_host": redis_host,
        "redis_port": config.PLATFORM_HEALTH_REDIS_PORT,
        "redis_password": config.PLATFORM_HEALTH_REDIS_PASSWORD,
    }


class PlatformHealthService:
    """Health service powered by the platform_health library.

    This service manages health checking for CCP using:
    - Custom checkers for CCP's own infrastructure (DB, RMQ, ES, Kube, S3)
    - HTTP checkers for non-SGCP services (GitHub, Grafana, Harbor, Gino)
    - Upstream SGCP dependency checkers (CaaS, OCS, DNS, MyVault, etc.)

    All checkers are created in health_checkers.py and directly target
    CCP's 5 business modules (application, artifact, deployment,
    environment, proxy) via module_name or modules_list.

    Args:
        config: CCP configuration instance.
        regions: List of deployment regions (e.g. ["eu-fr-paris", "eu-fr-north"]).
        checkers: List of HZCheckBase instances from health_checkers.py.
        mode: "read" for Flask (reads from Redis replica), "write" for Celery (writes to master).
        logger: Optional logger instance.
    """

    def __init__(
        self,
        config: CCPConfig,
        regions: List[str],
        checkers: List[HZCheckBase],
        mode: str = "read",
        logger: Optional[LoggerType] = None,
    ):
        self.logger = logger or get_default_logger(self.__class__.__name__)
        self._config = config
        self._regions = regions

        datastore_details = _build_datastore_details(config, mode)

        self._health = Health(
            application_name=config.APP_NAME,
            account_id=config.EVENTBUS_ACCOUNT_ID,
            datastore_details=datastore_details,
            version="1.0.0",
        )

        self._health.register_checks(checkers)
        self.logger.info(
            f"PlatformHealthService initialized (mode={mode}, "
            f"backend={config.PLATFORM_HEALTH_DATASTORE_BACKEND})"
        )

    def get_health(self) -> Dict[str, Any]:
        """Get the current health status from the datastore."""
        return self._health.get_health()

    def register_task_to_celery(self, app: Celery, interval: int = 180) -> None:
        """Register the health check periodic task to a Celery app."""
        self._health.register_task_to_celery(app, interval=interval)