from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Callable, Dict, List, Optional, Tuple

import aiohttp
import kubernetes.client as k8s
from platform_health import (
    HTTPChecker,
    HZCheckBase,
    HZStatus,
    RedisHealthChecker,
)
from platform_health.utils import ParentStatus

from ccp_core.errors.exceptions import (
    HealthCheckError,
    KubeClientError,
    PostgresError,
    RabbitMQError,
    S3ClientError,
)

if TYPE_CHECKING:
    from opensearchpy import OpenSearch

    from ccp_core.adapters.kube_client import KubeClient
    from ccp_core.adapters.os_config_client import OSConfigClient
    from ccp_core.adapters.pki_client import PKIClient
    from ccp_core.adapters.rmq_declare_change_adapter import RMQDeclareChangeAdapter
    from ccp_core.adapters.s3_client import S3Client


class SyncAdapterChecker(HZCheckBase):
    """Wraps a synchronous check function into an async health checker.

    All CCP adapters are synchronous (requests-based). This base class
    runs the check in a thread executor to avoid blocking the asyncio loop.
    """

    def __init__(
        self,
        check_fn: Callable[[], None],
        app_health_status: ParentStatus,
        module_health_status: ParentStatus,
        checker_name: str,
        module_name: Optional[str] = None,
        modules_list: Optional[List[str]] = None,
        module_description: Optional[str] = None,
        checker_timeout: Optional[int] = None,
        tags: Optional[List[str]] = None,
    ):
        super().__init__(
            app_health_status=app_health_status,
            module_health_status=module_health_status,
            checker_name=checker_name,
            module_name=module_name,
            modules_list=modules_list,
            module_description=module_description,
            checker_timeout=checker_timeout,
            tags=tags,
        )
        self._check_fn = check_fn

    async def get_hz_health(self) -> Tuple[HZStatus, str]:
        try:
            # Use asyncio.to_thread to run the blocking check function in a thread
            await asyncio.to_thread(self._check_fn)
            return HZStatus.OK, ""
        except Exception as e:
            return HZStatus.KO, str(e)


def _create_postgres_checker(db_uri: str) -> SyncAdapterChecker:
    """Check CCP's own PostgreSQL database connectivity."""
    from sqlalchemy import create_engine

    engine = create_engine(db_uri, pool_pre_ping=True)

    def check() -> None:
        try:
            conn = engine.connect()
            conn.close()
        except Exception as e:
            raise PostgresError(str(e)) from e

    return SyncAdapterChecker(
        check_fn=check,
        app_health_status=ParentStatus.DOWN,
        module_health_status=ParentStatus.DOWN,
        checker_name="postgres_checker",
        modules_list=["application", "artifact", "deployment", "environment", "proxy"],
        checker_timeout=10,
        tags=["database"],
    )


def _create_rabbitmq_checker(connection_uri: str) -> SyncAdapterChecker:
    """Check CCP's own RabbitMQ broker connectivity."""
    import pika

    def check() -> None:
        try:
            params = pika.URLParameters(connection_uri)
            params.socket_timeout = 5
            connection = pika.BlockingConnection(params)
            connection.close()
        except Exception as e:
            raise RabbitMQError(str(e)) from e

    return SyncAdapterChecker(
        check_fn=check,
        app_health_status=ParentStatus.DOWN,
        module_health_status=ParentStatus.DOWN,
        checker_name="rabbitmq_checker",
        modules_list=["application", "artifact", "deployment", "environment", "proxy"],
        checker_timeout=10,
        tags=["messaging"],
    )


def _create_elastic_checker(
    es_clients: dict[str, OpenSearch], regions: List[str]
) -> SyncAdapterChecker:
    """Check CCP's own Elasticsearch cluster connectivity across all regions."""

    def check() -> None:
        errors = []
        for region in regions:
            client = es_clients.get(region)
            if client is None:
                errors.append(f"No Elasticsearch client configured for region {region}")
                continue
            if not client.ping():
                errors.append(f"Elasticsearch cluster for {region} did not respond to ping")
        if errors:
            raise HealthCheckError("; ".join(errors))

    return SyncAdapterChecker(
        check_fn=check,
        app_health_status=ParentStatus.DEGRADED,
        module_health_status=ParentStatus.DOWN,
        checker_name="elastic_checker",
        modules_list=["environment", "deployment"],
        checker_timeout=10,
        tags=["elastic"],
    )


def _create_kube_checker(kube_client: KubeClient) -> SyncAdapterChecker:
    """Check Kubernetes API server connectivity across all configured clusters."""

    def check() -> None:
        errors = []
        for cluster_name, kube_conf in kube_client.configurations.items():
            try:
                config = kube_conf.get_config()
                with k8s.ApiClient(config) as client:
                    api = k8s.VersionApi(client)
                    api.get_code()
            except Exception as e:
                errors.append(f"{cluster_name}: {e}")
        if errors:
            raise KubeClientError("; ".join(errors))

    return SyncAdapterChecker(
        check_fn=check,
        app_health_status=ParentStatus.DEGRADED,
        module_health_status=ParentStatus.DOWN,
        checker_name="kube_checker",
        modules_list=["application", "deployment", "environment"],
        checker_timeout=10,
        tags=["kubernetes"],
    )


def _create_s3_checker(s3_client: S3Client) -> SyncAdapterChecker:
    """Check S3 connectivity."""

    def check() -> None:
        try:
            s3_client.client.list_buckets()
        except Exception as e:
            raise S3ClientError(str(e)) from e

    return SyncAdapterChecker(
        check_fn=check,
        app_health_status=ParentStatus.DEGRADED,
        module_health_status=ParentStatus.DEGRADED,
        checker_name="s3_checker",
        module_name="artifact",
        module_description="Artifact and image management",
        checker_timeout=10,
        tags=["storage"],
    )

def _create_github_checkers(api_url: str) -> HTTPChecker:
        """Check GitHub API reachability (auth not required for health).

        Returns a checkers for GitHub.
        """

        return HTTPChecker(
            checker_name="github_application_checker",
            module_name="artifact",
            app_health_status=ParentStatus.DEGRADED,
            module_health_status=ParentStatus.DEGRADED,
            module_description="GitHub API",
            checker_timeout=10,
            tags=["github"],
            url=api_url,
            allowed_status_codes=[200, 401, 403],
        )


def _create_gino_checker(gino_url: str) -> HTTPChecker:
    """Check Gino reachability (no /health endpoint available)."""
    return HTTPChecker(
        app_health_status=ParentStatus.DEGRADED,
        module_health_status=ParentStatus.DEGRADED,
        checker_name="gino_checker",
        module_name="deployment",
        module_description="Deployment management",
        checker_timeout=10,
        tags=["gino"],
        url=gino_url,
        allowed_status_codes=[200, 401, 403],
    )


def _create_grafana_checker(grafana_url: str) -> HTTPChecker:
    """Check Grafana reachability."""
    return HTTPChecker(
        app_health_status=ParentStatus.DEGRADED,
        module_health_status=ParentStatus.DEGRADED,
        checker_name="grafana_checker",
        module_name="deployment",
        module_description="Deployment management",
        checker_timeout=10,
        tags=["monitoring"],
        url=grafana_url,
        allowed_status_codes=[200, 401, 403],
    )


def _create_harbor_checkers(harbor_health_urls: Dict[str, str]) -> List[HTTPChecker]:
    """Check Harbor registry health endpoint for each region."""
    checkers = []
    for region, url in harbor_health_urls.items():
        suffix = f"_{region}" if len(harbor_health_urls) > 1 else ""
        checkers.append(
            HTTPChecker(
                app_health_status=ParentStatus.DEGRADED,
                module_health_status=ParentStatus.DOWN,
                checker_name=f"harbor_checker{suffix}",
                module_name="artifact",
                module_description="Artifact and image management",
                checker_timeout=10,
                tags=["registry"],
                url=url,
                allowed_status_codes=[200],
            )
        )
    return checkers


def _create_os_config_checker(os_config_client: OSConfigClient) -> SyncAdapterChecker:
    """Check OS Config (CMaaS) service connectivity."""

    def check() -> None:
        try:
            os_config_client.list_modules(region="eu-fr-paris", account="prd")
        except Exception as e:
            raise HealthCheckError(f"OSConfig service error: {e}") from e

    return SyncAdapterChecker(
        check_fn=check,
        app_health_status=ParentStatus.DEGRADED,
        module_health_status=ParentStatus.DEGRADED,
        checker_name="os_config_checker",
        module_name="proxy",
        checker_timeout=10,
        tags=["os_config"],
    )


def _create_pki_checker(pki_client: PKIClient) -> SyncAdapterChecker:
    """Check PKI service connectivity."""

    def check() -> None:
        try:
            pki_client.get_names(account="prd")
        except Exception as e:
            raise HealthCheckError(f"PKI service error: {e}") from e

    return SyncAdapterChecker(
        check_fn=check,
        app_health_status=ParentStatus.DEGRADED,
        module_health_status=ParentStatus.DEGRADED,
        checker_name="pki_checker",
        modules_list=["environment", "proxy"],
        checker_timeout=10,
        tags=["pki"],
    )


def _create_rmq_declare_change_checker(
    declare_change_adapter: RMQDeclareChangeAdapter,
) -> SyncAdapterChecker:
    """Check RMQ Declare Change connectivity (separate from main RMQ broker)."""
    import pika

    def check() -> None:
        try:
            params = pika.URLParameters(declare_change_adapter.connection_uri)
            params.socket_timeout = 5
            connection = pika.BlockingConnection(params)
            connection.close()
        except Exception as e:
            raise RabbitMQError(f"RMQ DeclareChange error: {e}") from e

    return SyncAdapterChecker(
        check_fn=check,
        app_health_status=ParentStatus.DEGRADED,
        module_health_status=ParentStatus.DEGRADED,
        checker_name="rmq_declare_change_checker",
        module_name="deployment",
        checker_timeout=10,
        tags=["rmq_declare_change"],
    )


def _create_redis_checker(
    redis_host: str,
    redis_port: int,
    checker_name: str,
    module_name: str,
    checker_timeout: int = 5,
    module_description: Optional[str] = None,
    tags: Optional[list] = None,
) -> RedisHealthChecker:
    """Create a Redis health checker (degraded on failure)."""
    return RedisHealthChecker(
        app_health_status=ParentStatus.DEGRADED,
        module_health_status=ParentStatus.DEGRADED,
        checker_name=checker_name,
        module_name=module_name,
        redis_host=redis_host,
        redis_port=redis_port,
        checker_timeout=checker_timeout,
        module_description=module_description,
        tags=tags or ["redis"],
    )


def _redis_checkers(
    redis_master_host: Optional[str],
    redis_replica_host: Optional[str],
    redis_port: int,
) -> List[RedisHealthChecker]:
    checkers: List[RedisHealthChecker] = []
    if redis_master_host:
        checkers.append(
            _create_redis_checker(
                redis_host=redis_master_host,
                redis_port=redis_port,
                checker_name="redis_master_checker",
                module_name="internal",
                tags=["redis", "master"],
            )
        )
    if redis_replica_host:
        checkers.append(
            _create_redis_checker(
                redis_host=redis_replica_host,
                redis_port=redis_port,
                checker_name="redis_replica_checker",
                module_name="internal",
                tags=["redis", "replica"],
            )
        )

class UpstreamHTTPChecker(HZCheckBase):
    """Checks upstream SGCP service reachability via their /health endpoint.

    Unlike HTTPChecker, this supports modules_list so a single checker
    can affect multiple CCP business modules without duplicate HTTP calls.
    """

    def __init__(
        self,
        checker_name: str,
        url: str,
        modules_list: List[str],
        tags: Optional[List[str]] = None,
        checker_timeout: Optional[int] = 10,
    ):
        super().__init__(
            app_health_status=ParentStatus.DEGRADED,
            module_health_status=ParentStatus.DEGRADED,
            checker_name=checker_name,
            modules_list=modules_list,
            checker_timeout=checker_timeout,
            tags=tags,
        )
        self.url = url

    async def get_hz_health(self) -> Tuple[HZStatus, str]:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    self.url, timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    if response.ok:
                        return HZStatus.OK, ""
                    return HZStatus.KO, f"HTTP {response.status}"
        except Exception as e:
            return HZStatus.KO, str(e)


# Upstream SGCP service dependency configurations.
# Each entry: (url_template, modules_list mapping to CCP business modules)
_UPSTREAM_REGIONAL = {
    "caas": ("https://kube.{region}.cloud.socgen/v3/health", ["application"]),
    "ocs": ("https://ocs.{region}.cloud.socgen/v0/health", ["proxy"]),
    "slb": ("https://api.slb.{region}.cloud.socgen/v1/health", ["proxy"]),
    "pcp": (
        "https://pcp.{region}.cloud.socgen/v2/health",
        ["application", "environment"],
    ),
    "dns": ("https://dns.{region}.cloud.socgen/v2/health", ["environment", "proxy"]),
    "metrology": ("https://metrology.{region}.cloud.socgen/v5/health", ["application"]),
    "osf": ("https://osf.{region}.cloud.socgen/v1/health", ["proxy"]),
    "tm": ("https://tm.{region}.cloud.socgen/v2/health", ["application", "proxy"]),
}

_UPSTREAM_GLOBAL = {
    "acl": ("https://acl.cloud.socgen/v3/health", ["internal"]),
    "secret": ("https://secret.cloud.socgen/v1/health", ["internal"]),
    "myvault": (
        "https://myvault.cloud.socgen/v1/health",
        ["application", "artifact", "deployment", "environment", "proxy"],
    ),
    "certificate": (
        "https://certificate.cloud.socgen/v2/health",
        ["environment", "proxy"],
    ),
}


def _create_upstream_checkers(regions: List[str]) -> List[HZCheckBase]:
    """Create health checkers for all upstream SGCP service dependencies.

    Each checker calls the upstream /health endpoint. Its result is
    propagated to the CCP business modules listed in modules_list.
    """
    checkers: List[HZCheckBase] = []

    for region in regions:
        suffix = f"_{region}" if len(regions) > 1 else ""
        for name, (url_template, modules) in _UPSTREAM_REGIONAL.items():
            checkers.append(
                UpstreamHTTPChecker(
                    checker_name=f"{name}_checker{suffix}",
                    url=url_template.format(region=region),
                    modules_list=modules,
                    tags=[name],
                )
            )

    for name, (url, modules) in _UPSTREAM_GLOBAL.items():
        checkers.append(
            UpstreamHTTPChecker(
                checker_name=f"{name}_checker",
                url=url,
                modules_list=modules,
                tags=[name],
            )
        )

    return checkers


def create_health_checkers(
    db_uri: str,
    rabbit_connection_uri: str,
    es_clients: dict[str, OpenSearch],
    regions: List[str],
    kube_client: KubeClient,
    s3_client: S3Client,
    harbor_health_urls: Dict[str, str],
    github_api_url: str = "https://sgithub.fr.world.socgen/api/v3",
    gino_url: str = "https://gino.cloud.socgen/v2/documentation/",
    grafana_url: str = "https://ccp-dataviz.eu-fr-paris.cloud.socgen/metrics",
    os_config_client: Optional[OSConfigClient] = None,
    pki_client: Optional[PKIClient] = None,
    declare_change_adapter: Optional[RMQDeclareChangeAdapter] = None,
    redis_master_host: Optional[str] = None,
    redis_replica_host: Optional[str] = None,
    redis_port: int = 6379,
) -> List[HZCheckBase]:
    """Create all health checkers for CCP.

    This includes:
    - Custom checkers for CCP's own infrastructure (DB, RMQ, ES, Kube, S3)
    - HTTP checkers for non-SGCP services (GitHub, Grafana, Harbor, Gino)
    - SDK-based dependency checkers (optional - only added if adapter is provided)
    - Upstream SGCP dependency checkers (CaaS, OCS, DNS, MyVault, etc.)
    """
    checkers: List[HZCheckBase] = [
        # Custom checkers - CCP's own infrastructure
        _create_postgres_checker(db_uri),
        _create_rabbitmq_checker(rabbit_connection_uri),
        _create_elastic_checker(es_clients, regions),
        _create_kube_checker(kube_client),
        _create_s3_checker(s3_client),
        *_redis_checkers(redis_master_host, redis_replica_host, redis_port),
        _create_github_checkers(github_api_url),
        _create_gino_checker(gino_url),
        _create_grafana_checker(grafana_url),
        *_create_harbor_checkers(harbor_health_urls),
        # Upstream SGCP dependency checkers
        *_create_upstream_checkers(regions),
    ]

    # SDK-based dependency checkers (optional - only added if adapter is provided)
    if os_config_client is not None:
        checkers.append(_create_os_config_checker(os_config_client))
    if pki_client is not None:
        checkers.append(_create_pki_checker(pki_client))
    if declare_change_adapter is not None:
        checkers.append(_create_rmq_declare_change_checker(declare_change_adapter))

    return checkers