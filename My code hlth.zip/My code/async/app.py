from dataviz_async.health_registration import register_platform_health

register_platform_health(app)
