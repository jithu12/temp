"""Wire the platform_health Celery task into the Dataviz async app.

The platform_health library registers its own periodic task that executes
every registered checker on the Celery beat schedule and writes results to
Redis. We delegate that registration here so the async app module stays
focused on its existing tasks.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from dataviz_async.core import get_core

if TYPE_CHECKING:
    from celery import Celery

logger = logging.getLogger(__name__)


def register_platform_health(app: "Celery") -> None:
    """Attach the platform_health periodic task to ``app``."""
    core = get_core(app)
    core.health.register_task_to_celery(app)
    logger.info("platform_health periodic task registered on Celery app %r", app.main)
