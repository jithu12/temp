# This module is no longer needed.
# Import ParentStatus directly from the platform_health library:
#
#   from platform_health.utils import ParentStatus
