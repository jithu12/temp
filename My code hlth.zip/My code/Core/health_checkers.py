"""Custom health checkers for Dataviz service dependencies.

Each external dependency is checked via a factory function that returns a
SyncAdapterChecker instance. The SyncAdapterChecker base class wraps any
synchronous client call into an async health check, avoiding boilerplate.

Call ``create_health_checkers(...)`` to obtain the full list to pass to
PlatformHealthService.
"""

from __future__ import annotations

import asyncio
import os
from typing import TYPE_CHECKING, Callable, List, Optional, Tuple

from platform_health import HZCheckBase, HZStatus, RedisHealthChecker
from platform_health.utils import ParentStatus

if TYPE_CHECKING:
    from dataviz_core.adapters.celery_workflow_executor import CeleryWorkflowExecutor
    from dataviz_core.adapters.dns_client import DNSClient
    from dataviz_core.adapters.kube_cp_client import KubeCPClient
    from dataviz_core.adapters.myvault_client import MyVaultClient
    from dataviz_core.adapters.pki_client import PKIClient
    from dataviz_core.adapters.postgres_cp_client import PostgresClient

MODULE_NAME = "application"


class SyncAdapterChecker(HZCheckBase):
    """Wraps a synchronous check function into an async health checker.

    All Dataviz adapters are synchronous (requests-based). This base class
    runs the check in a thread executor to avoid blocking the asyncio loop.
    """

    def __init__(
        self,
        check_fn: Callable[[], None],
        app_health_status: ParentStatus,
        module_health_status: ParentStatus,
        checker_name: str,
        module_name: Optional[str] = None,
        modules_list: Optional[List[str]] = None,
        module_description: Optional[str] = None,
        checker_timeout: Optional[int] = None,
        tags: Optional[List[str]] = None,
    ):
        super().__init__(
            app_health_status=app_health_status,
            module_health_status=module_health_status,
            checker_name=checker_name,
            module_name=module_name,
            modules_list=modules_list,
            module_description=module_description,
            checker_timeout=checker_timeout,
            tags=tags,
        )
        self._check_fn = check_fn

    async def get_hz_health(self) -> Tuple[HZStatus, str]:
        try:
            await asyncio.to_thread(self._check_fn)
            return HZStatus.OK, ""
        except Exception as e:
            return HZStatus.KO, str(e)


def _create_kube_checker(kube_client: "KubeCPClient") -> SyncAdapterChecker:
    """Check Kubernetes CP client connectivity."""

    def check() -> None:
        list(kube_client.get_clusters())

    return SyncAdapterChecker(
        check_fn=check,
        app_health_status=ParentStatus.DEGRADED,
        module_health_status=ParentStatus.DEGRADED,
        checker_name="kube_cp_connectivity",
        module_name=MODULE_NAME,
        module_description="Kubernetes Orchestrated Containers service connectivity",
        checker_timeout=10,
        tags=["kube"],
    )


def _create_vault_checker(vault_client: "MyVaultClient") -> SyncAdapterChecker:
    """Check MyVault secret management service connectivity."""

    def check() -> None:
        vault_client.list_namespaces()

    return SyncAdapterChecker(
        check_fn=check,
        app_health_status=ParentStatus.DEGRADED,
        module_health_status=ParentStatus.DEGRADED,
        checker_name="myvault_connectivity",
        module_name=MODULE_NAME,
        module_description="MyVault secret management service connectivity",
        checker_timeout=10,
        tags=["vault"],
    )


def _create_postgres_checker(postgres_client: "PostgresClient") -> SyncAdapterChecker:
    """Check PostgreSQL database client initialization."""

    def check() -> None:
        if postgres_client.controller is None:
            raise RuntimeError("PostgresClient controller is not initialized")

    return SyncAdapterChecker(
        check_fn=check,
        app_health_status=ParentStatus.DOWN,
        module_health_status=ParentStatus.DOWN,
        checker_name="postgres_connectivity",
        module_name=MODULE_NAME,
        module_description="PostgreSQL database service connectivity",
        checker_timeout=10,
        tags=["database"],
    )


def _create_celery_checker(celery_executor: "CeleryWorkflowExecutor") -> SyncAdapterChecker:
    """Check Celery broker connectivity via worker ping."""

    def check() -> None:
        inspect = celery_executor.app.control.inspect()
        result = inspect.ping()
        if result is None:
            raise RuntimeError("No response from Celery broker")

    return SyncAdapterChecker(
        check_fn=check,
        app_health_status=ParentStatus.DEGRADED,
        module_health_status=ParentStatus.DEGRADED,
        checker_name="celery_connectivity",
        module_name=MODULE_NAME,
        module_description="Celery/RabbitMQ message queue connectivity",
        checker_timeout=10,
        tags=["messaging"],
    )


def _create_dns_checker(dns_client: "DNSClient") -> SyncAdapterChecker:
    """Check internal DNS resolution service."""

    def check() -> None:
        dns_client.resolve("kubernetes.default.svc.cluster.local")

    return SyncAdapterChecker(
        check_fn=check,
        app_health_status=ParentStatus.DEGRADED,
        module_health_status=ParentStatus.DEGRADED,
        checker_name="dns_connectivity",
        module_name=MODULE_NAME,
        module_description="Internal DNS resolution service",
        checker_timeout=5,
        tags=["dns", "network"],
    )


def _create_pki_checker(pki_client: "PKIClient") -> SyncAdapterChecker:
    """Check PKI/Certificate service and certificate validity."""

    def check() -> None:
        is_valid = pki_client.verify_cert()
        if not is_valid:
            raise RuntimeError("Certificate validation failed or expiring soon")

    return SyncAdapterChecker(
        check_fn=check,
        app_health_status=ParentStatus.DEGRADED,
        module_health_status=ParentStatus.DEGRADED,
        checker_name="pki_connectivity",
        module_name=MODULE_NAME,
        module_description="Internal PKI/Certificate service",
        checker_timeout=10,
        tags=["security", "pki"],
    )


def create_health_checkers(
    kube_client: "KubeCPClient",
    vault_client: "MyVaultClient",
    postgres_client: "PostgresClient",
    celery_executor: "CeleryWorkflowExecutor",
    dns_client: "DNSClient",
    pki_client: "PKIClient",
) -> List[HZCheckBase]:
    """Create all health checkers for the Dataviz service."""
    return [
        _create_kube_checker(kube_client),
        _create_vault_checker(vault_client),
        _create_postgres_checker(postgres_client),
        _create_celery_checker(celery_executor),
        _create_dns_checker(dns_client),
        _create_pki_checker(pki_client),
        # Built-in Redis checker — verifies the datastore used by platform_health is reachable.
        RedisHealthChecker(
            app_health_status=ParentStatus.DEGRADED,
            module_health_status=ParentStatus.DEGRADED,
            checker_name="redis_checker",
            module_name=MODULE_NAME,
            redis_host=os.environ["REDIS_HOST"],
            redis_port=int(os.getenv("REDIS_PORT", "6379")),
            checker_timeout=5,
            tags=["redis"],
        ),
    ]
