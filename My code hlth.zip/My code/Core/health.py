"""Health service for Dataviz using the platform_health library.

The Celery beat task (registered via ``register_task_to_celery``) runs
all checkers on a schedule and writes results to Redis. The Flask API
reads the pre-computed result from Redis via ``get_health()``.

Redis configuration is read from environment variables:
  REDIS_HOST     - Redis hostname (e.g. dataviz-dev-redis-master)
  REDIS_PORT     - Redis port (default: 6379)
  REDIS_PASSWORD - Redis password (empty string if no auth)
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from platform_health import Health, HZCheckBase

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from celery import Celery

APP_NAME = "dataviz"
APP_VERSION = "1.0.0"


def _build_datastore_details() -> Dict[str, Any]:
    """Build Redis datastore configuration from environment variables.

    Standalone Redis (no Sentinel, same host for read and write).
    """
    return {
        "backend": "redis",
        "redis_host": os.environ["REDIS_HOST"],
        "redis_port": int(os.getenv("REDIS_PORT", "6379")),
        "redis_password": os.getenv("REDIS_PASSWORD", ""),
    }


class PlatformHealthService:
    """Health service powered by the platform_health library.

    Args:
        checkers: List of HZCheckBase instances from health_checkers.py.
        account_id: Service account identifier.
        mode: "read" for Flask API, "write" for Celery worker.
    """

    def __init__(
        self,
        checkers: List[HZCheckBase],
        account_id: str = APP_NAME,
        mode: str = "read",
    ):
        self.logger = logging.getLogger(self.__class__.__name__)

        datastore_details = _build_datastore_details()

        self._health = Health(
            application_name=APP_NAME,
            account_id=account_id,
            datastore_details=datastore_details,
            version=APP_VERSION,
        )

        self._health.register_checks(checkers)
        self.logger.info(
            "PlatformHealthService initialized (mode=%s, redis_host=%s)",
            mode,
            datastore_details["redis_host"],
        )

    def get_health(self) -> Dict[str, Any]:
        """Return the pre-computed health status from Redis."""
        return self._health.get_health()

    def register_task_to_celery(self, app: "Celery", interval: int = 180) -> None:
        """Register the platform_health periodic task to a Celery app."""
        self._health.register_task_to_celery(app, interval=interval)
