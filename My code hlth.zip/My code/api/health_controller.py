from flask import current_app
from typing import Any, Dict, Tuple
import logging

from dataviz_api.core import get_core

logger = logging.getLogger(__name__)


def health() -> Tuple[Dict[str, Any], int]:
    try:
        core = get_core(current_app)
        logger.info("Getting health from core.health service")

        health_result = core.health.get_health()

        logger.info(f"Health result type: {type(health_result)}")
        logger.info(f"Health result: {health_result}")

        if not health_result:
            logger.warning("Health result is empty or None!")
            return {"status": "UNKNOWN", "message": "Health check returned empty result"}, 500

        return health_result, 200
    except Exception as e:
        logger.error(f"Error in health endpoint: {e}", exc_info=True)
        return {"status": "ERROR", "message": str(e)}, 500