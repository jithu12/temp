"""
Skribbl-style multiplayer drawing & guessing game — team edition.

v2 changes:
- Admin role with hardcoded password (separate /admin login)
- Teams replace individual scoring
- Room locking
- Admin actions: start, lock, assign teams, skip round, deduct points, kick
- Chat restrictions: drawer's team cannot chat during drawing

Run: python app.py
"""

import threading
import time
from datetime import datetime
from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit, join_room as sio_join_room, leave_room as sio_leave_room

from game_logic import database, game_engine
from game_logic.profanity import contains_profanity, censor


# ---- Hardcoded admin password (per spec) ----
ADMIN_PASSWORD = 'admin123'


# ---- App setup ----
app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev-secret-change-me'
socketio = SocketIO(app, cors_allowed_origins='*', async_mode='threading')


# ============================================================
# HTTP routes
# ============================================================

@app.route('/')
def index():
    """Player landing — nickname + room code."""
    return render_template('index.html')


@app.route('/admin')
def admin():
    """Admin login page (separate from player flow)."""
    return render_template('admin.html')


@app.route('/game')
def game():
    """Player game page."""
    return render_template('game.html')


@app.route('/admin/panel')
def admin_panel():
    """Admin control panel."""
    return render_template('admin_panel.html')


@app.route('/api/admin_login', methods=['POST'])
def admin_login():
    """Verify admin password and create/return a room."""
    data = request.json or {}
    password = data.get('password', '')
    room_code = (data.get('room_code') or '').strip().upper()

    if password != ADMIN_PASSWORD:
        return jsonify({'error': 'Invalid admin password'}), 401

    if room_code:
        # Admin joining an existing room
        room = game_engine.get_room(room_code)
        if not room:
            return jsonify({'error': 'Room not found'}), 404
        return jsonify({'room_code': room_code})

    # Otherwise, create a new room
    room = game_engine.create_room()
    return jsonify({'room_code': room.code})


@app.route('/api/check_room/<room_code>', methods=['GET'])
def check_room(room_code):
    """Validate room code before navigating to /game."""
    room = game_engine.get_room(room_code.upper())
    if not room:
        return jsonify({'exists': False}), 404
    return jsonify({
        'exists': True,
        'in_progress': room.state != 'WAITING',
        'locked': room.room_locked,
    })


# ============================================================
# Socket helpers
# ============================================================

def get_player_info(sid):
    """Return the (room_code, nickname, is_admin) for a sid, or None."""
    return game_engine.sid_to_player.get(sid)


def emit_room_update(room):
    """Broadcast the latest room snapshot to all sockets in the room."""
    socketio.emit('player_list_update', room.to_dict(), room=room.code)


# ============================================================
# Connection events
# ============================================================

@socketio.on('connect')
def handle_connect():
    print(f'[connect] sid={request.sid}')


@socketio.on('disconnect')
def handle_disconnect():
    sid = request.sid
    if sid not in game_engine.sid_to_player:
        return

    info = game_engine.sid_to_player.pop(sid)
    room_code = info['room_code']
    room = game_engine.get_room(room_code)
    if not room:
        return

    if info.get('is_admin'):
        room.remove_admin(sid)
        print(f'[disconnect] admin left {room_code}')
        return

    nickname = info['nickname']
    room.mark_disconnected(nickname)
    print(f'[disconnect] {nickname} from {room_code}')
    emit_room_update(room)

    # If drawer disconnects mid-round, give them a grace period to reconnect
    # (handles page refreshes without crashing the game for everyone)
    if room.state in ('CHOOSING_WORD', 'DRAWING') and room.current_drawer == nickname:
        threading.Thread(
            target=drawer_disconnect_grace,
            args=(room_code, nickname),
            daemon=True,
        ).start()


def drawer_disconnect_grace(room_code, nickname):
    """Wait a few seconds before ending the round — the drawer might just be refreshing."""
    time.sleep(5)
    room = game_engine.get_room(room_code)
    if not room:
        return
    # If the drawer reconnected within the grace period, do nothing
    if nickname in room.players and room.players[nickname].connected:
        return
    # Still disconnected — end the round
    if room.state in ('CHOOSING_WORD', 'DRAWING') and room.current_drawer == nickname:
        end_current_round(room, reason='drawer_left')


# ============================================================
# Player events
# ============================================================

@socketio.on('join_room')
def handle_join_room(data):
    """Player joining the lobby."""
    nickname = (data.get('nickname') or '').strip()
    room_code = (data.get('room_code') or '').strip().upper()

    if not nickname or not room_code:
        emit('error', {'message': 'Nickname and room code required'})
        return
    if len(nickname) > 20:
        emit('error', {'message': 'Nickname too long'})
        return
    if contains_profanity(nickname):
        emit('error', {'message': 'Nickname contains inappropriate language'})
        return

    room = game_engine.get_room(room_code)
    if not room:
        emit('error', {'message': 'Room not found'})
        return

    # NEW: room locking
    if room.room_locked and nickname not in room.players:
        emit('error', {'message': 'Game already started'})
        return

    # In-progress games allow reconnects only
    if room.state != 'WAITING' and nickname not in room.players:
        emit('error', {'message': 'Game already started'})
        return

    if (nickname in room.players and room.players[nickname].connected
            and room.players[nickname].sid != request.sid):
        emit('error', {'message': 'Nickname already in use in this room'})
        return

    room.add_player(nickname, request.sid)
    sio_join_room(room_code)
    game_engine.sid_to_player[request.sid] = {
        'room_code': room_code,
        'nickname': nickname,
        'is_admin': False,
    }

    emit('joined_room', {
        'room_code': room_code,
        'nickname': nickname,
        'room_state': room.to_dict(),
    })
    emit_room_update(room)

    # Reconnect into mid-round
    if room.state == 'DRAWING':
        is_drawer = (nickname == room.current_drawer)
        emit('round_in_progress', {
            'drawer': room.current_drawer,
            'drawing_team_id': room.current_drawing_team_id,
            'word_blanks': room.get_word_blanks(),
            'time_remaining': int(room.get_time_remaining()),
            'word': room.current_word if is_drawer else None,
            'canvas_history': room.canvas_history,
        })

    print(f'[join_room] {nickname} joined {room_code}')


@socketio.on('admin_join')
def handle_admin_join(data):
    """
    Admin connecting to socket. Validates password, registers as invisible admin.
    Admins are NOT in the player list and cannot draw/guess/chat.
    """
    password = data.get('password', '')
    room_code = (data.get('room_code') or '').strip().upper()

    if password != ADMIN_PASSWORD:
        emit('error', {'message': 'Invalid admin password'})
        return

    room = game_engine.get_room(room_code)
    if not room:
        emit('error', {'message': 'Room not found'})
        return

    room.add_admin(request.sid)
    sio_join_room(room_code)
    game_engine.sid_to_player[request.sid] = {
        'room_code': room_code,
        'nickname': '__admin__',
        'is_admin': True,
    }

    emit('admin_joined', {
        'room_code': room_code,
        'room_state': room.to_dict(),
    })

    # If a round is in progress, send admin the current word for monitoring
    if room.state == 'DRAWING':
        emit('admin_round_info', {
            'drawer': room.current_drawer,
            'drawing_team_id': room.current_drawing_team_id,
            'word': room.current_word,
            'time_remaining': int(room.get_time_remaining()),
        })

    print(f'[admin_join] admin connected to {room_code}')


# ============================================================
# Admin actions
# ============================================================

def _require_admin(sid):
    """Helper: returns (room, info) if sid is a valid admin in a room, else None."""
    info = game_engine.sid_to_player.get(sid)
    if not info or not info.get('is_admin'):
        return None
    room = game_engine.get_room(info['room_code'])
    if not room:
        return None
    return room


@socketio.on('admin_setup_teams')
def handle_admin_setup_teams(data):
    """Admin sets up teams before starting. Auto-assigns players evenly."""
    room = _require_admin(request.sid)
    if not room:
        emit('error', {'message': 'Admin only'})
        return
    if room.state != 'WAITING':
        emit('error', {'message': 'Cannot change teams after game started'})
        return

    team_count = int(data.get('team_count', 2))
    room.setup_teams(team_count)
    emit_room_update(room)


@socketio.on('admin_reassign_player')
def handle_admin_reassign(data):
    """Admin moves a player between teams."""
    room = _require_admin(request.sid)
    if not room:
        return
    if room.state != 'WAITING':
        emit('error', {'message': 'Cannot reassign after game started'})
        return

    nickname = data.get('nickname')
    new_team_id = data.get('team_id')
    if room.reassign_player(nickname, int(new_team_id)):
        emit_room_update(room)


@socketio.on('admin_lock_room')
def handle_admin_lock(data):
    """Toggle room lock — when locked, no new players can join."""
    room = _require_admin(request.sid)
    if not room:
        return
    room.room_locked = bool(data.get('locked', True))
    emit_room_update(room)
    socketio.emit('chat_message', {
        'nickname': 'System',
        'message': f"Room {'locked' if room.room_locked else 'unlocked'} by admin.",
        'system': True,
    }, room=room.code)


@socketio.on('admin_start_game')
def handle_admin_start():
    """Admin starts the game. Validates teams are set up properly."""
    room = _require_admin(request.sid)
    if not room:
        return

    if not room.teams:
        emit('error', {'message': 'Set up teams first'})
        return

    if not room.can_start():
        emit('error', {'message': 'Need at least 2 players, all teams must have at least 1'})
        return

    # Auto-lock when game starts (admin can manually unlock if desired)
    room.room_locked = True
    room.start_game()
    socketio.emit('game_started', {'total_rounds': room.total_rounds}, room=room.code)
    emit_room_update(room)
    start_next_round(room)


@socketio.on('admin_skip_round')
def handle_admin_skip():
    """Admin skips the current round."""
    room = _require_admin(request.sid)
    if not room:
        return
    if room.state not in ('CHOOSING_WORD', 'DRAWING'):
        emit('error', {'message': 'No active round to skip'})
        return

    socketio.emit('chat_message', {
        'nickname': 'System',
        'message': '⏭️ Round skipped by admin.',
        'system': True,
    }, room=room.code)
    end_current_round(room, reason='admin_skipped')


@socketio.on('admin_penalty')
def handle_admin_penalty(data):
    """Admin deducts points from a team."""
    room = _require_admin(request.sid)
    if not room:
        return
    team_id = int(data.get('team_id'))
    points = int(data.get('points', 0))
    if points <= 0:
        emit('error', {'message': 'Penalty must be positive'})
        return
    if not room.apply_penalty(team_id, points):
        emit('error', {'message': 'Team not found'})
        return
    team = room.teams.get(team_id)
    socketio.emit('chat_message', {
        'nickname': 'System',
        'message': f"⚠️ Admin deducted {points} points from {team.name if team else 'team'}.",
        'system': True,
    }, room=room.code)
    socketio.emit('team_scores_update', {
        'teams': room.get_team_leaderboard(),
    }, room=room.code)


@socketio.on('admin_bonus')
def handle_admin_bonus(data):
    """Admin adds points to a team."""
    room = _require_admin(request.sid)
    if not room:
        return
    team_id = int(data.get('team_id'))
    points = int(data.get('points', 0))
    if points <= 0:
        emit('error', {'message': 'Points must be positive'})
        return
    if not room.apply_bonus(team_id, points):
        emit('error', {'message': 'Team not found'})
        return
    team = room.teams.get(team_id)
    socketio.emit('chat_message', {
        'nickname': 'System',
        'message': f"🎁 Admin awarded {points} points to {team.name if team else 'team'}.",
        'system': True,
    }, room=room.code)
    socketio.emit('team_scores_update', {
        'teams': room.get_team_leaderboard(),
    }, room=room.code)


@socketio.on('admin_kick_player')
def handle_admin_kick(data):
    """Admin kicks a player from the room."""
    room = _require_admin(request.sid)
    if not room:
        return
    nickname = data.get('nickname')
    if nickname not in room.players:
        return

    # Find their sid so we can disconnect them cleanly
    target_sid = room.players[nickname].sid
    is_current_drawer = (room.current_drawer == nickname)

    # Tell them they were kicked, then yank their socket
    socketio.emit('kicked', {'message': 'You were removed by admin.'}, room=target_sid)

    # Remove from sid map
    if target_sid in game_engine.sid_to_player:
        del game_engine.sid_to_player[target_sid]

    room.remove_player(nickname)
    emit_room_update(room)
    socketio.emit('chat_message', {
        'nickname': 'System',
        'message': f"🚫 {nickname} was kicked by admin.",
        'system': True,
    }, room=room.code)

    # If they were drawing, end the round
    if is_current_drawer and room.state in ('CHOOSING_WORD', 'DRAWING'):
        end_current_round(room, reason='drawer_kicked')


# ============================================================
# Game flow
# ============================================================

def start_next_round(room):
    """Set up next round and notify everyone."""
    if not room.next_round():
        end_game(room)
        return

    drawer_player = room.players.get(room.current_drawer)
    drawing_team = room.teams.get(room.current_drawing_team_id)

    # Drawer gets word choices privately
    if drawer_player:
        socketio.emit('word_choices', {
            'words': room.word_choices,
            'round_number': room.round_number,
            'total_rounds': room.total_rounds,
        }, room=drawer_player.sid)

    # Public broadcast: who's drawing + which team is drawing
    socketio.emit('start_round', {
        'drawer': room.current_drawer,
        'drawing_team_id': room.current_drawing_team_id,
        'drawing_team_name': drawing_team.name if drawing_team else '',
        'drawing_team_color': drawing_team.color if drawing_team else '',
        'round_number': room.round_number,
        'total_rounds': room.total_rounds,
        'state': 'CHOOSING_WORD',
    }, room=room.code)


@socketio.on('select_word')
def handle_select_word(data):
    """Drawer picks a word; transition to DRAWING and start the timer."""
    info = get_player_info(request.sid)
    if not info or info.get('is_admin'):
        return
    room = game_engine.get_room(info['room_code'])
    if not room:
        return
    if info['nickname'] != room.current_drawer:
        return

    word = data.get('word', '')
    if not room.select_word(word):
        emit('error', {'message': 'Invalid word selection'})
        return

    socketio.emit('round_drawing_start', {
        'word_blanks': room.get_word_blanks(),
        'time_remaining': game_engine.ROUND_TIME,
    }, room=room.code)
    socketio.emit('your_word', {'word': room.current_word}, room=request.sid)

    # Notify admins of the actual word for monitoring
    for admin_sid in room.admin_sids:
        socketio.emit('admin_round_info', {
            'drawer': room.current_drawer,
            'drawing_team_id': room.current_drawing_team_id,
            'word': room.current_word,
            'time_remaining': game_engine.ROUND_TIME,
        }, room=admin_sid)

    threading.Thread(target=round_timer, args=(room.code,), daemon=True).start()


def round_timer(room_code):
    time.sleep(game_engine.ROUND_TIME)
    room = game_engine.get_room(room_code)
    if room and room.state == 'DRAWING':
        end_current_round(room, reason='time_up')


def end_current_round(room, reason='time_up'):
    if room.state not in ('DRAWING', 'CHOOSING_WORD'):
        return

    word = room.current_word
    room.state = 'ROUND_END'

    socketio.emit('end_round', {
        'word': word,
        'reason': reason,
        'team_leaderboard': room.get_team_leaderboard(),
        'correct_guessers': room.correct_guessers,
    }, room=room.code)

    threading.Thread(target=delayed_next_round, args=(room.code,), daemon=True).start()


def delayed_next_round(room_code):
    time.sleep(5)
    room = game_engine.get_room(room_code)
    if room and room.state == 'ROUND_END':
        start_next_round(room)


def end_game(room):
    """Game over. Persist team scores, broadcast results, reset for new game."""
    team_results = [(t.name, t.color, t.score) for t in room.teams.values()]

    try:
        database.save_game_history(
            room.code,
            room.started_at or datetime.now(),
            room.total_rounds,
            team_results,
        )
    except Exception as e:
        print(f'[end_game] failed to save history: {e}')

    socketio.emit('game_over', {
        'team_leaderboard': room.get_team_leaderboard(),
    }, room=room.code)

    # Reset for potential next game
    room.state = 'WAITING'
    room.round_number = 0
    room.total_rounds = 0
    room.current_drawer = None
    room.current_drawing_team_id = None
    room.current_word = None
    for t in room.teams.values():
        t.score = 0
    for p in room.players.values():
        p.has_guessed = False


# ============================================================
# Drawing events
# ============================================================

@socketio.on('draw_event')
def handle_draw_event(data):
    info = get_player_info(request.sid)
    if not info or info.get('is_admin'):
        return  # admin cannot draw
    room = game_engine.get_room(info['room_code'])
    if not room or room.state != 'DRAWING':
        return
    if info['nickname'] != room.current_drawer:
        return

    room.add_canvas_event(data)
    emit('draw_data', data, room=room.code, include_self=False)


@socketio.on('clear_canvas')
def handle_clear_canvas():
    info = get_player_info(request.sid)
    if not info or info.get('is_admin'):
        return
    room = game_engine.get_room(info['room_code'])
    if not room or info['nickname'] != room.current_drawer:
        return
    room.canvas_history.append({'type': 'clear'})
    emit('canvas_cleared', {}, room=room.code, include_self=False)


# ============================================================
# Chat / guess events
# ============================================================

@socketio.on('guess_event')
def handle_guess(data):
    info = get_player_info(request.sid)
    if not info:
        return

    # Admins cannot chat (they're invisible to players)
    if info.get('is_admin'):
        emit('chat_message', {
            'nickname': 'System',
            'message': 'Admin cannot chat in the game.',
            'system': True,
        })
        return

    room = game_engine.get_room(info['room_code'])
    if not room:
        return

    nickname = info['nickname']
    message = (data.get('message') or '').strip()
    if not message:
        return
    if len(message) > 200:
        message = message[:200]

    # Enforce chat restrictions at the BACKEND level (per spec)
    if not room.can_chat(nickname):
        # Different reason messages for clarity
        if nickname == room.current_drawer:
            reason = "You can't chat while drawing."
        else:
            reason = "Your team can't chat while one of you is drawing."
        emit('chat_message', {
            'nickname': 'System',
            'message': reason,
            'system': True,
        })
        return

    clean_message = censor(message)

    # Check for correct guess
    is_correct, points = room.check_guess(nickname, message)

    if is_correct:
        team = room.get_player_team(nickname)
        socketio.emit('correct_guess', {
            'nickname': nickname,
            'team_name': team.name if team else '',
            'team_color': team.color if team else '',
            'points': points,
            'team_leaderboard': room.get_team_leaderboard(),
        }, room=room.code)
        socketio.emit('your_guess_correct', {
            'word': room.current_word,
            'points': points,
        }, room=request.sid)

        if room.all_non_drawing_teams_guessed():
            end_current_round(room, reason='all_guessed')
        return

    # Not a correct guess — broadcast as normal chat (with team color)
    team = room.get_player_team(nickname)
    socketio.emit('chat_message', {
        'nickname': nickname,
        'message': clean_message,
        'team_color': team.color if team else None,
        'team_name': team.name if team else None,
        'system': False,
    }, room=room.code)


@socketio.on('leave_room')
def handle_leave_room():
    info = get_player_info(request.sid)
    if not info:
        return
    del game_engine.sid_to_player[request.sid]
    room = game_engine.get_room(info['room_code'])
    if not room:
        return

    if info.get('is_admin'):
        room.remove_admin(request.sid)
    else:
        room.remove_player(info['nickname'])
        sio_leave_room(info['room_code'])
        if (room.state in ('CHOOSING_WORD', 'DRAWING')
                and room.current_drawer == info['nickname']):
            end_current_round(room, reason='drawer_left')

    if not room.players and not room.admin_sids:
        game_engine.delete_room(info['room_code'])
    else:
        emit_room_update(room)


# ============================================================
# Background cleanup
# ============================================================

def cleanup_loop():
    while True:
        time.sleep(30)
        try:
            removed = game_engine.cleanup_inactive_players()
            for room_code, nickname in removed:
                room = game_engine.get_room(room_code)
                if room:
                    emit_room_update(room)
                    socketio.emit('chat_message', {
                        'nickname': 'System',
                        'message': f'{nickname} was removed (inactive)',
                        'system': True,
                    }, room=room_code)
        except Exception as e:
            print(f'[cleanup] error: {e}')


# ============================================================
# Entry point
# ============================================================

if __name__ == '__main__':
    database.init_db()
    threading.Thread(target=cleanup_loop, daemon=True).start()
    print('Skribbl game (team edition) running on http://localhost:5000')
    print(f'Admin login: http://localhost:5000/admin (password: {ADMIN_PASSWORD})')
    socketio.run(app, host='0.0.0.0', port=5000, debug=False, allow_unsafe_werkzeug=True)
