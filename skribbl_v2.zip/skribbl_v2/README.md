# Draw & Guess — Team Edition (v2)

A multiplayer drawing & guessing game with **team-based gameplay** and an **admin control panel**.

## What's new in v2

| Area | Change |
|---|---|
| **Admin role** | Hardcoded password (`admin123`), separate `/admin` login. Admins are invisible to players — not on any team, can't draw, guess, or chat. |
| **Teams** | Players are distributed into 2-4 teams. Scoring is per team, not per player. |
| **Room locking** | Admin can lock/unlock the room; locked rooms reject new joiners with "Game already started". Auto-locks on game start. |
| **Drawer selection** | Each round, the engine picks a team first, then a player from that team. A banner announces "TEAM RED IS DRAWING". |
| **Chat restrictions** | Drawer + their entire team **cannot chat** during DRAWING. Only opposing teams can guess. Enforced at the backend. |
| **Penalty system** | Admin can deduct points from any team in real time. |
| **Word list** | 412 words in SQLite (was ~80). |
| **Guidelines screen** | Modal explains rules + chat restrictions on first visit. |
| **Canvas** | Larger (900×650), with a clear gray wrapper background so you can see the canvas edges while drawing. |

## Setup

```bash
pip install -r requirements.txt
python app.py
```

Open **http://localhost:5000** for players, **http://localhost:5000/admin** for admin login (password: `admin123`).

## Workflow

1. **Admin** creates a room at `/admin` → gets a 6-char room code.
2. **Players** join the room at `/` using the code.
3. **Admin** picks team count (2-4), clicks **Apply Teams** to auto-distribute, then **Start Game**.
4. Game runs round by round; admin can **skip**, **kick**, **deduct points**, or **reassign teams** mid-pre-game.

## Team distribution math

- `team_size = total_players // team_count`
- `extras = total_players % team_count`
- First `extras` teams get one extra player.

Example: 7 players into 3 teams → sizes 3, 2, 2.

## Project structure

```
skribbl_v2/
├── app.py                          # Flask + SocketIO server, all event handlers
├── requirements.txt
├── game_logic/
│   ├── database.py                 # SQLite: words (412), team_scores, game_history
│   ├── game_engine.py              # In-memory rooms/teams/players + game flow
│   ├── scoring.py                  # Team-based scoring rules
│   └── profanity.py                # Substring blocklist
├── templates/
│   ├── index.html                  # Player landing
│   ├── admin.html                  # Admin login
│   ├── game.html                   # Player game page
│   └── admin_panel.html            # Admin control panel
└── static/
    ├── css/style.css
    └── js/
        ├── index.js                # Player landing
        ├── admin_login.js          # Admin login
        ├── game.js                 # Player game (canvas, chat, teams)
        └── admin_panel.js          # Admin controls
```

## Key SocketIO events

### Player → Server
- `join_room` — join a lobby
- `select_word` — drawer picks word
- `draw_event`, `clear_canvas` — canvas updates (drawer only)
- `guess_event` — chat message / guess
- `leave_room`

### Admin → Server
- `admin_join` — authenticate as admin
- `admin_setup_teams` — create N teams, auto-distribute players
- `admin_reassign_player` — move player to another team
- `admin_lock_room` — toggle lock
- `admin_start_game`, `admin_skip_round`
- `admin_penalty` — deduct points
- `admin_kick_player`

### Server → Clients
- `joined_room`, `admin_joined`
- `player_list_update` — full room snapshot (teams, players, state, lock flag)
- `start_round`, `word_choices`, `your_word`, `round_drawing_start`
- `draw_data`, `canvas_cleared`
- `chat_message`, `correct_guess`, `your_guess_correct`
- `team_scores_update` — broadcast after a penalty
- `admin_round_info` — current word (admins only)
- `end_round`, `game_over`
- `kicked` — sent to a kicked player's socket
- `error`

## Edge cases handled

- **Player disconnects** → marked offline, removed from team after 60s timeout.
- **Drawer disconnects mid-round** → round ends immediately.
- **Empty team in rotation** → that team's drawer slots are skipped.
- **Drawer kicked** → round ends.

## Configuration knobs (in code)

- `ADMIN_PASSWORD` — `app.py` (default `admin123`)
- `ROUND_TIME` — `game_engine.py` (default 60s)
- `WORD_CHOICES` — `game_engine.py` (default 3)
- `ROUNDS_PER_PLAYER` — `game_engine.py` (default 2)
- `MAX_GUESS_POINTS` / `MIN_GUESS_POINTS` / `DRAWER_TEAM_POINTS_PER_GUESS` — `scoring.py`
