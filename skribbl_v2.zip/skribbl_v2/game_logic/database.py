"""
Database module for the Skribbl game (team edition).

Handles SQLite persistence for:
- Words list (400+ entries, used for word selection)
- Game history (finished rooms)
- Team scores (final scores per team per finished game)

Real-time game state lives in memory (see game_engine.py).
"""

import sqlite3
import os
from datetime import datetime
from contextlib import contextmanager

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'game.db')


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    """Create tables if they don't exist, then seed words on first run."""
    with get_conn() as conn:
        c = conn.cursor()

        c.execute('''
            CREATE TABLE IF NOT EXISTS words (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                word TEXT UNIQUE NOT NULL,
                difficulty TEXT DEFAULT 'medium'
            )
        ''')

        c.execute('''
            CREATE TABLE IF NOT EXISTS game_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                room_code TEXT NOT NULL,
                started_at TIMESTAMP NOT NULL,
                ended_at TIMESTAMP NOT NULL,
                total_rounds INTEGER NOT NULL,
                team_count INTEGER NOT NULL
            )
        ''')

        # Team scores replace per-player scores from v1.
        c.execute('''
            CREATE TABLE IF NOT EXISTS team_scores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                game_id INTEGER NOT NULL,
                team_name TEXT NOT NULL,
                team_color TEXT NOT NULL,
                score INTEGER NOT NULL,
                FOREIGN KEY (game_id) REFERENCES game_history(id)
            )
        ''')

        # Re-seed if we have fewer than 400 words (handles upgrades from v1's smaller list)
        c.execute('SELECT COUNT(*) as count FROM words')
        if c.fetchone()['count'] < 400:
            seed_words(conn)


def seed_words(conn):
    """
    Insert a 400+ word starter pack.
    INSERT OR IGNORE keeps re-runs safe and lets us extend the list later.
    """
    words = [
        # ---- Animals (50) ----
        ('cat', 'easy'), ('dog', 'easy'), ('elephant', 'easy'), ('fish', 'easy'),
        ('lion', 'easy'), ('monkey', 'easy'), ('tiger', 'easy'), ('bear', 'easy'),
        ('rabbit', 'easy'), ('horse', 'easy'), ('cow', 'easy'), ('pig', 'easy'),
        ('sheep', 'easy'), ('chicken', 'easy'), ('duck', 'easy'), ('frog', 'easy'),
        ('snake', 'easy'), ('owl', 'easy'), ('eagle', 'easy'), ('parrot', 'easy'),
        ('penguin', 'medium'), ('giraffe', 'medium'), ('octopus', 'medium'),
        ('butterfly', 'medium'), ('dolphin', 'medium'), ('whale', 'medium'),
        ('shark', 'medium'), ('crocodile', 'medium'), ('zebra', 'medium'),
        ('panda', 'medium'), ('koala', 'medium'), ('fox', 'medium'),
        ('wolf', 'medium'), ('bee', 'medium'), ('spider', 'medium'),
        ('crab', 'medium'), ('lobster', 'medium'), ('squirrel', 'medium'),
        ('hedgehog', 'medium'), ('turtle', 'easy'),
        ('kangaroo', 'hard'), ('platypus', 'hard'), ('rhinoceros', 'hard'),
        ('hippo', 'hard'), ('chameleon', 'hard'), ('flamingo', 'hard'),
        ('peacock', 'hard'), ('porcupine', 'hard'), ('armadillo', 'hard'),
        ('jellyfish', 'hard'), ('seahorse', 'hard'),

        # ---- Food & Drink (55) ----
        ('pizza', 'easy'), ('burger', 'easy'), ('apple', 'easy'), ('banana', 'easy'),
        ('orange', 'easy'), ('grape', 'easy'), ('lemon', 'easy'), ('cherry', 'easy'),
        ('strawberry', 'easy'), ('watermelon', 'easy'), ('bread', 'easy'),
        ('cheese', 'easy'), ('milk', 'easy'), ('cake', 'easy'),
        ('cookie', 'easy'), ('donut', 'easy'), ('chocolate', 'easy'),
        ('coffee', 'easy'), ('tea', 'easy'), ('juice', 'easy'),
        ('sandwich', 'medium'), ('spaghetti', 'medium'), ('sushi', 'medium'),
        ('pancake', 'medium'), ('waffle', 'medium'), ('taco', 'medium'),
        ('burrito', 'medium'), ('hotdog', 'medium'), ('salad', 'medium'),
        ('soup', 'medium'), ('noodles', 'medium'), ('rice', 'medium'),
        ('bacon', 'medium'), ('steak', 'medium'), ('fries', 'medium'),
        ('popcorn', 'medium'), ('pretzel', 'medium'), ('pineapple', 'medium'),
        ('avocado', 'medium'), ('mushroom', 'medium'),
        ('cappuccino', 'hard'), ('croissant', 'hard'), ('lasagna', 'hard'),
        ('quesadilla', 'hard'), ('cheesecake', 'hard'), ('macaron', 'hard'),
        ('hamburger', 'easy'), ('pumpkin', 'medium'), ('coconut', 'medium'),
        ('blueberry', 'medium'), ('raspberry', 'medium'), ('peach', 'easy'),
        ('pear', 'easy'), ('mango', 'easy'), ('honey', 'easy'),

        # ---- Objects/Household (55) ----
        ('chair', 'easy'), ('book', 'easy'), ('phone', 'easy'), ('clock', 'easy'),
        ('lamp', 'easy'), ('table', 'easy'), ('bed', 'easy'), ('door', 'easy'),
        ('window', 'easy'), ('key', 'easy'), ('cup', 'easy'), ('plate', 'easy'),
        ('spoon', 'easy'), ('fork', 'easy'), ('knife', 'easy'), ('bowl', 'easy'),
        ('bag', 'easy'), ('hat', 'easy'), ('shoe', 'easy'), ('sock', 'easy'),
        ('umbrella', 'medium'), ('telescope', 'medium'),
        ('camera', 'medium'), ('television', 'medium'), ('computer', 'medium'),
        ('keyboard', 'medium'), ('headphones', 'medium'),
        ('speaker', 'medium'), ('refrigerator', 'medium'), ('toaster', 'medium'),
        ('blender', 'medium'), ('vacuum', 'medium'), ('mirror', 'medium'),
        ('candle', 'medium'), ('toothbrush', 'medium'), ('scissors', 'medium'),
        ('hammer', 'medium'), ('screwdriver', 'medium'), ('pencil', 'easy'),
        ('pen', 'easy'),
        ('typewriter', 'hard'), ('chandelier', 'hard'), ('binoculars', 'hard'),
        ('thermometer', 'hard'), ('calculator', 'hard'), ('microscope', 'hard'),
        ('stethoscope', 'hard'), ('chainsaw', 'hard'),
        ('broom', 'easy'), ('mop', 'easy'), ('bucket', 'easy'),
        ('basket', 'easy'), ('pillow', 'easy'), ('blanket', 'easy'),
        ('curtain', 'medium'), ('rug', 'easy'),

        # ---- Nature & Weather (40) ----
        ('tree', 'easy'), ('flower', 'easy'), ('grass', 'easy'), ('leaf', 'easy'),
        ('rock', 'easy'), ('mountain', 'easy'), ('sun', 'easy'), ('moon', 'easy'),
        ('star', 'easy'), ('cloud', 'easy'), ('rain', 'easy'), ('snow', 'easy'),
        ('fire', 'easy'), ('water', 'easy'), ('river', 'easy'),
        ('rainbow', 'medium'), ('volcano', 'medium'), ('waterfall', 'medium'),
        ('lightning', 'medium'), ('thunder', 'medium'), ('storm', 'medium'),
        ('hurricane', 'medium'), ('tornado', 'medium'), ('earthquake', 'medium'),
        ('beach', 'medium'), ('ocean', 'medium'), ('forest', 'medium'),
        ('desert', 'medium'), ('island', 'medium'), ('cave', 'medium'),
        ('canyon', 'hard'), ('glacier', 'hard'), ('iceberg', 'hard'),
        ('tsunami', 'hard'), ('avalanche', 'hard'), ('savanna', 'hard'),
        ('peninsula', 'hard'), ('archipelago', 'hard'), ('stalactite', 'hard'),
        ('aurora', 'hard'),

        # ---- Vehicles & Transport (30) ----
        ('car', 'easy'), ('bike', 'easy'), ('bus', 'easy'), ('train', 'easy'),
        ('plane', 'easy'), ('boat', 'easy'), ('truck', 'easy'), ('ship', 'easy'),
        ('rocket', 'easy'), ('helicopter', 'medium'), ('motorcycle', 'medium'),
        ('skateboard', 'medium'), ('scooter', 'medium'), ('tractor', 'medium'),
        ('submarine', 'medium'), ('ambulance', 'medium'), ('firetruck', 'medium'),
        ('taxi', 'medium'), ('van', 'medium'), ('limousine', 'medium'),
        ('hovercraft', 'hard'), ('zeppelin', 'hard'), ('snowmobile', 'hard'),
        ('catamaran', 'hard'), ('locomotive', 'hard'), ('parachute', 'hard'),
        ('bulldozer', 'medium'), ('forklift', 'medium'), ('jetski', 'medium'),
        ('sailboat', 'medium'),

        # ---- Activities & Sports (40) ----
        ('swimming', 'medium'), ('dancing', 'medium'), ('cooking', 'medium'),
        ('singing', 'easy'), ('reading', 'easy'), ('writing', 'easy'),
        ('running', 'easy'), ('jumping', 'easy'), ('walking', 'easy'),
        ('sleeping', 'easy'), ('eating', 'easy'), ('drinking', 'easy'),
        ('basketball', 'medium'), ('football', 'medium'), ('baseball', 'medium'),
        ('tennis', 'medium'), ('golf', 'medium'), ('hockey', 'medium'),
        ('soccer', 'medium'), ('volleyball', 'medium'), ('badminton', 'medium'),
        ('bowling', 'medium'), ('boxing', 'medium'), ('wrestling', 'medium'),
        ('skiing', 'medium'), ('snowboarding', 'medium'), ('surfing', 'medium'),
        ('skating', 'medium'), ('cycling', 'medium'), ('hiking', 'medium'),
        ('camping', 'medium'), ('fishing', 'medium'), ('hunting', 'medium'),
        ('archery', 'hard'), ('fencing', 'hard'), ('gymnastics', 'hard'),
        ('skydiving', 'hard'), ('paragliding', 'hard'), ('snorkeling', 'hard'),
        ('yoga', 'easy'),

        # ---- Fantasy/Characters (30) ----
        ('robot', 'easy'), ('dragon', 'medium'), ('wizard', 'medium'),
        ('castle', 'medium'), ('pirate', 'medium'), ('ninja', 'easy'),
        ('vampire', 'medium'), ('astronaut', 'medium'), ('mermaid', 'medium'),
        ('unicorn', 'easy'), ('fairy', 'easy'), ('ghost', 'easy'),
        ('zombie', 'easy'), ('witch', 'easy'), ('knight', 'easy'),
        ('king', 'easy'), ('queen', 'easy'), ('prince', 'easy'),
        ('princess', 'easy'), ('dwarf', 'medium'), ('elf', 'medium'),
        ('goblin', 'medium'), ('troll', 'medium'), ('werewolf', 'medium'),
        ('phoenix', 'hard'), ('griffin', 'hard'), ('centaur', 'hard'),
        ('minotaur', 'hard'), ('cyclops', 'hard'), ('leprechaun', 'hard'),

        # ---- Body Parts (20) ----
        ('hand', 'easy'), ('foot', 'easy'), ('eye', 'easy'), ('ear', 'easy'),
        ('nose', 'easy'), ('mouth', 'easy'), ('tooth', 'easy'), ('hair', 'easy'),
        ('finger', 'easy'), ('toe', 'easy'), ('arm', 'easy'), ('leg', 'easy'),
        ('head', 'easy'), ('heart', 'easy'), ('brain', 'medium'),
        ('skeleton', 'medium'), ('muscle', 'medium'), ('eyebrow', 'medium'),
        ('shoulder', 'medium'), ('knee', 'easy'),

        # ---- Clothing & Accessories (20) ----
        ('shirt', 'easy'), ('pants', 'easy'), ('dress', 'easy'),
        ('jacket', 'easy'), ('coat', 'easy'), ('sweater', 'easy'),
        ('skirt', 'easy'), ('tie', 'easy'), ('belt', 'easy'),
        ('glove', 'easy'), ('scarf', 'easy'), ('boot', 'easy'),
        ('sunglasses', 'medium'), ('necklace', 'medium'),
        ('bracelet', 'medium'), ('ring', 'easy'), ('crown', 'medium'),
        ('helmet', 'medium'), ('backpack', 'medium'), ('wallet', 'medium'),

        # ---- Music & Instruments (15) ----
        ('guitar', 'easy'), ('piano', 'easy'), ('drum', 'easy'),
        ('violin', 'medium'), ('flute', 'medium'), ('trumpet', 'medium'),
        ('saxophone', 'medium'), ('harp', 'medium'), ('accordion', 'hard'),
        ('clarinet', 'hard'), ('xylophone', 'hard'), ('harmonica', 'hard'),
        ('banjo', 'medium'), ('cello', 'medium'), ('tambourine', 'medium'),

        # ---- Buildings & Places (25) ----
        ('house', 'easy'), ('school', 'easy'), ('hospital', 'easy'),
        ('library', 'easy'), ('church', 'easy'), ('shop', 'easy'),
        ('park', 'easy'), ('zoo', 'easy'), ('farm', 'easy'),
        ('factory', 'medium'), ('airport', 'medium'), ('station', 'medium'),
        ('lighthouse', 'hard'), ('cathedral', 'hard'), ('skyscraper', 'hard'),
        ('mansion', 'hard'), ('cottage', 'medium'), ('windmill', 'medium'),
        ('barn', 'easy'), ('garage', 'easy'), ('bridge', 'medium'),
        ('tunnel', 'medium'), ('stadium', 'medium'), ('museum', 'medium'),
        ('palace', 'medium'),

        # ---- Misc/Holiday (30) ----
        ('snowman', 'easy'), ('santa', 'easy'), ('reindeer', 'medium'),
        ('present', 'easy'), ('balloon', 'easy'),
        ('fireworks', 'medium'), ('mummy', 'easy'),
        ('cupid', 'medium'), ('clover', 'medium'),
        ('bunny', 'easy'), ('turkey', 'easy'), ('mustache', 'medium'),
        ('beard', 'easy'), ('tattoo', 'medium'), ('makeup', 'medium'),
        ('lipstick', 'medium'), ('compass', 'medium'),
        ('map', 'easy'), ('flag', 'easy'), ('treasure', 'medium'),
        ('coin', 'easy'), ('dollar', 'easy'), ('diamond', 'medium'),
        ('crystal', 'medium'), ('pearl', 'medium'),
        ('feather', 'easy'), ('bone', 'easy'), ('shell', 'easy'),
        ('dice', 'easy'), ('puzzle', 'medium'),
    ]
    c = conn.cursor()
    c.executemany('INSERT OR IGNORE INTO words (word, difficulty) VALUES (?, ?)', words)


def get_random_words(count=3):
    """Pick `count` distinct random words for the drawer to choose from."""
    with get_conn() as conn:
        c = conn.cursor()
        # Per spec: SELECT word FROM words ORDER BY RANDOM() LIMIT ?
        c.execute('SELECT word FROM words ORDER BY RANDOM() LIMIT ?', (count,))
        return [row['word'] for row in c.fetchall()]


def save_game_history(room_code, started_at, total_rounds, team_results):
    """
    Persist a finished game with team scores.
    `team_results` is a list of (team_name, team_color, score) tuples.
    """
    with get_conn() as conn:
        c = conn.cursor()
        c.execute('''
            INSERT INTO game_history (room_code, started_at, ended_at, total_rounds, team_count)
            VALUES (?, ?, ?, ?, ?)
        ''', (room_code, started_at, datetime.now(), total_rounds, len(team_results)))
        game_id = c.lastrowid

        for team_name, team_color, score in team_results:
            c.execute('INSERT INTO team_scores (game_id, team_name, team_color, score) VALUES (?, ?, ?, ?)',
                      (game_id, team_name, team_color, score))
        return game_id


def get_top_team_scores(limit=10):
    """Top-N team scores across all games."""
    with get_conn() as conn:
        c = conn.cursor()
        c.execute('''
            SELECT team_name, team_color, MAX(score) as best_score
            FROM team_scores
            GROUP BY team_name, team_color
            ORDER BY best_score DESC
            LIMIT ?
        ''', (limit,))
        return [dict(row) for row in c.fetchall()]
