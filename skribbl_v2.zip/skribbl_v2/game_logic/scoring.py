"""
Scoring rules (team-based).

Two payouts per correct guess:
- Guesser's team: speed-scaled points (faster = more)
- Drawer's team: small flat bonus per correct guesser (rewards clear drawings)
"""

MAX_GUESS_POINTS = 100
MIN_GUESS_POINTS = 20
DRAWER_TEAM_POINTS_PER_GUESS = 30


def calculate_guess_score(time_remaining, total_time):
    """Linear scale: full time left = MAX, none left = MIN."""
    if total_time <= 0:
        return MIN_GUESS_POINTS
    ratio = max(0.0, min(1.0, time_remaining / total_time))
    return int(MIN_GUESS_POINTS + (MAX_GUESS_POINTS - MIN_GUESS_POINTS) * ratio)


def calculate_drawer_team_bonus():
    """Flat bonus added to the drawer's team per correct guesser."""
    return DRAWER_TEAM_POINTS_PER_GUESS
