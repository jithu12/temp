"""
In-memory team-based game engine.

Major v2 changes:
- Players are organized into Teams. Scores live on teams, not players.
- Drawer selection: pick a team first, then pick a player from that team.
- Rooms have a `room_locked` flag (admin-controlled).
- Admins exist outside the player list (separate `admin_sids` set per room).
- Admin actions: lock/unlock, assign teams, skip round, deduct points, kick.
"""

import random
import string
from datetime import datetime
from . import database


# ---- Constants ----
ROUND_TIME = 60
WORD_CHOICES = 3
ROUNDS_PER_PLAYER = 2          # Each player draws this many times before game ends
INACTIVE_TIMEOUT_SECONDS = 60

# Pre-defined team palette. We use colors[i] for team i.
TEAM_PALETTE = [
    {'name': 'Team Red',    'color': '#ef4444'},
    {'name': 'Team Blue',   'color': '#3b82f6'},
    {'name': 'Team Green',  'color': '#22c55e'},
    {'name': 'Team Yellow', 'color': '#eab308'},
    {'name': 'Team Purple', 'color': '#8b5cf6'},
    {'name': 'Team Orange', 'color': '#f97316'},
]


# ---- In-memory state ----
rooms = {}
sid_to_player = {}    # sid -> {'room_code', 'nickname', 'is_admin': bool}


def generate_room_code():
    while True:
        code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        if code not in rooms:
            return code


# ============================================================
# Team
# ============================================================

class Team:
    """A team is a labeled bucket of players plus a shared score."""

    def __init__(self, team_id, name, color):
        self.team_id = team_id
        self.name = name
        self.color = color
        self.player_nicknames = []   # stable list of nicknames in this team
        self.score = 0

    def add_player(self, nickname):
        if nickname not in self.player_nicknames:
            self.player_nicknames.append(nickname)

    def remove_player(self, nickname):
        if nickname in self.player_nicknames:
            self.player_nicknames.remove(nickname)

    def is_empty(self):
        return len(self.player_nicknames) == 0

    def to_dict(self, players_dict=None):
        # Build nested player info if a player dict is supplied (for richer client display).
        out = {
            'team_id': self.team_id,
            'name': self.name,
            'color': self.color,
            'score': self.score,
            'player_nicknames': list(self.player_nicknames),
        }
        if players_dict is not None:
            out['players'] = []
            for nick in self.player_nicknames:
                p = players_dict.get(nick)
                if p:
                    out['players'].append({
                        'nickname': nick,
                        'connected': p.connected,
                        'has_guessed': p.has_guessed,
                    })
        return out


# ============================================================
# Player
# ============================================================

class Player:
    """One participant. Note: scores live on the team, not the player."""

    def __init__(self, nickname, sid):
        self.nickname = nickname
        self.sid = sid
        self.connected = True
        self.disconnected_at = None
        self.has_guessed = False        # reset per round
        self.team_id = None             # set after admin assigns / auto-assigns

    def to_dict(self):
        return {
            'nickname': self.nickname,
            'connected': self.connected,
            'has_guessed': self.has_guessed,
            'team_id': self.team_id,
        }


# ============================================================
# Room
# ============================================================

class Room:
    """
    One game lobby + active game.

    State machine:
      WAITING -> CHOOSING_WORD -> DRAWING -> ROUND_END -> (next round) ...
                                                        -> GAME_OVER
    """

    def __init__(self, code):
        self.code = code
        self.players = {}                # nickname -> Player
        self.admin_sids = set()          # connected admin socket ids
        self.teams = {}                  # team_id -> Team
        self.team_count = 2              # default; admin sets at game start
        self.room_locked = False         # admin-controlled join lock
        self.state = 'WAITING'

        # Per-round state
        self.current_drawer = None
        self.current_drawing_team_id = None
        self.current_word = None
        self.word_choices = []
        self.round_number = 0
        self.total_rounds = 0
        self.round_start_time = None
        self.canvas_history = []
        self.correct_guessers = []

        # Drawer rotation: list of (team_id, nickname) tuples
        self.drawer_order = []
        self.started_at = None

    # ---- Player management ----

    def add_player(self, nickname, sid):
        if nickname in self.players:
            # Reconnect — keep team assignment
            p = self.players[nickname]
            p.sid = sid
            p.connected = True
            p.disconnected_at = None
            return p
        p = Player(nickname, sid)
        self.players[nickname] = p

        # Auto-assign to smallest team when teams already exist
        if self.teams:
            smallest_team = min(
                self.teams.values(),
                key=lambda t: len(t.player_nicknames)
            )
            p.team_id = smallest_team.team_id
            smallest_team.add_player(nickname)

        return p

    def remove_player(self, nickname):
        """Hard-remove. Also removes from team if assigned."""
        if nickname not in self.players:
            return
        p = self.players[nickname]
        if p.team_id is not None and p.team_id in self.teams:
            self.teams[p.team_id].remove_player(nickname)
        del self.players[nickname]

    def mark_disconnected(self, nickname):
        if nickname in self.players:
            self.players[nickname].connected = False
            self.players[nickname].disconnected_at = datetime.now()

    def get_connected_players(self):
        return [p for p in self.players.values() if p.connected]

    # ---- Admin management ----

    def add_admin(self, sid):
        self.admin_sids.add(sid)

    def remove_admin(self, sid):
        self.admin_sids.discard(sid)

    def is_admin(self, sid):
        return sid in self.admin_sids

    # ---- Team management ----

    def setup_teams(self, team_count):
        """
        Build `team_count` empty Team objects from the palette.
        Auto-assign all currently-connected players evenly.
        """
        team_count = max(2, min(len(TEAM_PALETTE), team_count))
        self.team_count = team_count
        self.teams = {}
        for i in range(team_count):
            t = Team(i, TEAM_PALETTE[i]['name'], TEAM_PALETTE[i]['color'])
            self.teams[i] = t

        # Wipe any existing assignments before redistribution
        for p in self.players.values():
            p.team_id = None

        self.auto_assign_teams()

    def auto_assign_teams(self):
        """
        Distribute connected players evenly:
          team_size = total // team_count
          extras    = total % team_count   (first `extras` teams get +1)
        """
        connected = list(self.get_connected_players())
        random.shuffle(connected)         # shuffle so teams aren't biased by join order

        if not self.teams:
            return  # shouldn't happen — setup_teams should run first

        # Reset teams first (so re-balancing works)
        for t in self.teams.values():
            t.player_nicknames = []
        for p in self.players.values():
            p.team_id = None

        team_ids = sorted(self.teams.keys())
        n_teams = len(team_ids)
        total = len(connected)
        if total == 0 or n_teams == 0:
            return

        base = total // n_teams
        extras = total % n_teams

        # First `extras` teams get base+1, rest get base
        idx = 0
        for i, tid in enumerate(team_ids):
            size = base + (1 if i < extras else 0)
            for _ in range(size):
                if idx >= total:
                    break
                player = connected[idx]
                player.team_id = tid
                self.teams[tid].add_player(player.nickname)
                idx += 1

    def reassign_player(self, nickname, new_team_id):
        """Admin moves a player to a different team."""
        if nickname not in self.players:
            return False
        if new_team_id not in self.teams:
            return False
        p = self.players[nickname]
        # Remove from old team
        if p.team_id is not None and p.team_id in self.teams:
            self.teams[p.team_id].remove_player(nickname)
        p.team_id = new_team_id
        self.teams[new_team_id].add_player(nickname)
        return True

    def get_player_team(self, nickname):
        if nickname not in self.players:
            return None
        tid = self.players[nickname].team_id
        if tid is None:
            return None
        return self.teams.get(tid)

    # ---- Game flow ----

    def can_start(self):
        """
        Need:
        - At least 2 connected players total
        - Teams set up
        - Each team has at least 1 player
        """
        if self.state != 'WAITING':
            return False
        if len(self.get_connected_players()) < 2:
            return False
        if not self.teams:
            return False
        for t in self.teams.values():
            if t.is_empty():
                return False
        return True

    def start_game(self):
        """
        Build the drawer rotation. Each player draws ROUNDS_PER_PLAYER times.
        Order: alternate through teams round-robin so teams take turns drawing.
        """
        self.state = 'CHOOSING_WORD'
        self.started_at = datetime.now()
        self.round_number = 0

        # Build per-team drawer queues (shuffled)
        team_queues = {}
        for tid, team in self.teams.items():
            queue = list(team.player_nicknames)
            random.shuffle(queue)
            # Each player draws ROUNDS_PER_PLAYER times
            queue = queue * ROUNDS_PER_PLAYER
            team_queues[tid] = queue

        # Round-robin interleave: rotate teams so they take turns drawing
        self.drawer_order = []
        team_ids = sorted(self.teams.keys())
        # Continue until all queues are empty
        while any(team_queues[tid] for tid in team_ids):
            for tid in team_ids:
                if team_queues[tid]:
                    nick = team_queues[tid].pop(0)
                    self.drawer_order.append((tid, nick))

        self.total_rounds = len(self.drawer_order)

        # Reset team scores & per-player flags
        for t in self.teams.values():
            t.score = 0
        for p in self.players.values():
            p.has_guessed = False

    def next_round(self):
        """
        Advance to the next round.
        Returns True if a new round was set up, False if game is over.

        Skip rules:
        - If the chosen drawer disconnected, skip them
        - If their entire team is empty (everyone left), skip the team's slots
        """
        # Reset per-round state
        for p in self.players.values():
            p.has_guessed = False
        self.canvas_history = []
        self.correct_guessers = []
        self.current_word = None
        self.word_choices = []

        if self.round_number >= self.total_rounds:
            self.state = 'GAME_OVER'
            return False

        # Walk forward until we find a valid drawer
        while self.round_number < self.total_rounds:
            tid, nickname = self.drawer_order[self.round_number]
            self.round_number += 1

            # Team gone?
            team = self.teams.get(tid)
            if not team or team.is_empty():
                continue
            # Player gone or disconnected?
            if nickname not in self.players:
                continue
            if not self.players[nickname].connected:
                continue

            # Found a valid drawer
            self.current_drawer = nickname
            self.current_drawing_team_id = tid
            self.state = 'CHOOSING_WORD'
            self.word_choices = database.get_random_words(WORD_CHOICES)
            return True

        # Exhausted rotation without finding a valid drawer
        self.state = 'GAME_OVER'
        return False

    def select_word(self, word):
        if word not in self.word_choices:
            return False
        self.current_word = word
        self.state = 'DRAWING'
        self.round_start_time = datetime.now()
        return True

    def get_word_blanks(self):
        if not self.current_word:
            return ''
        return ' '.join('_' if ch.isalnum() else ch for ch in self.current_word)

    def get_time_remaining(self):
        if not self.round_start_time or self.state != 'DRAWING':
            return 0
        elapsed = (datetime.now() - self.round_start_time).total_seconds()
        return max(0, ROUND_TIME - elapsed)

    def can_chat(self, nickname):
        """
        Per spec:
        - Drawer:           NO
        - Drawing team:     NO
        - Other teams:      YES (only during DRAWING)
        Outside DRAWING (lobby, round end), everyone can chat.
        """
        if self.state != 'DRAWING':
            return True
        if nickname == self.current_drawer:
            return False
        # Same team as drawer? Blocked.
        p = self.players.get(nickname)
        if p and p.team_id == self.current_drawing_team_id:
            return False
        return True

    def check_guess(self, nickname, guess):
        """
        Check if a guess matches the current word.
        Returns (is_correct, points_awarded). Points go to the player's team.
        """
        if self.state != 'DRAWING' or not self.current_word:
            return (False, 0)
        if nickname == self.current_drawer:
            return (False, 0)
        p = self.players.get(nickname)
        if not p or p.has_guessed:
            return (False, 0)
        # Drawer's team can't guess (their messages are blocked at the chat layer too,
        # but double-check here)
        if p.team_id == self.current_drawing_team_id:
            return (False, 0)

        if guess.strip().lower() == self.current_word.lower():
            from .scoring import calculate_guess_score, calculate_drawer_team_bonus
            time_remaining = self.get_time_remaining()
            points = calculate_guess_score(time_remaining, ROUND_TIME)

            # Award to GUESSER's team
            if p.team_id is not None and p.team_id in self.teams:
                self.teams[p.team_id].score += points

            p.has_guessed = True
            self.correct_guessers.append(nickname)

            # Drawer's TEAM also gets a bonus
            if (self.current_drawing_team_id is not None
                    and self.current_drawing_team_id in self.teams):
                self.teams[self.current_drawing_team_id].score += calculate_drawer_team_bonus()

            return (True, points)
        return (False, 0)

    def all_non_drawing_teams_guessed(self):
        """
        End round early when every connected player on a non-drawing team has guessed.
        """
        eligible = [
            p for p in self.get_connected_players()
            if p.team_id != self.current_drawing_team_id
        ]
        if not eligible:
            return False
        return all(p.has_guessed for p in eligible)

    def add_canvas_event(self, event):
        self.canvas_history.append(event)

    def apply_penalty(self, team_id, points):
        """Admin deducts points from a team. Floor at 0 to avoid negative scores."""
        if team_id not in self.teams:
            return False
        t = self.teams[team_id]
        t.score = max(0, t.score - abs(points))
        return True

    def apply_bonus(self, team_id, points):
        """Admin adds points to a team."""
        if team_id not in self.teams:
            return False
        t = self.teams[team_id]
        t.score += abs(points)
        return True

    # ---- Serialization ----

    def get_team_leaderboard(self):
        """Teams sorted by score desc."""
        return sorted(
            [t.to_dict(self.players) for t in self.teams.values()],
            key=lambda t: t['score'],
            reverse=True,
        )

    def to_dict(self):
        """Public snapshot for player_list_update."""
        return {
            'code': self.code,
            'state': self.state,
            'room_locked': self.room_locked,
            'players': [p.to_dict() for p in self.players.values()],
            'teams': [t.to_dict(self.players) for t in self.teams.values()],
            'team_count': self.team_count,
            'round_number': self.round_number,
            'total_rounds': self.total_rounds,
            'current_drawer': self.current_drawer,
            'current_drawing_team_id': self.current_drawing_team_id,
        }


# ============================================================
# Module-level helpers
# ============================================================

def create_room():
    """Admin or first-player creates a room. No host concept anymore — admin runs it."""
    code = generate_room_code()
    room = Room(code)
    rooms[code] = room
    return room


def get_room(code):
    return rooms.get(code)


def delete_room(code):
    if code in rooms:
        del rooms[code]


def cleanup_inactive_players():
    """Remove players disconnected longer than INACTIVE_TIMEOUT_SECONDS."""
    now = datetime.now()
    removed = []
    for room_code in list(rooms.keys()):
        room = rooms[room_code]
        for nickname in list(room.players.keys()):
            p = room.players[nickname]
            if not p.connected and p.disconnected_at:
                elapsed = (now - p.disconnected_at).total_seconds()
                if elapsed > INACTIVE_TIMEOUT_SECONDS:
                    room.remove_player(nickname)
                    removed.append((room_code, nickname))

        # Drop empty rooms (no players AND no admins)
        if not room.players and not room.admin_sids:
            delete_room(room_code)
    return removed
