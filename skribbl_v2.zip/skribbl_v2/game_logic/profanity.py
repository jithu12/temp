"""
Lightweight profanity filter.

Substring-match against a small bad-words list. Intentionally simple —
not meant to catch every variation, just to block obvious spam in a
casual party-game setting.
"""

# Minimal blocklist — keep it conservative to avoid false positives on guesses.
BAD_WORDS = {
    'shit', 'fuck', 'bitch', 'asshole', 'bastard', 'damn',
    'crap', 'dick', 'piss', 'cunt', 'whore', 'slut',
}


def contains_profanity(text):
    """True if any blocked word appears as a substring (case-insensitive)."""
    if not text:
        return False
    lower = text.lower()
    return any(bad in lower for bad in BAD_WORDS)


def censor(text):
    """Replace each blocked word with asterisks of the same length."""
    if not text:
        return text
    result = text
    for bad in BAD_WORDS:
        # Case-insensitive replace, preserving length
        idx = 0
        lower = result.lower()
        while idx < len(lower):
            pos = lower.find(bad, idx)
            if pos == -1:
                break
            result = result[:pos] + ('*' * len(bad)) + result[pos + len(bad):]
            lower = result.lower()
            idx = pos + len(bad)
    return result
