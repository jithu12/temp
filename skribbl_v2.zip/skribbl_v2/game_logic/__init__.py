"""Game logic package — database, scoring, profanity filter, and the in-memory engine."""
