/**
 * Admin control panel logic.
 *
 * Reads admin password + room code from sessionStorage (set during /admin login),
 * connects via socket, and exposes:
 * - Team setup (2-4 teams) + lock + start (pre-game)
 * - Skip round, kick player, reassign player, deduct points (live controls)
 * - Live chat + word monitor
 *
 * Admins are invisible to players (not in player list, can't draw/guess/chat).
 */

const adminPassword = sessionStorage.getItem('admin_password');
const roomCode = sessionStorage.getItem('admin_room_code');

if (!adminPassword || !roomCode) {
    window.location.href = '/admin';
}

// ---- DOM ----
const roomCodeEl = document.getElementById('admin-room-code');
const stateBadge = document.getElementById('admin-state-badge');
const copyCodeBtn = document.getElementById('copy-code-btn');

const setupSection = document.getElementById('setup-section');
const liveSection = document.getElementById('live-section');
const teamCountSelect = document.getElementById('team-count-select');
const setupTeamsBtn = document.getElementById('setup-teams-btn');
const lockRoomBtn = document.getElementById('lock-room-btn');
const startGameBtn = document.getElementById('start-game-btn');
const setupHint = document.getElementById('setup-hint');

const drawerEl = document.getElementById('admin-drawer');
const drawingTeamEl = document.getElementById('admin-drawing-team');
const wordEl = document.getElementById('admin-word');
const skipRoundBtn = document.getElementById('skip-round-btn');

const playersList = document.getElementById('admin-players-list');
const teamsList = document.getElementById('admin-teams-list');

const penaltyTeamSelect = document.getElementById('penalty-team-select');
const penaltyAmountInput = document.getElementById('penalty-amount');
const applyPenaltyBtn = document.getElementById('apply-penalty-btn');
const applyBonusBtn = document.getElementById('apply-bonus-btn');

const adminChat = document.getElementById('admin-chat');

roomCodeEl.textContent = roomCode;

// ---- State ----
let currentState = 'WAITING';
let roomLocked = false;
let currentTeams = [];
let currentPlayers = [];

// ---- Socket ----
const socket = io();

socket.on('connect', () => {
    socket.emit('admin_join', { password: adminPassword, room_code: roomCode });
});

socket.on('error', (data) => {
    appendChat({ nickname: 'Error', message: data.message, system: true });
    // If auth failed, kick back to login
    if ((data.message || '').toLowerCase().includes('admin')) {
        setTimeout(() => { window.location.href = '/admin'; }, 1500);
    }
});

socket.on('admin_joined', (data) => {
    applyRoomState(data.room_state);
});

socket.on('player_list_update', (state) => {
    applyRoomState(state);
});

socket.on('admin_round_info', (data) => {
    drawerEl.textContent = data.drawer || '—';
    const team = currentTeams.find(t => t.team_id === data.drawing_team_id);
    drawingTeamEl.textContent = team ? team.name : '—';
    if (team) drawingTeamEl.style.color = team.color;
    wordEl.textContent = data.word || '—';
});

socket.on('team_scores_update', (data) => {
    if (data.teams) {
        currentTeams = data.teams;
        renderTeams();
        populatePenaltyDropdown();
    }
});

socket.on('chat_message', (data) => {
    appendChat(data);
});

socket.on('correct_guess', (data) => {
    appendChat({
        nickname: 'System',
        message: `✓ ${data.nickname} (${data.team_name}) guessed it! +${data.points}`,
        system: false,
        correct: true,
    });
    // Update team scores in admin panel when someone guesses correctly
    if (data.team_leaderboard) {
        currentTeams = data.team_leaderboard;
        renderTeams();
        populatePenaltyDropdown();
    }
});

socket.on('end_round', (data) => {
    if (data.team_leaderboard) {
        currentTeams = data.team_leaderboard;
        renderTeams();
        populatePenaltyDropdown();
    }
    wordEl.textContent = data.word ? `${data.word} (ended)` : '—';
    appendChat({
        nickname: 'System',
        message: `Round ended (${data.reason || 'time_up'}). Word: ${data.word || '???'}`,
        system: true,
    });
});

socket.on('game_over', (data) => {
    if (data.team_leaderboard) {
        currentTeams = data.team_leaderboard;
        renderTeams();
        populatePenaltyDropdown();
    }
    wordEl.textContent = '—';
    drawerEl.textContent = '—';
    drawingTeamEl.textContent = '—';
    appendChat({
        nickname: 'System',
        message: '🏆 Game over!',
        system: true,
    });
});

// ---- State application ----

function applyRoomState(state) {
    currentState = state.state;
    roomLocked = !!state.room_locked;
    currentTeams = state.teams || [];
    currentPlayers = state.players || [];

    // State badge
    stateBadge.textContent = currentState;
    stateBadge.style.background = stateColor(currentState);

    // Lock button
    lockRoomBtn.textContent = roomLocked ? '🔓 Unlock Room' : '🔒 Lock Room';
    lockRoomBtn.classList.toggle('active', roomLocked);

    // Section visibility — setup before game, live during game
    if (currentState === 'WAITING') {
        setupSection.style.display = 'block';
        liveSection.style.display = 'none';
        // Re-enable controls in case we were live earlier (after game over)
        setupTeamsBtn.disabled = false;
        startGameBtn.disabled = false;
        teamCountSelect.disabled = false;
        setupHint.textContent = currentTeams.length === 0
            ? `Pick a team count, then "Apply Teams". ${currentPlayers.length} player(s) in room.`
            : `Teams set up. ${currentPlayers.length} player(s) in room. Click Start Game when ready.`;
    } else {
        setupSection.style.display = 'none';
        liveSection.style.display = 'block';
    }

    // Live info during round
    drawerEl.textContent = state.current_drawer || '—';
    const team = currentTeams.find(t => t.team_id === state.current_drawing_team_id);
    drawingTeamEl.textContent = team ? team.name : '—';
    if (team) drawingTeamEl.style.color = team.color;
    else drawingTeamEl.style.color = '';
    // Word is set via admin_round_info — don't clear it here

    renderPlayers();
    renderTeams();
    populatePenaltyDropdown();
}

function stateColor(state) {
    return {
        'WAITING': '#4b5563',
        'CHOOSING_WORD': '#f59e0b',
        'DRAWING': '#10b981',
        'ROUND_END': '#6366f1',
        'GAME_OVER': '#dc2626',
    }[state] || '#4b5563';
}

// ---- Renderers ----

function renderPlayers() {
    playersList.innerHTML = '';
    if (currentPlayers.length === 0) {
        playersList.innerHTML = '<p class="info-text">No players yet. Share the room code.</p>';
        return;
    }

    currentPlayers.forEach(p => {
        const row = document.createElement('div');
        row.className = 'admin-player-row';
        if (!p.connected) row.classList.add('disconnected');

        const team = currentTeams.find(t => t.team_id === p.team_id);
        if (team) row.style.borderLeftColor = team.color;

        const teamLabel = team ? team.name : 'Unassigned';

        // Team-reassign dropdown — only enabled in WAITING
        const teamOptions = currentTeams.map(t =>
            `<option value="${t.team_id}" ${t.team_id === p.team_id ? 'selected' : ''}>${escapeHtml(t.name)}</option>`
        ).join('');

        row.innerHTML = `
            <div>
                <div class="admin-player-name">
                    ${escapeHtml(p.nickname)}
                    ${!p.connected ? '<small style="color:#9ca3af">(offline)</small>' : ''}
                </div>
                <small style="color:#9ca3af">${escapeHtml(teamLabel)}</small>
            </div>
            <div class="admin-player-actions">
                <select data-nickname="${escapeHtml(p.nickname)}" class="reassign-select" ${currentState !== 'WAITING' || currentTeams.length === 0 ? 'disabled' : ''}>
                    ${teamOptions || '<option>—</option>'}
                </select>
                <button class="kick-btn" data-nickname="${escapeHtml(p.nickname)}">Kick</button>
            </div>
        `;
        playersList.appendChild(row);
    });

    // Wire up reassign selects
    playersList.querySelectorAll('.reassign-select').forEach(sel => {
        sel.addEventListener('change', () => {
            const nickname = sel.dataset.nickname;
            const teamId = parseInt(sel.value);
            socket.emit('admin_reassign_player', { nickname, team_id: teamId });
        });
    });

    // Wire up kick buttons
    playersList.querySelectorAll('.kick-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const nickname = btn.dataset.nickname;
            if (confirm(`Kick ${nickname}?`)) {
                socket.emit('admin_kick_player', { nickname });
            }
        });
    });
}

function renderTeams() {
    teamsList.innerHTML = '';
    if (currentTeams.length === 0) {
        teamsList.innerHTML = '<p class="info-text">No teams set up yet.</p>';
        return;
    }

    currentTeams.forEach(t => {
        const row = document.createElement('div');
        row.className = 'admin-team-row';
        row.style.borderLeftColor = t.color;

        const playerNames = (t.player_nicknames || []).join(', ') || '<em>empty</em>';
        row.innerHTML = `
            <div style="flex:1;">
                <div class="admin-team-name" style="color:${t.color}">${escapeHtml(t.name)}</div>
                <div class="admin-team-players">${playerNames}</div>
            </div>
            <div class="admin-team-score">${t.score}</div>
        `;
        teamsList.appendChild(row);
    });
}

function populatePenaltyDropdown() {
    const previousValue = penaltyTeamSelect.value;
    penaltyTeamSelect.innerHTML = '';
    if (currentTeams.length === 0) {
        penaltyTeamSelect.innerHTML = '<option value="">No teams</option>';
        return;
    }
    currentTeams.forEach(t => {
        const opt = document.createElement('option');
        opt.value = t.team_id;
        opt.textContent = `${t.name} (${t.score} pts)`;
        penaltyTeamSelect.appendChild(opt);
    });
    if (previousValue) penaltyTeamSelect.value = previousValue;
}

function appendChat(data) {
    const div = document.createElement('div');
    div.className = 'chat-message';
    if (data.system) div.classList.add('system');
    if (data.correct) div.classList.add('correct');

    if (data.system) {
        div.textContent = data.message;
    } else {
        div.innerHTML = `<span class="nickname">${escapeHtml(data.nickname)}:</span> ${escapeHtml(data.message)}`;
    }
    adminChat.appendChild(div);
    adminChat.scrollTop = adminChat.scrollHeight;

    // Cap at 200 messages so DOM doesn't grow forever
    while (adminChat.children.length > 200) adminChat.removeChild(adminChat.firstChild);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text == null ? '' : String(text);
    return div.innerHTML;
}

// ---- Button handlers ----

setupTeamsBtn.addEventListener('click', () => {
    const teamCount = parseInt(teamCountSelect.value);
    socket.emit('admin_setup_teams', { team_count: teamCount });
});

lockRoomBtn.addEventListener('click', () => {
    socket.emit('admin_lock_room', { locked: !roomLocked });
});

startGameBtn.addEventListener('click', () => {
    if (currentTeams.length === 0) {
        alert('Set up teams first');
        return;
    }
    if (currentPlayers.length < 2) {
        alert('Need at least 2 players');
        return;
    }
    if (currentTeams.some(t => (t.player_nicknames || []).length === 0)) {
        if (!confirm('Some teams are empty. Re-apply teams to redistribute? (Click Cancel to start anyway — empty teams will be skipped.)')) {
            socket.emit('admin_start_game');
        } else {
            const teamCount = parseInt(teamCountSelect.value);
            socket.emit('admin_setup_teams', { team_count: teamCount });
        }
        return;
    }
    socket.emit('admin_start_game');
});

skipRoundBtn.addEventListener('click', () => {
    if (confirm('Skip the current round?')) {
        socket.emit('admin_skip_round');
    }
});

applyPenaltyBtn.addEventListener('click', () => {
    const teamId = parseInt(penaltyTeamSelect.value);
    const points = parseInt(penaltyAmountInput.value);
    if (isNaN(teamId)) { alert('Pick a team'); return; }
    if (!points || points <= 0) { alert('Enter a positive number of points'); return; }
    if (confirm(`Deduct ${points} points from this team?`)) {
        socket.emit('admin_penalty', { team_id: teamId, points });
    }
});

applyBonusBtn.addEventListener('click', () => {
    const teamId = parseInt(penaltyTeamSelect.value);
    const points = parseInt(penaltyAmountInput.value);
    if (isNaN(teamId)) { alert('Pick a team'); return; }
    if (!points || points <= 0) { alert('Enter a positive number of points'); return; }
    socket.emit('admin_bonus', { team_id: teamId, points });
});

copyCodeBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(roomCode).then(() => {
        copyCodeBtn.textContent = '✓ Copied';
        setTimeout(() => { copyCodeBtn.textContent = '📋 Copy'; }, 1500);
    }).catch(() => prompt('Copy this room code:', roomCode));
});

window.addEventListener('beforeunload', (e) => {
    if (currentState !== 'WAITING') {
        e.preventDefault();
        e.returnValue = 'Game is in progress — are you sure you want to leave the admin panel?';
        return e.returnValue;
    }
});
