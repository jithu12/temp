/**
 * Admin login. Validates password against /api/admin_login.
 * On success, sessionStorage carries the password + room_code to /admin/panel.
 *
 * Note: storing the password in sessionStorage is OK for this dev/party-game use case
 * since it's per-tab and hardcoded anyway. Don't reuse this pattern for real apps.
 */

document.addEventListener('DOMContentLoaded', () => {
    const passwordInput = document.getElementById('password');
    const roomCodeInput = document.getElementById('room-code');
    const createBtn = document.getElementById('create-btn');
    const joinBtn = document.getElementById('join-btn');
    const errorMsg = document.getElementById('error-msg');
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const tab = btn.dataset.tab;
            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById(`${tab}-tab`).classList.add('active');
            errorMsg.textContent = '';
        });
    });

    function showError(msg) { errorMsg.textContent = msg; }

    async function submit(roomCode = null) {
        const password = passwordInput.value;
        if (!password) { showError('Enter the admin password'); return; }

        try {
            const res = await fetch('/api/admin_login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ password, room_code: roomCode }),
            });
            const data = await res.json();
            if (!res.ok) { showError(data.error || 'Login failed'); return; }

            sessionStorage.setItem('admin_password', password);
            sessionStorage.setItem('admin_room_code', data.room_code);
            window.location.href = '/admin/panel';
        } catch (err) {
            showError('Connection error: ' + err.message);
        }
    }

    createBtn.addEventListener('click', () => submit(null));
    joinBtn.addEventListener('click', () => {
        const code = roomCodeInput.value.trim().toUpperCase();
        if (!code || code.length !== 6) { showError('Enter a 6-character code'); return; }
        submit(code);
    });

    [passwordInput, roomCodeInput].forEach(input => {
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                if (document.getElementById('create-tab').classList.contains('active')) {
                    createBtn.click();
                } else {
                    joinBtn.click();
                }
            }
        });
    });
});
