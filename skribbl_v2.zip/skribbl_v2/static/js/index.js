/**
 * Player landing page.
 * Players only join rooms — admin creates them.
 */

document.addEventListener('DOMContentLoaded', () => {
    const nicknameInput = document.getElementById('nickname');
    const roomCodeInput = document.getElementById('room-code');
    const joinBtn = document.getElementById('join-btn');
    const errorMsg = document.getElementById('error-msg');

    // Restore previously-typed nickname for convenience
    const savedNickname = sessionStorage.getItem('nickname');
    if (savedNickname) nicknameInput.value = savedNickname;

    function showError(msg) { errorMsg.textContent = msg; }

    function getNickname() {
        const nickname = nicknameInput.value.trim();
        if (!nickname) { showError('Please enter a nickname'); return null; }
        if (nickname.length > 20) { showError('Nickname must be 20 characters or less'); return null; }
        return nickname;
    }

    joinBtn.addEventListener('click', async () => {
        const nickname = getNickname();
        if (!nickname) return;

        const roomCode = roomCodeInput.value.trim().toUpperCase();
        if (!roomCode || roomCode.length !== 6) {
            showError('Please enter a valid 6-character room code');
            return;
        }

        joinBtn.disabled = true;
        try {
            const res = await fetch(`/api/check_room/${roomCode}`);
            const data = await res.json();
            if (!res.ok || !data.exists) {
                showError('Room not found');
                joinBtn.disabled = false;
                return;
            }
            if (data.locked) {
                showError('Game already started');
                joinBtn.disabled = false;
                return;
            }
            sessionStorage.setItem('nickname', nickname);
            sessionStorage.setItem('room_code', roomCode);
            window.location.href = '/game';
        } catch (err) {
            showError('Connection error: ' + err.message);
            joinBtn.disabled = false;
        }
    });

    roomCodeInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') joinBtn.click();
    });
});
