/**
 * Player game page logic — team edition.
 *
 * Key changes from v1:
 * - Renders team panels instead of player list
 * - Shows team banner during drawing rounds
 * - Chat is disabled for the entire drawing TEAM, not just the drawer
 * - Guidelines modal shown on first load
 * - Canvas dynamically resized to fit the wrapper while keeping aspect ratio
 */

const nickname = sessionStorage.getItem('nickname');
const roomCode = sessionStorage.getItem('room_code');

if (!nickname || !roomCode) {
    window.location.href = '/';
}

// ---- DOM ----
const canvas = document.getElementById('drawing-canvas');
const ctx = canvas.getContext('2d');
const overlay = document.getElementById('canvas-overlay');
const overlayContent = document.getElementById('overlay-content');
const tools = document.getElementById('tools');
const chatMessages = document.getElementById('chat-messages');
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const chatSubmitBtn = chatForm.querySelector('button[type="submit"]');
const teamsContainer = document.getElementById('teams-container');
const roomCodeDisplay = document.getElementById('room-code-display');
const lockIndicator = document.getElementById('lock-indicator');
const wordDisplay = document.getElementById('word-display');
const timerDisplay = document.getElementById('timer');
const roundNumDisplay = document.getElementById('round-num');
const totalRoundsDisplay = document.getElementById('total-rounds');
const teamBanner = document.getElementById('team-banner');
const teamBannerText = document.getElementById('team-banner-text');
const guidelinesModal = document.getElementById('guidelines-modal');
const guidelinesOkBtn = document.getElementById('guidelines-ok-btn');
const wordModal = document.getElementById('word-modal');
const wordChoicesDiv = document.getElementById('word-choices');
const gameOverModal = document.getElementById('game-over-modal');
const finalLeaderboard = document.getElementById('final-leaderboard');
const backToLobbyBtn = document.getElementById('back-to-lobby-btn');
const copyCodeBtn = document.getElementById('copy-code-btn');
const kickedModal = document.getElementById('kicked-modal');

roomCodeDisplay.textContent = roomCode;

// ---- State ----
let isDrawer = false;
let currentDrawer = null;
let currentDrawingTeamId = null;
let myTeamId = null;
let timerInterval = null;
let roomState = 'WAITING';
// Cache the latest team list for current drawer color lookups
let latestTeams = [];

// ---- Drawing tool state ----
let drawing = false;
let currentColor = '#000000';
let currentSize = 5;
let isEraser = false;
let lastX = 0, lastY = 0;

// ---- Guidelines modal: show once per session ----
if (sessionStorage.getItem('guidelines_seen') === 'true') {
    guidelinesModal.style.display = 'none';
}
guidelinesOkBtn.addEventListener('click', () => {
    guidelinesModal.style.display = 'none';
    sessionStorage.setItem('guidelines_seen', 'true');
});

// ---- Socket ----
const socket = io();

socket.on('connect', () => {
    socket.emit('join_room', { nickname, room_code: roomCode });
});

socket.on('disconnect', () => {
    addSystemMessage('Disconnected. Trying to reconnect...');
});

socket.on('error', (data) => {
    alert(data.message);
    if (data.message.includes('not found') || data.message.includes('already started')
        || data.message.includes('in use')) {
        window.location.href = '/';
    }
});

socket.on('joined_room', (data) => {
    updateRoomState(data.room_state);
});

socket.on('player_list_update', (data) => {
    updateRoomState(data);
});

socket.on('chat_message', (data) => {
    addChatMessage(data.nickname, data.message, data.system, false, data.team_color);
});

socket.on('correct_guess', (data) => {
    addChatMessage(
        'System',
        `${data.nickname} (${data.team_name}) guessed correctly! +${data.points}`,
        false, true
    );
    if (data.team_leaderboard) {
        latestTeams = data.team_leaderboard;
        renderTeams(data.team_leaderboard);
    }
});

socket.on('your_guess_correct', (data) => {
    addSystemMessage(`✓ Correct! Word: "${data.word}". +${data.points} for your team!`);
    chatInput.disabled = true;
    chatInput.placeholder = 'You guessed it!';
});

socket.on('team_scores_update', (data) => {
    if (data.teams) {
        latestTeams = data.teams;
        renderTeams(data.teams);
    }
});

socket.on('game_started', (data) => {
    totalRoundsDisplay.textContent = data.total_rounds;
});

socket.on('start_round', (data) => {
    roomState = 'CHOOSING_WORD';
    currentDrawer = data.drawer;
    currentDrawingTeamId = data.drawing_team_id;
    isDrawer = (currentDrawer === nickname);
    roundNumDisplay.textContent = data.round_number;
    totalRoundsDisplay.textContent = data.total_rounds;

    clearCanvas();
    setChatEnabled(false);  // chat is locked until DRAWING starts
    wordDisplay.textContent = 'Waiting...';
    stopTimer();
    timerDisplay.textContent = '--';
    timerDisplay.classList.remove('urgent');

    // Show banner with the drawing team's color
    showTeamBanner(data.drawing_team_name, data.drawing_team_color);

    if (isDrawer) {
        showOverlay('You are drawing!', 'Choose a word from the popup');
    } else {
        showOverlay(`${escapeHtml(currentDrawer)} (${escapeHtml(data.drawing_team_name)}) is choosing a word...`, '');
    }
    tools.style.display = 'none';
});

socket.on('word_choices', (data) => {
    wordChoicesDiv.innerHTML = '';
    data.words.forEach(word => {
        const btn = document.createElement('button');
        btn.className = 'word-choice-btn';
        btn.textContent = word;
        btn.addEventListener('click', () => {
            socket.emit('select_word', { word });
            wordModal.style.display = 'none';
        });
        wordChoicesDiv.appendChild(btn);
    });
    wordModal.style.display = 'flex';
});

socket.on('round_drawing_start', (data) => {
    roomState = 'DRAWING';   // critical for the canvas mousedown guard
    wordDisplay.textContent = data.word_blanks;
    hideOverlay();

    if (isDrawer) {
        tools.style.display = 'flex';
        canvas.style.cursor = 'crosshair';
    } else {
        tools.style.display = 'none';
        canvas.style.cursor = 'default';
    }

    // Apply chat permissions: drawer's team blocked, others can chat
    applyChatPermissions();
    startTimer(data.time_remaining);
});

socket.on('your_word', (data) => {
    wordDisplay.textContent = data.word;
});

socket.on('draw_data', (data) => {
    applyDrawEvent(data);
});

socket.on('canvas_cleared', () => {
    clearCanvas();
});

socket.on('end_round', (data) => {
    roomState = 'ROUND_END';
    stopTimer();
    tools.style.display = 'none';
    setChatEnabled(true);
    chatInput.placeholder = 'Type your guess...';
    wordDisplay.textContent = data.word || '???';
    hideTeamBanner();

    let reasonMsg = `The word was: "${data.word || 'unknown'}"`;
    if (data.reason === 'admin_skipped') reasonMsg = `Round skipped! Word was: "${data.word || '???'}"`;
    if (data.reason === 'drawer_left') reasonMsg = `Drawer left! Word was: "${data.word || '???'}"`;
    if (data.reason === 'all_guessed') reasonMsg = `Everyone guessed! Word was: "${data.word}"`;

    showOverlay('Round ended!', `${reasonMsg}<br>Next round in 5s...`);
    if (data.team_leaderboard) {
        latestTeams = data.team_leaderboard;
        renderTeams(data.team_leaderboard);
    }
});

socket.on('game_over', (data) => {
    roomState = 'GAME_OVER';
    stopTimer();
    hideTeamBanner();
    finalLeaderboard.innerHTML = '';
    data.team_leaderboard.forEach((t, idx) => {
        const li = document.createElement('li');
        li.style.background = t.color;
        const medal = idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : `${idx + 1}.`;
        li.innerHTML = `<span>${medal} ${escapeHtml(t.name)}</span><span>${t.score} pts</span>`;
        finalLeaderboard.appendChild(li);
    });
    gameOverModal.style.display = 'flex';
});

socket.on('round_in_progress', (data) => {
    // Reconnect path
    roomState = 'DRAWING';
    currentDrawer = data.drawer;
    currentDrawingTeamId = data.drawing_team_id;
    isDrawer = (currentDrawer === nickname);
    wordDisplay.textContent = isDrawer && data.word ? data.word : data.word_blanks;
    hideOverlay();
    if (isDrawer) tools.style.display = 'flex';
    applyChatPermissions();
    startTimer(data.time_remaining);
    if (data.canvas_history && data.canvas_history.length) {
        data.canvas_history.forEach(applyDrawEvent);
    }
});

socket.on('kicked', (data) => {
    document.getElementById('kicked-reason').textContent = data.message || 'You were removed.';
    kickedModal.style.display = 'flex';
    socket.disconnect();
});

// ---- Render helpers ----

function updateRoomState(state) {
    roomState = state.state;
    currentDrawer = state.current_drawer;
    currentDrawingTeamId = state.current_drawing_team_id;
    isDrawer = (currentDrawer === nickname);

    roundNumDisplay.textContent = state.round_number || '-';
    totalRoundsDisplay.textContent = state.total_rounds || '-';

    // Lock indicator
    lockIndicator.style.display = state.room_locked ? 'inline-block' : 'none';

    // Find my team_id by scanning players
    const me = (state.players || []).find(p => p.nickname === nickname);
    myTeamId = me ? me.team_id : null;

    latestTeams = state.teams || [];
    renderTeams(latestTeams);

    if (state.state === 'WAITING') {
        const teamCount = (state.teams || []).length;
        const playerCount = (state.players || []).length;
        if (teamCount === 0) {
            showOverlay('Waiting for admin...', `${playerCount} player(s) in the room`);
        } else {
            const myTeam = latestTeams.find(t => t.team_id === myTeamId);
            const teamName = myTeam ? myTeam.name : 'Unassigned';
            showOverlay(
                'Waiting for admin to start...',
                `You're on <strong style="color:${myTeam ? myTeam.color : '#000'}">${escapeHtml(teamName)}</strong>`
            );
        }
        hideTeamBanner();
    }

    // Update chat permissions if state changed
    if (state.state === 'DRAWING') {
        applyChatPermissions();
    } else if (state.state !== 'DRAWING') {
        // Outside DRAWING, anyone can chat (lobby/round-end)
        if (state.state !== 'GAME_OVER') {
            setChatEnabled(true);
        }
    }
}

function renderTeams(teams) {
    teamsContainer.innerHTML = '';
    teams.forEach(team => {
        const card = document.createElement('div');
        card.className = 'team-card';
        if (team.team_id === currentDrawingTeamId) {
            card.classList.add('is-drawing');
        }
        card.style.borderLeftColor = team.color;

        const playersHtml = (team.players || []).map(p => {
            const classes = ['team-player'];
            if (p.nickname === currentDrawer) classes.push('is-drawer');
            if (p.has_guessed) classes.push('has-guessed');
            if (!p.connected) classes.push('disconnected');
            if (p.nickname === nickname) classes.push('is-you');
            return `<span class="${classes.join(' ')}">${escapeHtml(p.nickname)}${p.nickname === nickname ? ' (you)' : ''}</span>`;
        }).join('');

        card.innerHTML = `
            <div class="team-card-header">
                <span class="team-name" style="color:${team.color}">${escapeHtml(team.name)}</span>
                <span class="team-score">${team.score}</span>
            </div>
            <div class="team-players">${playersHtml || '<em style="color:#9ca3af">No players</em>'}</div>
        `;
        teamsContainer.appendChild(card);
    });
}

function showTeamBanner(teamName, teamColor) {
    if (!teamName) return;
    teamBannerText.textContent = `${teamName.toUpperCase()} IS DRAWING`;
    teamBanner.style.background = teamColor || '#4c1d95';
    teamBanner.style.display = 'block';
}

function hideTeamBanner() {
    teamBanner.style.display = 'none';
}

function showOverlay(title, sub) {
    overlayContent.innerHTML = `<h2>${title}</h2>` + (sub ? `<p>${sub}</p>` : '');
    overlay.classList.remove('hidden');
}

function hideOverlay() {
    overlay.classList.add('hidden');
}

function addChatMessage(nick, message, isSystem, isCorrect, teamColor) {
    const div = document.createElement('div');
    div.className = 'chat-message';
    if (isSystem) div.classList.add('system');
    if (isCorrect) div.classList.add('correct');
    if (nick === nickname) div.classList.add('self');

    if (isSystem) {
        div.textContent = message;
    } else {
        const colorStyle = teamColor ? ` style="color:${teamColor}"` : '';
        div.innerHTML = `<span class="nickname"${colorStyle}>${escapeHtml(nick)}:</span> ${escapeHtml(message)}`;
    }
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function addSystemMessage(message) {
    addChatMessage('System', message, true, false);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text == null ? '' : String(text);
    return div.innerHTML;
}

// ---- Chat permission logic ----

function applyChatPermissions() {
    // Only matters during DRAWING
    if (roomState !== 'DRAWING') {
        setChatEnabled(true);
        chatInput.placeholder = 'Type your guess...';
        return;
    }
    // Drawer: locked
    if (isDrawer) {
        setChatEnabled(false);
        chatInput.placeholder = 'You are drawing — no chat';
        return;
    }
    // Same team as drawer: locked
    if (myTeamId !== null && myTeamId === currentDrawingTeamId) {
        setChatEnabled(false);
        chatInput.placeholder = 'Your team is drawing — wait';
        return;
    }
    setChatEnabled(true);
    chatInput.placeholder = 'Type your guess...';
}

function setChatEnabled(enabled) {
    chatInput.disabled = !enabled;
    chatSubmitBtn.disabled = !enabled;
}

// ---- Timer ----

function startTimer(seconds) {
    stopTimer();
    let remaining = Math.floor(seconds);
    timerDisplay.textContent = remaining;
    timerInterval = setInterval(() => {
        remaining--;
        if (remaining <= 0) {
            timerDisplay.textContent = 0;
            stopTimer();
            return;
        }
        timerDisplay.textContent = remaining;
        if (remaining <= 10) timerDisplay.classList.add('urgent');
        else timerDisplay.classList.remove('urgent');
    }, 1000);
}

function stopTimer() {
    if (timerInterval) { clearInterval(timerInterval); timerInterval = null; }
    timerDisplay.classList.remove('urgent');
}

// ---- Canvas drawing ----

/**
 * Map pointer event to canvas-internal coordinates.
 * Canvas has fixed internal width/height (900x650) but is CSS-scaled to fit
 * its wrapper, so we need to undo the scaling.
 */
function getCanvasCoords(e) {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return {
        x: (clientX - rect.left) * scaleX,
        y: (clientY - rect.top) * scaleY,
    };
}

function startDraw(e) {
    if (!isDrawer || roomState !== 'DRAWING') return;
    e.preventDefault();
    drawing = true;
    const coords = getCanvasCoords(e);
    lastX = coords.x;
    lastY = coords.y;
    drawDot(lastX, lastY);
    emitDrawEvent({
        type: 'dot', x: lastX, y: lastY,
        color: isEraser ? '#ffffff' : currentColor,
        size: currentSize,
    });
}

function moveDraw(e) {
    if (!drawing || !isDrawer) return;
    e.preventDefault();
    const coords = getCanvasCoords(e);
    drawLine(lastX, lastY, coords.x, coords.y, isEraser ? '#ffffff' : currentColor, currentSize);
    emitDrawEvent({
        type: 'line', x1: lastX, y1: lastY, x2: coords.x, y2: coords.y,
        color: isEraser ? '#ffffff' : currentColor,
        size: currentSize,
    });
    lastX = coords.x;
    lastY = coords.y;
}

function endDraw() { drawing = false; }

function drawLine(x1, y1, x2, y2, color, size) {
    ctx.strokeStyle = color;
    ctx.lineWidth = size;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
}

function drawDot(x, y) {
    ctx.fillStyle = isEraser ? '#ffffff' : currentColor;
    ctx.beginPath();
    ctx.arc(x, y, currentSize / 2, 0, Math.PI * 2);
    ctx.fill();
}

function clearCanvas() {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
}

function applyDrawEvent(data) {
    if (data.type === 'line') {
        drawLine(data.x1, data.y1, data.x2, data.y2, data.color, data.size);
    } else if (data.type === 'dot') {
        ctx.fillStyle = data.color;
        ctx.beginPath();
        ctx.arc(data.x, data.y, data.size / 2, 0, Math.PI * 2);
        ctx.fill();
    } else if (data.type === 'clear') {
        clearCanvas();
    }
}

function emitDrawEvent(data) {
    socket.emit('draw_event', data);
}

canvas.addEventListener('mousedown', startDraw);
canvas.addEventListener('mousemove', moveDraw);
canvas.addEventListener('mouseup', endDraw);
canvas.addEventListener('mouseleave', endDraw);
canvas.addEventListener('touchstart', startDraw, { passive: false });
canvas.addEventListener('touchmove', moveDraw, { passive: false });
canvas.addEventListener('touchend', endDraw);

clearCanvas();

// ---- Tool controls ----

document.querySelectorAll('.color-swatch').forEach(swatch => {
    swatch.addEventListener('click', () => {
        document.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
        swatch.classList.add('active');
        currentColor = swatch.dataset.color;
        isEraser = false;
        document.getElementById('eraser-btn').classList.remove('active');
        document.getElementById('brush-btn').classList.add('active');
    });
});

const brushSizeInput = document.getElementById('brush-size');
const brushSizeDisplay = document.getElementById('brush-size-display');
brushSizeInput.addEventListener('input', () => {
    currentSize = parseInt(brushSizeInput.value);
    brushSizeDisplay.textContent = currentSize;
});

document.getElementById('brush-btn').addEventListener('click', () => {
    isEraser = false;
    document.getElementById('brush-btn').classList.add('active');
    document.getElementById('eraser-btn').classList.remove('active');
});

document.getElementById('eraser-btn').addEventListener('click', () => {
    isEraser = true;
    document.getElementById('eraser-btn').classList.add('active');
    document.getElementById('brush-btn').classList.remove('active');
});

document.getElementById('clear-btn').addEventListener('click', () => {
    if (!isDrawer) return;
    clearCanvas();
    socket.emit('clear_canvas');
});

// ---- Chat ----

chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const message = chatInput.value.trim();
    if (!message) return;
    if (chatInput.disabled) return;
    socket.emit('guess_event', { message });
    chatInput.value = '';
});

// ---- Other UI controls ----

backToLobbyBtn.addEventListener('click', () => {
    gameOverModal.style.display = 'none';
    chatMessages.innerHTML = '';
});

copyCodeBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(roomCode).then(() => {
        copyCodeBtn.textContent = '✓';
        setTimeout(() => { copyCodeBtn.textContent = '📋'; }, 1500);
    }).catch(() => prompt('Copy this room code:', roomCode));
});

window.addEventListener('beforeunload', (e) => {
    // Warn the player if game is in progress — refreshing will disconnect them
    if (roomState !== 'WAITING' && roomState !== 'GAME_OVER') {
        e.preventDefault();
        // Most browsers show a generic prompt; returnValue is required for Chrome
        e.returnValue = 'Game is in progress — leaving will disconnect you!';
        return e.returnValue;
    }
    socket.emit('leave_room');
});
