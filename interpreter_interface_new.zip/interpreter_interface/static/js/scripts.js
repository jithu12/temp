document.addEventListener("DOMContentLoaded", function() {
    const dateInput = document.getElementById('meetingDate');
    const typeOnline = document.getElementById('typeOnline');
    const typeOffline = document.getElementById('typeOffline');

    function updateMinDate() {
        if (!dateInput) return;
        
        // Online: 1 day gap (Today + 2 days)
        // Offline: 2 days gap (Today + 3 days)
        const isOnline = document.getElementById('typeOnline').checked;
        const daysToAdd = isOnline ? 2 : 3;

        const today = new Date();
        const minDate = new Date(today);
        minDate.setDate(today.getDate() + daysToAdd);
        
        const yyyy = minDate.getFullYear();
        let mm = minDate.getMonth() + 1;
        let dd = minDate.getDate();
        
        if (mm < 10) mm = '0' + mm;
        if (dd < 10) dd = '0' + dd;
        
        dateInput.setAttribute('min', yyyy + '-' + mm + '-' + dd);
    }

    if (dateInput) {
        // Initialize on load
        updateMinDate();

        // Update when radio buttons change
        if (typeOnline) typeOnline.addEventListener('change', updateMinDate);
        if (typeOffline) typeOffline.addEventListener('change', updateMinDate);
        
        // Disable weekends on input change (UX only, backend handles strict check)
        dateInput.addEventListener('input', function(e) {
            const day = new Date(this.value).getUTCDay();
            if([6,0].includes(day)){
                alert('Weekends are not allowed!');
                this.value = '';
            }
        });
    }
});

function toggleFields() {
    const isOnline = document.getElementById('typeOnline').checked;
    const linkField = document.getElementById('linkField');
    const locationField = document.getElementById('locationField');
    const linkInput = linkField.querySelector('input');
    const locInput = locationField.querySelector('input');

    if (isOnline) {
        linkField.classList.remove('d-none');
        locationField.classList.add('d-none');
        linkInput.required = true;
        locInput.required = false;
    } else {
        linkField.classList.add('d-none');
        locationField.classList.remove('d-none');
        linkInput.required = false;
        locInput.required = true;
    }
}
