from app import app
from models import db

with app.app_context():
    db.drop_all()  # Drops existing tables to clear the old schema
    db.create_all()
    print("Database tables dropped and recreated with new columns!")