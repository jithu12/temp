from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_login import UserMixin

db = SQLAlchemy()

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)

    def __repr__(self):
        return f'<User {self.username}>'

class InterpreterRequest(db.Model):
    __tablename__ = 'interpreter_requests'

    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.String(50), nullable=False)
    employee_name = db.Column(db.String(100), nullable=False)
    employee_email = db.Column(db.String(120), nullable=False)
    department = db.Column(db.String(100), nullable=False)
    
    # 'Online' or 'Offline'
    meeting_type = db.Column(db.String(20), nullable=False)
    meeting_date = db.Column(db.Date, nullable=False)
    meeting_time = db.Column(db.Time, nullable=False)
    
    meeting_link = db.Column(db.String(255), nullable=True)
    location = db.Column(db.String(255), nullable=True)
    
    purpose = db.Column(db.Text, nullable=False)
    notes = db.Column(db.Text, nullable=True)
    ics_file_path = db.Column(db.String(255), nullable=True)
    
    # Status: Sent to V-shesh, Confirmed, Security Requested, Completed
    status = db.Column(db.String(50), default='Sent to V-shesh')
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Request {self.id} - {self.employee_name}>'
