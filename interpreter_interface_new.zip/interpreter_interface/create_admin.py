import getpass
from app import app, bcrypt
from models import db, User

def main():
    """
    A command-line script to create a new admin user.
    """
    with app.app_context():
        print("--- Create Admin User ---")
        username = input("Enter username: ")
        
        if User.query.filter_by(username=username).first():
            print(f"Error: User '{username}' already exists.")
            return

        password = getpass.getpass("Enter password: ")
        confirm_password = getpass.getpass("Confirm password: ")

        if password != confirm_password:
            print("Error: Passwords do not match.")
            return

        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        new_user = User(username=username, password_hash=hashed_password)
        
        db.session.add(new_user)
        db.session.commit()
        print(f"Admin user '{username}' created successfully!")

if __name__ == '__main__':
    main()