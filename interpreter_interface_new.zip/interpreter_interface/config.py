import os

class Config:
    # App Secret Key
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-prod'
    
    # Database
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    SQLALCHEMY_DATABASE_URI = "postgresql://jp:jp123@localhost:5432/interpreter_db"
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Email Configuration (SMTP)
    MAIL_SERVER = os.environ.get('MAIL_SERVER') or 'smtp.gmail.com'
    MAIL_PORT = int(os.environ.get('MAIL_PORT') or 587)
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME') or 'your-email@example.com'
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD') or 'your-email-password'
    
    # V-shesh Contact
    V_SHESH_EMAIL = 'requests@v-shesh.example.com'
    SECURITY_EMAIL = 'security@company.com'
