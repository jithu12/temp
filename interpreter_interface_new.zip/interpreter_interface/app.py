from flask import Flask
import os
from flask_login import LoginManager
from flask_bcrypt import Bcrypt
from config import Config
from models import db, User

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

# Configure upload folder
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@login_manager.user_loader
def load_user(user_id):
    """
    This function is required by Flask-Login to retrieve a user from the database
    given their user ID.
    """
    return User.query.get(int(user_id))

from routes import register_routes
register_routes(app, bcrypt)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
