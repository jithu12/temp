import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from config import Config

class Mailer:
    @staticmethod
    def send_email(to_email, subject, body, attachment_path=None):
        try:
            msg = MIMEMultipart()
            msg['From'] = Config.MAIL_USERNAME
            msg['To'] = to_email
            msg['Subject'] = subject

            msg.attach(MIMEText(body, 'html'))

            if attachment_path and os.path.exists(attachment_path):
                with open(attachment_path, "rb") as f:
                    part = MIMEApplication(f.read(), Name=os.path.basename(attachment_path))
                    part['Content-Disposition'] = f'attachment; filename="{os.path.basename(attachment_path)}"'
                    msg.attach(part)

            # In a real production app, use Celery for async emailing
            # For this requirement, synchronous sending is implemented
            server = smtplib.SMTP(Config.MAIL_SERVER, Config.MAIL_PORT)
            server.starttls()
            server.login(Config.MAIL_USERNAME, Config.MAIL_PASSWORD)
            text = msg.as_string()
            server.sendmail(Config.MAIL_USERNAME, to_email, text)
            server.quit()
            print(f"Email sent to {to_email}")
            return True
        except Exception as e:
            print(f"Failed to send email: {e}")
            return False

    @staticmethod
    def send_employee_confirmation(req):
        subject = f"Interpreter Request Received - ID #{req.id}"
        body = f"""
        <h3>Request Received</h3>
        <p>Hi {req.employee_name},</p>
        <p>We have received your request for an interpreter.</p>
        <ul>
            <li><strong>Date:</strong> {req.meeting_date}</li>
            <li><strong>Time:</strong> {req.meeting_time}</li>
            <li><strong>Type:</strong> {req.meeting_type}</li>
        </ul>
        <p>Status: <strong>{req.status}</strong></p>
        """
        Mailer.send_email(req.employee_email, subject, body)

    @staticmethod
    def send_to_vshesh(req):
        subject = f"Interpreter Request - {req.meeting_date} - {req.employee_name}"
        location_info = f"Link: {req.meeting_link}" if req.meeting_type == 'Online' else f"Location: {req.location}"
        
        body = f"""
        <h3>New Interpreter Request</h3>
        <p><strong>Employee:</strong> {req.employee_name} (ID: {req.employee_id})</p>
        <p><strong>Date:</strong> {req.meeting_date}</p>
        <p><strong>Time:</strong> {req.meeting_time}</p>
        <p><strong>Type:</strong> {req.meeting_type}</p>
        <p><strong>{location_info}</strong></p>
        <p><strong>Purpose:</strong> {req.purpose}</p>
        <p><strong>Notes:</strong> {req.notes}</p>
        """
        Mailer.send_email(Config.V_SHESH_EMAIL, subject, body, attachment_path=req.ics_file_path)

    @staticmethod
    def send_confirmation_update(req):
        subject = f"Interpreter Confirmed - ID #{req.id}"
        body = f"""
        <h3>Good News!</h3>
        <p>Your interpreter request for <strong>{req.meeting_date}</strong> has been confirmed.</p>
        """
        Mailer.send_email(req.employee_email, subject, body)

    @staticmethod
    def send_security_request(req):
        subject = f"Visitor Pass Request - Interpreter - {req.meeting_date}"
        body = f"""
        <h3>Visitor Access Required</h3>
        <p>An interpreter will be visiting for a meeting.</p>
        <p><strong>Host:</strong> {req.employee_name}</p>
        <p><strong>Date:</strong> {req.meeting_date}</p>
        <p><strong>Time:</strong> {req.meeting_time}</p>
        <p><strong>Location:</strong> {req.location}</p>
        <p>Please arrange a visitor pass.</p>
        """
        Mailer.send_email(Config.SECURITY_EMAIL, subject, body)
