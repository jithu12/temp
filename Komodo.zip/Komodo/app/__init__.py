from flask import Flask
import os

def create_app():
    app = Flask(__name__)
    app.config.from_object('config.Config')

    # Ensure sites directory exists
    if not os.path.exists(app.config['SITES_DIR']):
        os.makedirs(app.config['SITES_DIR'])

    # Register blueprints
    from app.auth import auth_bp
    from app.admin import admin_bp
    from app.sites import sites_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(sites_bp)

    # Wrap the application with the dynamic site loading middleware
    from app.middleware import MultiSiteMiddleware
    app.wsgi_app = MultiSiteMiddleware(app.wsgi_app, app.config['SITES_DIR'])

    return app
