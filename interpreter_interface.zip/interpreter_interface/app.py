from flask import Flask, render_template, request, redirect, url_for, flash
import os
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta, date
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_bcrypt import Bcrypt
from config import Config
from models import db, InterpreterRequest, User
from mailer import Mailer

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

# Configure upload folder
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@login_manager.user_loader
def load_user(user_id):
    """
    This function is required by Flask-Login to retrieve a user from the database
    given their user ID.
    """
    return User.query.get(int(user_id))

# --- Helpers ---

def is_business_day(check_date):
    # 0=Monday, 6=Sunday. >=5 is Weekend.
    if check_date.weekday() >= 5:
        return False
    return True

def validate_timeline(meeting_date, meeting_type):
    today = date.today()
    delta = (meeting_date - today).days
    
    if delta < 0:
        return False, "Meeting date cannot be in the past."
    
    if not is_business_day(meeting_date):
        return False, "Meetings cannot be scheduled on weekends or holidays."

    if meeting_type == 'Online':
        if delta < 2:
            return False, "Online meetings require at least 1 day gap (2 days notice)."
    elif meeting_type == 'Offline':
        if delta < 3:
            return False, "Offline meetings require at least 2 days gap (3 days notice)."
            
    return True, ""

# --- Routes ---

@app.route('/')
def index():
    return redirect(url_for('request_form'))

@app.route('/request', methods=['GET', 'POST'])
def request_form():
    if request.method == 'POST':
        try:
            # Extract data
            emp_id = request.form['employee_id']
            name = request.form['employee_name']
            email = request.form['employee_email']
            dept = request.form['department']
            m_type = request.form['meeting_type']
            m_date_str = request.form['meeting_date']
            m_time_str = request.form['meeting_time']
            link = request.form.get('meeting_link')
            loc = request.form.get('location')
            purpose = request.form['purpose']
            notes = request.form.get('notes')

            # Parse Date/Time
            m_date = datetime.strptime(m_date_str, '%Y-%m-%d').date()
            m_time = datetime.strptime(m_time_str, '%H:%M').time()

            # Validation
            is_valid, error_msg = validate_timeline(m_date, m_type)
            if not is_valid:
                flash(error_msg, 'danger')
                return render_template('request_form.html', form_data=request.form)

            if m_type == 'Online' and not link:
                flash('Meeting link is required for Online meetings.', 'danger')
                return render_template('request_form.html', form_data=request.form)
            if m_type == 'Offline' and not loc:
                flash('Location is required for Offline meetings.', 'danger')
                return render_template('request_form.html', form_data=request.form)

            # Handle optional ICS file upload for Online meetings
            ics_file_path = None
            if m_type == 'Online':
                ics_file = request.files.get('ics_file')
                if ics_file and ics_file.filename.endswith('.ics'):
                    filename = secure_filename(ics_file.filename)
                    filename = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{filename}"
                    ics_file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    ics_file.save(ics_file_path)

            # Save to DB
            new_req = InterpreterRequest(
                employee_id=emp_id,
                employee_name=name,
                employee_email=email,
                department=dept,
                meeting_type=m_type,
                meeting_date=m_date,
                meeting_time=m_time,
                meeting_link=link,
                location=loc,
                purpose=purpose,
                notes=notes,
                status='Sent to V-shesh',
                ics_file_path=ics_file_path
            )
            db.session.add(new_req)
            db.session.commit()

            # Email Automation
            Mailer.send_employee_confirmation(new_req)
            Mailer.send_to_vshesh(new_req)

            flash(f'Request submitted successfully! Reference ID: {new_req.id}', 'success')
            return redirect(url_for('status_page'))

        except Exception as e:
            flash(f'Error submitting request: {str(e)}', 'danger')
            return render_template('request_form.html', form_data=request.form)

    return render_template('request_form.html', form_data={})

@app.route('/status', methods=['GET', 'POST'])
def status_page():
    requests = []
    if request.method == 'POST':
        email = request.form.get('email')
        if email:
            requests = InterpreterRequest.query.filter_by(employee_email=email).order_by(InterpreterRequest.created_at.desc()).all()
    return render_template('status.html', requests=requests)

# --- Auth Routes ---

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('admin_dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()

        if user and bcrypt.check_password_hash(user.password_hash, password):
            login_user(user)
            next_page = request.args.get('next')
            flash('Login successful. Welcome!', 'success')
            return redirect(next_page or url_for('admin_dashboard'))
        else:
            flash('Login Unsuccessful. Please check username and password.', 'danger')
            
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

# --- Admin Routes ---

@app.route('/admin')
@login_required
def admin_dashboard():
    all_requests = InterpreterRequest.query.order_by(InterpreterRequest.created_at.desc()).all()
    
    # Auto-complete past requests
    today = date.today()
    for req in all_requests:
        if req.meeting_date < today and req.status != 'Completed':
            req.status = 'Completed'
    db.session.commit()

    counts = {
        'total': len(all_requests),
        'vshesh': sum(1 for r in all_requests if r.status == 'Sent to V-shesh'),
        'security': sum(1 for r in all_requests if r.status == 'Security Requested'),
        'completed': sum(1 for r in all_requests if r.status == 'Completed')
    }
    
    return render_template('dashboard.html', requests=all_requests, counts=counts)

@app.route('/admin/action/<int:req_id>/<action>')
@login_required
def admin_action(req_id, action):
    req = InterpreterRequest.query.get_or_404(req_id)
    
    if action == 'confirm':
        req.status = 'Confirmed'
        Mailer.send_confirmation_update(req)
        flash(f'Request #{req.id} marked as Confirmed.', 'success')
        
    elif action == 'send_security':
        if req.meeting_type == 'Offline':
            req.status = 'Security Requested'
            Mailer.send_security_request(req)
            flash(f'Security request sent for #{req.id}.', 'warning')
        else:
            flash('Security request is only for Offline meetings.', 'danger')

    db.session.commit()
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/delete/<int:req_id>', methods=['POST'])
@login_required
def delete_request(req_id):
    req = InterpreterRequest.query.get_or_404(req_id)
    db.session.delete(req)
    db.session.commit()
    flash(f'Request #{req_id} deleted successfully.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/edit/<int:req_id>', methods=['GET', 'POST'])
@login_required
def edit_request(req_id):
    req = InterpreterRequest.query.get_or_404(req_id)
    
    if request.method == 'POST':
        req.employee_id = request.form['employee_id']
        req.employee_name = request.form['employee_name']
        req.employee_email = request.form['employee_email']
        req.department = request.form['department']
        req.meeting_type = request.form['meeting_type']
        req.meeting_date = datetime.strptime(request.form['meeting_date'], '%Y-%m-%d').date()
        req.meeting_time = datetime.strptime(request.form['meeting_time'], '%H:%M').time()
        req.meeting_link = request.form.get('meeting_link')
        req.location = request.form.get('location')
        req.purpose = request.form['purpose']
        req.notes = request.form.get('notes')
        
        db.session.commit()
        flash('Request updated successfully.', 'success')
        return redirect(url_for('admin_dashboard'))
        
    return render_template('edit_request.html', req=req)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
