import subprocess
import threading
from app.socket import socketio

# Dictionary to hold active processes
# Key: session_id, Value: subprocess.Popen object
active_terminals = {}

# Dictionary to hold line buffers for each session
input_buffers = {}

def read_and_emit(process, session_id):
    """Reads stdout from the subprocess and emits it to the connected client."""
    try:
        # Read output byte by byte to ensure real-time streaming
        while True:
            char = process.stdout.read(1)
            if not char:
                break
            
            # Try to decode the character. On Windows, it could be cp1252 or utf-8 depending on the console.
            # Using errors='replace' to prevent crashing on un-decodable bytes.
            try:
                text = char.decode('utf-8', errors='replace')
            except Exception:
                text = '?'
            
            # Emit character to the specific session
            socketio.emit('terminal_output', {'output': text}, to=session_id)
            
    except Exception as e:
        print(f"Error reading process output: {e}")
    finally:
        socketio.emit('terminal_output', {'output': '\r\n[Process terminated]\r\n'}, to=session_id)
        if session_id in active_terminals:
            del active_terminals[session_id]

@socketio.on('connect')
def handle_connect():
    pass

@socketio.on('disconnect')
def handle_disconnect():
    from flask import request
    session_id = request.sid
    if session_id in active_terminals:
        process = active_terminals[session_id]
        process.terminate()
        del active_terminals[session_id]
    if session_id in input_buffers:
        del input_buffers[session_id]

@socketio.on('start_terminal')
def handle_start_terminal(data):
    from flask import request
    session_id = request.sid
    
    if session_id in active_terminals:
        return
    
    # Start a cmd.exe process
    # Use CREATE_NO_WINDOW if we don't want a console window to pop up on the server
    import subprocess
    import sys
    import os
    
    kwargs = {}
    if sys.platform == 'win32':
        kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
        cmd = ['cmd.exe']
    else:
        cmd = ['bash']

    try:
        process = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=0,
            **kwargs
        )
        
        active_terminals[session_id] = process
        input_buffers[session_id] = ""
        
        # Start background thread to read output
        thread = threading.Thread(target=read_and_emit, args=(process, session_id))
        thread.daemon = True
        thread.start()
        
    except Exception as e:
        socketio.emit('terminal_output', {'output': f'\r\nError starting terminal: {e}\r\n'}, to=session_id)

@socketio.on('terminal_input')
def handle_terminal_input(data):
    from flask import request
    session_id = request.sid
    
    if session_id in active_terminals:
        process = active_terminals[session_id]
        input_data = data.get('input', '')
        
        if session_id not in input_buffers:
            input_buffers[session_id] = ""
            
        if process.stdin:
            try:
                # Handle Backspace
                if input_data == '\x7f' or input_data == '\x08':
                    if len(input_buffers[session_id]) > 0:
                        input_buffers[session_id] = input_buffers[session_id][:-1]
                        socketio.emit('terminal_output', {'output': '\b \b'}, to=session_id)
                # Handle Enter
                elif input_data == '\r' or input_data == '\n':
                    input_buffers[session_id] += '\n'
                    socketio.emit('terminal_output', {'output': '\r\n'}, to=session_id)
                    
                    # Write the complete line to stdin and flush
                    process.stdin.write(input_buffers[session_id].encode('utf-8'))
                    process.stdin.flush()
                    
                    # Clear buffer
                    input_buffers[session_id] = ""
                else:
                    # Ignore escape sequences (like arrows) to avoid breaking the buffer
                    if '\x1b' not in input_data:
                        input_buffers[session_id] += input_data
                        # Echo normal characters back to the terminal
                        socketio.emit('terminal_output', {'output': input_data}, to=session_id)

            except Exception as e:
                print(f"Error writing to process stdin: {e}")
