import os
import sys
import importlib.util

class MultiSiteMiddleware:
    """
    WSGI Middleware that intercepts requests to /<site_name>.
    If the site folder contains an app.py, it dynamically loads the Flask app
    and delegates the request to it.
    Otherwise, it falls back to the main app (which serves static files).
    """
    def __init__(self, app, sites_dir):
        self.app = app
        self.sites_dir = os.path.abspath(sites_dir)
        self.loaded_apps = {}
        self.app_mtimes = {}

    def __call__(self, environ, start_response):
        path = environ.get('PATH_INFO', '')
        parts = path.lstrip('/').split('/')
        
        # Reserved routes for the main platform
        reserved_routes = ['admin', 'login', 'logout', 'static']
        
        if parts and parts[0] and parts[0] not in reserved_routes:
            site_name = parts[0]
            site_path = os.path.abspath(os.path.join(self.sites_dir, site_name))
            
            # Security check: ensure path is within sites_dir
            if site_path.startswith(self.sites_dir + os.sep) or site_path == self.sites_dir:
                if os.path.exists(os.path.join(site_path, '.disabled')):
                    response_body = b"<html><body><h1>Site Not Available</h1><p>This site is currently disabled.</p></body></html>"
                    start_response('503 Service Unavailable', [
                        ('Content-Type', 'text/html; charset=utf-8'),
                        ('Content-Length', str(len(response_body)))
                    ])
                    return [response_body]
                    
                app_py = os.path.join(site_path, 'app.py')
                
                if os.path.exists(app_py):
                    mtime = os.path.getmtime(app_py)
                    
                    # Load or reload the app if modified
                    if site_name not in self.loaded_apps or self.app_mtimes.get(site_name) != mtime:
                        try:
                            # Add site directory to python path for local imports
                            if site_path not in sys.path:
                                sys.path.insert(0, site_path)
                                
                            # Force reload of local modules to prevent collisions with master app
                            local_modules = []
                            if os.path.exists(site_path):
                                for f in os.listdir(site_path):
                                    if f.endswith('.py') and f != '__init__.py':
                                        local_modules.append(f[:-3])
                                    elif os.path.isdir(os.path.join(site_path, f)) and os.path.exists(os.path.join(site_path, f, '__init__.py')):
                                        local_modules.append(f)
                            
                            for mod in local_modules:
                                if mod in sys.modules:
                                    sys.modules.pop(mod)
                                    
                            spec = importlib.util.spec_from_file_location(f"site_{site_name}_{mtime}", app_py)
                            site_module = importlib.util.module_from_spec(spec)
                            
                            # MUST add to sys.modules so Flask( __name__ ) finds the correct root_path
                            sys.modules[spec.name] = site_module
                            
                            spec.loader.exec_module(site_module)
                            
                            # Find the WSGI application object
                            if hasattr(site_module, 'app'):
                                self.loaded_apps[site_name] = site_module.app
                                self.app_mtimes[site_name] = mtime
                            elif hasattr(site_module, 'application'):
                                self.loaded_apps[site_name] = site_module.application
                                self.app_mtimes[site_name] = mtime
                                
                        except Exception as e:
                            import traceback
                            error_msg = f"Error loading dynamically: {site_name}\n\n{traceback.format_exc()}"
                            print(error_msg)
                            self.loaded_apps[site_name] = f"ERROR: {e}"
                            self.app_mtimes[site_name] = mtime
                    
                    site_app = self.loaded_apps.get(site_name)
                    if site_app:
                        if isinstance(site_app, str) and site_app.startswith("ERROR:"):
                            # Return a 500 response with the error
                            response_body = f"<html><body><h1>Internal Server Error</h1><p>The Flask application for this site failed to load.</p><pre>{site_app}</pre></body></html>".encode('utf-8')
                            start_response('500 Internal Server Error', [
                                ('Content-Type', 'text/html; charset=utf-8'),
                                ('Content-Length', str(len(response_body)))
                            ])
                            return [response_body]
                            
                        # Rewrite WSGI environment so the sub-app knows its root path
                        script_name = environ.get('SCRIPT_NAME', '') + '/' + site_name
                        path_info = '/' + '/'.join(parts[1:])
                        environ['SCRIPT_NAME'] = script_name
                        environ['PATH_INFO'] = path_info
                        return site_app(environ, start_response)
                        
        # Fallback to main app (static file serving or admin panel)
        return self.app(environ, start_response)
