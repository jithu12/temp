from flask import Blueprint, render_template, request, redirect, url_for, session, current_app, flash, send_file, Response
import os
import shutil
from app.auth import login_required
from app.utils import safe_join, create_zip_from_folder
from werkzeug.utils import secure_filename

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/')
@login_required
def dashboard():
    sites_dir = current_app.config['SITES_DIR']
    sites = []
    if os.path.exists(sites_dir):
        for name in os.listdir(sites_dir):
            site_path = os.path.join(sites_dir, name)
            if os.path.isdir(site_path):
                sites.append({
                    'name': name,
                    'enabled': not os.path.exists(os.path.join(site_path, '.disabled'))
                })
    return render_template('dashboard.html', sites=sites)

@admin_bp.route('/create_site', methods=['POST'])
@login_required
def create_site():
    site_name = secure_filename(request.form.get('site_name', ''))
    if not site_name:
        flash('Site name is required.', 'error')
        return redirect(url_for('admin.dashboard'))
    
    sites_dir = current_app.config['SITES_DIR']
    site_path = safe_join(sites_dir, site_name)
    
    if os.path.exists(site_path):
        flash('Site already exists.', 'error')
    else:
        os.makedirs(site_path)
        # Create a default index.html
        index_content = f"<!DOCTYPE html>\n<html>\n<head>\n<title>{site_name}</title>\n</head>\n<body>\n<h1>Welcome to {site_name}</h1>\n</body>\n</html>"
        with open(os.path.join(site_path, 'index.html'), 'w', encoding='utf-8') as f:
            f.write(index_content)
        flash('Site created successfully.', 'success')
        
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/delete_site/<site_name>', methods=['POST'])
@login_required
def delete_site(site_name):
    try:
        site_path = safe_join(current_app.config['SITES_DIR'], site_name)
        if os.path.exists(site_path):
            shutil.rmtree(site_path)
            flash(f'Site {site_name} deleted.', 'success')
        else:
            flash('Site not found.', 'error')
    except Exception as e:
        flash(f'Error deleting site: {str(e)}', 'error')
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/toggle_site/<site_name>', methods=['POST'])
@login_required
def toggle_site(site_name):
    try:
        site_path = safe_join(current_app.config['SITES_DIR'], site_name)
        if os.path.exists(site_path):
            disabled_file = os.path.join(site_path, '.disabled')
            if os.path.exists(disabled_file):
                os.remove(disabled_file)
                flash(f'Site {site_name} enabled.', 'success')
            else:
                with open(disabled_file, 'w') as f:
                    f.write('')
                flash(f'Site {site_name} disabled.', 'warning')
        else:
            flash('Site not found.', 'error')
    except Exception as e:
        flash(f'Error toggling site: {str(e)}', 'error')
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/download_site/<site_name>')
@login_required
def download_site(site_name):
    try:
        site_path = safe_join(current_app.config['SITES_DIR'], site_name)
        if not os.path.exists(site_path):
            flash('Site not found.', 'error')
            return redirect(url_for('admin.dashboard'))
        
        memory_file = create_zip_from_folder(site_path)
        return send_file(
            memory_file,
            mimetype='application/zip',
            as_attachment=True,
            download_name=f"{site_name}.zip"
        )
    except Exception as e:
        flash(f'Error downloading site: {str(e)}', 'error')
        return redirect(url_for('admin.dashboard'))

@admin_bp.route('/manager/<site_name>', defaults={'subpath': ''})
@admin_bp.route('/manager/<site_name>/<path:subpath>')
@login_required
def manager(site_name, subpath):
    try:
        sites_dir = current_app.config['SITES_DIR']
        site_path = safe_join(sites_dir, site_name)
        current_path = safe_join(site_path, subpath)
        
        if not os.path.exists(current_path) or not os.path.isdir(current_path):
            flash('Directory not found.', 'error')
            return redirect(url_for('admin.dashboard'))
        
        items = []
        for item_name in os.listdir(current_path):
            item_path = os.path.join(current_path, item_name)
            items.append({
                'name': item_name,
                'is_dir': os.path.isdir(item_path),
                'path': os.path.relpath(item_path, site_path).replace('\\', '/')
            })
            
        # Sort so directories are first
        items.sort(key=lambda x: (not x['is_dir'], x['name'].lower()))
        
        parent_path = ''
        if subpath:
            parent_path = os.path.dirname(subpath).replace('\\', '/')
            
        return render_template('manager.html', site_name=site_name, items=items, subpath=subpath, parent_path=parent_path)
    except ValueError:
        flash('Invalid path.', 'error')
        return redirect(url_for('admin.dashboard'))

@admin_bp.route('/upload/<site_name>', methods=['POST'])
@login_required
def upload_file(site_name):
    subpath = request.form.get('subpath', '')
    try:
        site_path = safe_join(current_app.config['SITES_DIR'], site_name)
        target_dir = safe_join(site_path, subpath)
        
        if 'file' not in request.files:
            flash('No file part', 'error')
            return redirect(url_for('admin.manager', site_name=site_name, subpath=subpath))
            
        file = request.files['file']
        if file.filename == '':
            flash('No selected file', 'error')
            return redirect(url_for('admin.manager', site_name=site_name, subpath=subpath))
            
        if file:
            filename = secure_filename(file.filename)
            file.save(os.path.join(target_dir, filename))
            flash('File uploaded successfully.', 'success')
    except Exception as e:
        flash(f'Error uploading file: {str(e)}', 'error')
        
    return redirect(url_for('admin.manager', site_name=site_name, subpath=subpath))

@admin_bp.route('/delete/<site_name>', methods=['POST'])
@login_required
def delete_item(site_name):
    item_path = request.form.get('item_path')
    try:
        site_path = safe_join(current_app.config['SITES_DIR'], site_name)
        full_path = safe_join(site_path, item_path)
        
        if os.path.isdir(full_path):
            shutil.rmtree(full_path)
        else:
            os.remove(full_path)
        flash('Item deleted.', 'success')
    except Exception as e:
        flash(f'Error deleting item: {str(e)}', 'error')
        
    subpath = os.path.dirname(item_path).replace('\\', '/')
    return redirect(url_for('admin.manager', site_name=site_name, subpath=subpath))

@admin_bp.route('/editor/<site_name>/<path:filepath>', methods=['GET', 'POST'])
@login_required
def editor(site_name, filepath):
    try:
        site_path = safe_join(current_app.config['SITES_DIR'], site_name)
        full_path = safe_join(site_path, filepath)
        subpath = os.path.dirname(filepath).replace('\\', '/')
        
        if request.method == 'POST':
            content = request.form.get('content', '')
            # Handle Windows line endings if needed, but saving as utf-8 is fine
            with open(full_path, 'w', encoding='utf-8', newline='') as f:
                f.write(content)
            flash('File saved successfully.', 'success')
            return redirect(url_for('admin.manager', site_name=site_name, subpath=subpath))
            
        if not os.path.exists(full_path) or not os.path.isfile(full_path):
            flash('File not found.', 'error')
            return redirect(url_for('admin.manager', site_name=site_name, subpath=subpath))
            
        with open(full_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        return render_template('editor.html', site_name=site_name, filepath=filepath, content=content, subpath=subpath)
    except UnicodeDecodeError:
        flash('Cannot edit binary files.', 'error')
        return redirect(url_for('admin.manager', site_name=site_name, subpath=subpath))
    except Exception as e:
        flash(f'Error: {str(e)}', 'error')
        return redirect(url_for('admin.dashboard'))

@admin_bp.route('/create_file/<site_name>', methods=['POST'])
@login_required
def create_file(site_name):
    subpath = request.form.get('subpath', '')
    filename = secure_filename(request.form.get('filename', ''))
    is_dir = request.form.get('is_dir') == 'true'
    
    if not filename:
        flash('Name is required.', 'error')
        return redirect(url_for('admin.manager', site_name=site_name, subpath=subpath))
        
    try:
        site_path = safe_join(current_app.config['SITES_DIR'], site_name)
        target_dir = safe_join(site_path, subpath)
        new_path = safe_join(target_dir, filename)
        
        if os.path.exists(new_path):
            flash('Item already exists.', 'error')
        else:
            if is_dir:
                os.makedirs(new_path)
            else:
                with open(new_path, 'w', encoding='utf-8') as f:
                    f.write('')
            flash('Created successfully.', 'success')
    except Exception as e:
        flash(f'Error creating item: {str(e)}', 'error')
        
    return redirect(url_for('admin.manager', site_name=site_name, subpath=subpath))

@admin_bp.route('/restart', methods=['POST'])
@login_required
def restart():
    """Attempt to reload the app by touching wsgi.py"""
    try:
        wsgi_path = os.path.abspath(os.path.join(current_app.config['BASE_DIR'], 'wsgi.py'))
        if os.path.exists(wsgi_path):
            os.utime(wsgi_path, None)
            flash('App restart signal sent (if using Gunicorn/uWSGI).', 'success')
        else:
            flash('wsgi.py not found. Cannot auto-restart.', 'warning')
    except Exception as e:
        flash(f'Error attempting restart: {str(e)}', 'error')
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/terminal')
@login_required
def terminal():
    return render_template('terminal.html')
