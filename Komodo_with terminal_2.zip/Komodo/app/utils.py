import os
import zipfile
import io

def safe_join(base_dir, *paths):
    """
    Safely join paths to ensure the resulting path falls strictly 
    within the base_dir to prevent directory traversal attacks.
    """
    base_dir = os.path.abspath(base_dir)
    final_path = os.path.abspath(os.path.join(base_dir, *paths))
    
    if not final_path.startswith(base_dir + os.sep) and final_path != base_dir:
        raise ValueError("Path traversal attempt detected")
    
    return final_path

def create_zip_from_folder(folder_path):
    """
    Creates an in-memory zip file of a given folder and returns it.
    """
    memory_file = io.BytesIO()
    with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                # Calculate relative path to store inside zip
                arcname = os.path.relpath(file_path, folder_path)
                zf.write(file_path, arcname)
    memory_file.seek(0)
    return memory_file
