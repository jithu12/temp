import subprocess
import threading
import sys
import os
from app.socket import socketio

# Dictionary to hold active processes
# Key: session_id, Value: dict with 'process', 'type', and optionally 'fd'
active_terminals = {}

# Dictionary to hold line buffers for each session (Windows only)
input_buffers = {}

def read_and_emit_windows(process, session_id):
    """Reads stdout from the subprocess and emits it to the connected client (Windows)."""
    try:
        # Read output byte by byte to ensure real-time streaming
        while True:
            char = process.stdout.read(1)
            if not char:
                break
            
            try:
                text = char.decode('utf-8', errors='replace')
            except Exception:
                text = '?'
            
            socketio.emit('terminal_output', {'output': text}, to=session_id)
            
    except Exception as e:
        print(f"Error reading process output: {e}")
    finally:
        socketio.emit('terminal_output', {'output': '\r\n[Process terminated]\r\n'}, to=session_id)
        if session_id in active_terminals:
            del active_terminals[session_id]

def read_and_emit_pty(fd, session_id):
    """Reads output from the pty and emits it to the connected client (Linux/macOS)."""
    try:
        while True:
            try:
                char = os.read(fd, 1024)
            except OSError:
                break
            
            if not char:
                break
            
            try:
                text = char.decode('utf-8', errors='replace')
            except Exception:
                text = '?'
            
            socketio.emit('terminal_output', {'output': text}, to=session_id)
            
    except Exception as e:
        print(f"Error reading pty output: {e}")
    finally:
        socketio.emit('terminal_output', {'output': '\r\n[Process terminated]\r\n'}, to=session_id)
        if session_id in active_terminals:
            del active_terminals[session_id]

@socketio.on('connect')
def handle_connect():
    pass

@socketio.on('disconnect')
def handle_disconnect():
    from flask import request
    session_id = request.sid
    if session_id in active_terminals:
        terminal_info = active_terminals[session_id]
        process = terminal_info['process']
        process.terminate()
        if terminal_info['type'] == 'pty':
            try:
                os.close(terminal_info['fd'])
            except Exception:
                pass
        del active_terminals[session_id]
    if session_id in input_buffers:
        del input_buffers[session_id]

@socketio.on('start_terminal')
def handle_start_terminal(data):
    from flask import request
    session_id = request.sid
    
    if session_id in active_terminals:
        return
    
    if sys.platform == 'win32':
        kwargs = {}
        kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
        cmd = ['cmd.exe']
        
        try:
            process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=0,
                **kwargs
            )
            
            active_terminals[session_id] = {'process': process, 'type': 'windows'}
            input_buffers[session_id] = ""
            
            thread = threading.Thread(target=read_and_emit_windows, args=(process, session_id))
            thread.daemon = True
            thread.start()
            
        except Exception as e:
            socketio.emit('terminal_output', {'output': f'\r\nError starting terminal: {e}\r\n'}, to=session_id)
            
    else:
        import pty
        cmd = ['bash']
        
        try:
            master_fd, slave_fd = pty.openpty()
            process = subprocess.Popen(
                cmd,
                stdin=slave_fd,
                stdout=slave_fd,
                stderr=slave_fd,
                close_fds=True
            )
            os.close(slave_fd)
            
            active_terminals[session_id] = {'process': process, 'type': 'pty', 'fd': master_fd}
            
            thread = threading.Thread(target=read_and_emit_pty, args=(master_fd, session_id))
            thread.daemon = True
            thread.start()
            
        except Exception as e:
            socketio.emit('terminal_output', {'output': f'\r\nError starting terminal: {e}\r\n'}, to=session_id)

@socketio.on('terminal_input')
def handle_terminal_input(data):
    from flask import request
    session_id = request.sid
    
    if session_id in active_terminals:
        terminal_info = active_terminals[session_id]
        input_data = data.get('input', '')
        
        if terminal_info['type'] == 'windows':
            process = terminal_info['process']
            
            if session_id not in input_buffers:
                input_buffers[session_id] = ""
                
            if process.stdin:
                try:
                    # Handle Backspace
                    if input_data == '\x7f' or input_data == '\x08':
                        if len(input_buffers[session_id]) > 0:
                            input_buffers[session_id] = input_buffers[session_id][:-1]
                            socketio.emit('terminal_output', {'output': '\b \b'}, to=session_id)
                    # Handle Enter
                    elif input_data == '\r' or input_data == '\n':
                        input_buffers[session_id] += '\n'
                        socketio.emit('terminal_output', {'output': '\r\n'}, to=session_id)
                        
                        # Write the complete line to stdin and flush
                        process.stdin.write(input_buffers[session_id].encode('utf-8'))
                        process.stdin.flush()
                        
                        # Clear buffer
                        input_buffers[session_id] = ""
                    else:
                        # Ignore escape sequences (like arrows) to avoid breaking the buffer
                        if '\x1b' not in input_data:
                            input_buffers[session_id] += input_data
                            # Echo normal characters back to the terminal
                            socketio.emit('terminal_output', {'output': input_data}, to=session_id)

                except Exception as e:
                    print(f"Error writing to process stdin: {e}")
                    
        elif terminal_info['type'] == 'pty':
            fd = terminal_info['fd']
            try:
                os.write(fd, input_data.encode('utf-8'))
            except Exception as e:
                print(f"Error writing to pty: {e}")

