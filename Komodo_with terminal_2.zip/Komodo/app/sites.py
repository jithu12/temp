from flask import Blueprint, current_app, send_from_directory, abort
import os
from app.utils import safe_join

sites_bp = Blueprint('sites', __name__)

@sites_bp.route('/')
def home():
    # Optional: Serve a default platform landing page, or redirect to /admin
    # We will just redirect to admin for now
    from flask import redirect, url_for
    return redirect(url_for('auth.login'))

@sites_bp.route('/<site_name>/')
@sites_bp.route('/<site_name>/<path:filename>')
def serve_site(site_name, filename='index.html'):
    try:
        sites_dir = current_app.config['SITES_DIR']
        # Validate that the site directory itself exists
        site_path = safe_join(sites_dir, site_name)
        
        if not os.path.exists(site_path) or not os.path.isdir(site_path):
            abort(404)
            
        # Also validate that the requested file doesn't traverse out of the site directory
        # safe_join inside send_from_directory or manually here
        file_path = safe_join(site_path, filename)
        
        if not os.path.exists(file_path):
            abort(404)
            
        if os.path.isdir(file_path):
            # If it's a directory, serve its index.html
            return send_from_directory(file_path, 'index.html')
            
        # Serve the file
        # We use send_from_directory for security and correct mime types
        directory = os.path.dirname(file_path)
        name = os.path.basename(file_path)
        return send_from_directory(directory, name)
        
    except ValueError:
        # Path traversal detected
        abort(403)
