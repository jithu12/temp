from app import create_app

application = create_app()

# This is the WSGI entry point used by Gunicorn
# Command: gunicorn --bind 0.0.0.0:8000 wsgi:application
