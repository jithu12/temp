# Multi-Site Hosting Platform

A lightweight, self-hosted multi-site platform built with Python Flask.

## Features
- Secure admin panel with session login.
- Host multiple static HTML/CSS/JS websites.
- Fully manageable from the browser (no CLI required after setup).
- Browser-based File Manager: upload, create, delete, and edit files directly.
- Download complete site backups as ZIP files.
- Dark-mode UI.

## Requirements
- Python 3.8+
- Requirements listed in `requirements.txt`

## Setup Instructions

1. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Configuration**
   - The default admin password is `admin123`.
   - To change this, modify the `ADMIN_PASSWORD_HASH` in `config.py`. You can generate a new hash in a Python shell:
     ```python
     from werkzeug.security import generate_password_hash
     print(generate_password_hash('your_new_password'))
     ```

3. **Running Locally (Development)**
   ```bash
   python run.py
   ```
   Access the admin panel at `http://127.0.0.1:5000/admin`.

## Production Deployment (Gunicorn + Nginx)

1. **Run with Gunicorn**
   ```bash
   gunicorn --workers 3 --bind 127.0.0.1:8000 wsgi:application
   ```

2. **Nginx Reverse Proxy Configuration (Optional but Recommended)**
   Create a file `/etc/nginx/sites-available/multisite`:
   ```nginx
   server {
       listen 80;
       server_name yourdomain.com;

       location / {
           proxy_pass http://127.0.0.1:8000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
       }
   }
   ```
   Enable it: `sudo ln -s /etc/nginx/sites-available/multisite /etc/nginx/sites-enabled/` and `sudo systemctl restart nginx`.
