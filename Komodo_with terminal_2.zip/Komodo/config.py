import os

class Config:
    # Set a secret key for sessions
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'a-very-secret-key-change-me-in-production'
    
    # Absolute path to the sites directory
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    SITES_DIR = os.path.join(BASE_DIR, 'sites')
    
    # Hashed password for 'admin123'
    ADMIN_PASSWORD_HASH = 'scrypt:32768:8:1$iR1JjdBTOglIAtvH$36f9f5c60a7d966748a94b610ecc52856ca5dc224d5a57214bd6298a51c0ba95638751bd7a579613cab1ea6d45561107e5368b55760a8dde6d43d21a7f0067d9'
    
    # Max upload size (e.g., 50MB)
    MAX_CONTENT_LENGTH = 50 * 1024 * 1024
