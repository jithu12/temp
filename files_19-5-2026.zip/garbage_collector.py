"""
dataviz_core/services/garbage_collector.py

Automated account lifecycle management service.

Implements the account deletion lifecycle from the PPT:

    INACTIVE (grace period 5-30 days)
         ↓  [grace period expires]
    DELETING  ← LifecycleEvent.ResourceDeleting sent to Event Bus
         ↓  [24 hours later]
    DELETED   ← LifecycleEvent.ResourceDeleted sent to Event Bus
         ↓
    All workspaces deleted

Called by Celery beat every hour via run_garbage_collector task.
"""

import logging
from datetime import datetime, timezone, timedelta
from typing import List, Optional

from dataviz_core.models.shared_enums import Status
from dataviz_core.models.account_details import AccountDetails
from dataviz_core.services.filtering import FilteringCriterion
from dataviz_core.services.session import SessionManagerMixin
from dataviz_core.utils.logging import get_default_logger

# How long account stays in DELETING before moving to DELETED
DELETING_TO_DELETED_HOURS = 24

# Default grace period if not set on the account
DEFAULT_GRACE_PERIOD_DAYS = 30

# Minimum and maximum allowed grace period from PPT
MIN_GRACE_PERIOD_DAYS = 5
MAX_GRACE_PERIOD_DAYS = 30


class GarbageCollectorService(SessionManagerMixin):
    """
    Automated account lifecycle manager.

    Runs every hour via Celery beat and:

    1. Finds INACTIVE accounts whose grace period (deletion_date) has passed
       → moves them to DELETING
       → resets deletion_date to NOW + 24h for next phase
       → TODO: fires LifecycleEvent.ResourceDeleting to Event Bus

    2. Finds DELETING accounts whose deletion_date has passed (24h)
       → deletes all their workspaces
       → moves them to DELETED
       → TODO: fires LifecycleEvent.ResourceDeleted to Event Bus
    """

    def __init__(
        self,
        session_provider,
        repository_context=None,
        logger=None,
    ):
        super().__init__(
            session_provider,
            repository_context=repository_context,
        )
        self.logger = logger if logger else get_default_logger(__name__)
        self.workspace_service = None

    def set_workspace_service(self, workspace_service):
        """Inject workspace service to avoid circular dependency."""
        self.workspace_service = workspace_service

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def run(self) -> dict:
        """
        Main entry point called by Celery beat every hour.
        Returns a summary dict of what was processed.
        """
        self.logger.info("GarbageCollector: Starting run")

        grace_expired = self._process_grace_period_expired()
        deleting_completed = self._process_deleting_completed()

        summary = {
            "grace_period_expired": grace_expired,
            "deleting_completed": deleting_completed,
        }

        self.logger.info(f"GarbageCollector: Run complete — {summary}")
        return summary

    # ------------------------------------------------------------------
    # Phase 1: INACTIVE → DELETING
    # ------------------------------------------------------------------

    def _process_grace_period_expired(self) -> List[str]:
        """
        Find INACTIVE accounts whose grace period has ended
        (deletion_date <= NOW) and move them to DELETING.

        deletion_date is set when admin deactivates the account:
            deletion_date = deactivation_time + grace_period_days
        """
        self.logger.info(
            "GarbageCollector: Checking for expired grace periods"
        )

        filters = [FilteringCriterion("status", Status.INACTIVE)]
        inactive_accounts = self.repositories.account_details.list(
            filters=filters
        )

        now = datetime.now(timezone.utc)
        processed = []

        for account in inactive_accounts:
            try:
                deletion_date = self._get_aware_datetime(account.deletion_date)

                if deletion_date is None:
                    # deletion_date not set — skip this account
                    # it was probably deactivated before this system existed
                    self.logger.warning(
                        f"GarbageCollector: Account {account.owner_account_id} "
                        f"is INACTIVE but has no deletion_date set. Skipping."
                    )
                    continue

                if now >= deletion_date:
                    self.logger.info(
                        f"GarbageCollector: Account {account.owner_account_id} "
                        f"grace period expired on {deletion_date}. "
                        f"Moving to DELETING."
                    )
                    self._move_to_deleting(account)
                    processed.append(str(account.owner_account_id))
                else:
                    remaining = deletion_date - now
                    self.logger.info(
                        f"GarbageCollector: Account {account.owner_account_id} "
                        f"grace period ends in {remaining.days} day(s) "
                        f"on {deletion_date}."
                    )

            except Exception as e:
                self.logger.error(
                    f"GarbageCollector: Error processing INACTIVE account "
                    f"{account.owner_account_id}: {e}"
                )
                continue

        return processed

    def _move_to_deleting(self, account: AccountDetails) -> None:
        """
        Move account from INACTIVE to DELETING.
        Sets deletion_date = NOW + 24h for the next phase.
        TODO: Fire LifecycleEvent.ResourceDeleting to Event Bus.
        """
        try:
            now = datetime.now(timezone.utc)
            deletion_completes_at = now + timedelta(hours=DELETING_TO_DELETED_HOURS)

            with self.autocommit():
                self.repositories.account_details.update(
                    id=account.id,
                    status=Status.DELETING,
                    deletion_date=deletion_completes_at,
                )

            self.logger.info(
                f"GarbageCollector: Account {account.owner_account_id} "
                f"moved to DELETING. "
                f"Will be fully deleted at {deletion_completes_at}."
            )

            # TODO: Fire LifecycleEvent.ResourceDeleting to Event Bus
            # self.event_bus.publish(LifecycleEvent.ResourceDeleting, account)

        except Exception as e:
            self.logger.error(
                f"GarbageCollector: Failed to move account "
                f"{account.owner_account_id} to DELETING: {e}"
            )
            raise

    # ------------------------------------------------------------------
    # Phase 2: DELETING → DELETED
    # ------------------------------------------------------------------

    def _process_deleting_completed(self) -> List[str]:
        """
        Find DELETING accounts whose deletion_date has passed (24h)
        and move them to DELETED with workspace cascade.
        """
        self.logger.info(
            "GarbageCollector: Checking for accounts ready to be deleted"
        )

        filters = [FilteringCriterion("status", Status.DELETING)]
        deleting_accounts = self.repositories.account_details.list(
            filters=filters
        )

        now = datetime.now(timezone.utc)
        processed = []

        for account in deleting_accounts:
            try:
                deletion_date = self._get_aware_datetime(account.deletion_date)

                if deletion_date is None:
                    self.logger.warning(
                        f"GarbageCollector: Account {account.owner_account_id} "
                        f"is DELETING but has no deletion_date set. Skipping."
                    )
                    continue

                if now >= deletion_date:
                    self.logger.info(
                        f"GarbageCollector: Account {account.owner_account_id} "
                        f"has been DELETING since {deletion_date}. "
                        f"Moving to DELETED."
                    )
                    self._move_to_deleted(account)
                    processed.append(str(account.owner_account_id))
                else:
                    remaining = deletion_date - now
                    hours_remaining = remaining.seconds // 3600
                    self.logger.info(
                        f"GarbageCollector: Account {account.owner_account_id} "
                        f"deletion completes in {hours_remaining} hour(s) "
                        f"at {deletion_date}."
                    )

            except Exception as e:
                self.logger.error(
                    f"GarbageCollector: Error processing DELETING account "
                    f"{account.owner_account_id}: {e}"
                )
                continue

        return processed

    def _move_to_deleted(self, account: AccountDetails) -> None:
        """
        Move account from DELETING to DELETED.
        Cascades workspace deletion first.
        TODO: Fire LifecycleEvent.ResourceDeleted to Event Bus.
        """
        try:
            # Delete all workspaces first
            if self.workspace_service is not None:
                self.logger.info(
                    f"GarbageCollector: Deleting workspaces for "
                    f"account {account.owner_account_id}"
                )
                self.workspace_service.delete_workspaces_by_owner_account_id(
                    account.owner_account_id
                )
                self.logger.info(
                    f"GarbageCollector: Workspaces deleted for "
                    f"account {account.owner_account_id}"
                )
            else:
                self.logger.warning(
                    f"GarbageCollector: workspace_service not set — "
                    f"skipping workspace deletion for {account.owner_account_id}"
                )

            # Then mark account as DELETED
            with self.autocommit():
                self.repositories.account_details.update(
                    id=account.id,
                    status=Status.DELETED,
                )

            self.logger.info(
                f"GarbageCollector: Account {account.owner_account_id} "
                f"moved to DELETED."
            )

            # TODO: Fire LifecycleEvent.ResourceDeleted to Event Bus
            # self.event_bus.publish(LifecycleEvent.ResourceDeleted, account)

        except Exception as e:
            self.logger.error(
                f"GarbageCollector: Failed to move account "
                f"{account.owner_account_id} to DELETED: {e}"
            )
            raise

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _get_aware_datetime(
        dt: Optional[datetime],
    ) -> Optional[datetime]:
        """
        Make a datetime timezone-aware (UTC) if it isn't already.
        Returns None if dt is None.
        """
        if dt is None:
            return None
        if dt.tzinfo is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt

    @staticmethod
    def _validate_grace_period_days(days: int) -> int:
        """
        Clamp grace period to allowed range (5-30 days from PPT).
        Returns the clamped value.
        """
        return max(
            MIN_GRACE_PERIOD_DAYS,
            min(MAX_GRACE_PERIOD_DAYS, days)
        )

    # ------------------------------------------------------------------
    # Public helper — called by accounts.py when deactivating
    # ------------------------------------------------------------------

    def set_deletion_date_for_account(
        self,
        account: AccountDetails,
        grace_period_days: int = DEFAULT_GRACE_PERIOD_DAYS,
    ) -> None:
        """
        Set deletion_date on account when it gets deactivated.
        Called by request_account_deactivation in accounts.py.

        deletion_date = NOW + grace_period_days
        This is when the garbage collector will move it to DELETING.
        """
        grace_period_days = self._validate_grace_period_days(grace_period_days)
        now = datetime.now(timezone.utc)
        deletion_date = now + timedelta(days=grace_period_days)

        try:
            with self.autocommit():
                self.repositories.account_details.update(
                    id=account.id,
                    deletion_date=deletion_date,
                )
            self.logger.info(
                f"GarbageCollector: Set deletion_date for account "
                f"{account.owner_account_id} to {deletion_date} "
                f"({grace_period_days} day grace period)."
            )
        except Exception as e:
            self.logger.error(
                f"GarbageCollector: Failed to set deletion_date for "
                f"account {account.owner_account_id}: {e}"
            )
            raise
