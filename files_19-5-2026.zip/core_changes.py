"""
Changes to make in dataviz_core/core.py

1. Import GarbageCollectorService
2. Register it in DatavizCore.__init__
3. Wire up workspace_service injection
"""

# -----------------------------------------------------------------------
# 1. ADD THIS IMPORT at top of core.py
# -----------------------------------------------------------------------

from dataviz_core.services.garbage_collector import GarbageCollectorService


# -----------------------------------------------------------------------
# 2. ADD THIS in DatavizCore.__init__ after self.account is set up
# -----------------------------------------------------------------------

self.garbage_collector = GarbageCollectorService(
    session_provider=self.session_provider,
    repository_context=self.repository_context,
)
self.garbage_collector.set_workspace_service(self.workspace)

# Also wire garbage_collector into account service
self.account.set_garbage_collector_service(self.garbage_collector)
