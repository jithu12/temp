"""
Add these to dataviz_async/app.py

1. Add the task function after the existing tasks
2. Add the schedule to beat_schedule
"""

# -----------------------------------------------------------------------
# ADD THIS TASK after check_certificate_expiration task
# -----------------------------------------------------------------------

@app.task(name="run_garbage_collector")
def run_garbage_collector() -> None:
    """
    Automated account lifecycle task.
    Runs every hour and:
    - Moves INACTIVE accounts with expired grace period → DELETING
    - Moves DELETING accounts after 24h → DELETED + deletes workspaces
    """
    logger.info("GarbageCollector: BEGIN")
    get_core(app).garbage_collector.run()
    logger.info("GarbageCollector: DONE")


# -----------------------------------------------------------------------
# ADD THIS to app.conf.beat_schedule dict
# -----------------------------------------------------------------------

# Add inside app.conf.beat_schedule = { ... }

"run_garbage_collector_every_hour": {
    "task": "run_garbage_collector",
    "schedule": crontab(minute=0),  # runs every hour at :00
},
