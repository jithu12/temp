"""add grace_period_days to api_account_details

Revision ID: add_grace_period_days
Revises: fbb4ef4836b7
Create Date: 2026-05-19

"""
from alembic import op
import sqlalchemy as sa

revision = 'add_grace_period_days'
down_revision = 'fbb4ef4836b7'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        'api_account_details',
        sa.Column(
            'grace_period_days',
            sa.Integer(),
            nullable=False,
            server_default='30',
            comment='Grace period in days before account moves from INACTIVE to DELETING. Range 5-30 days.',
        )
    )


def downgrade():
    op.drop_column('api_account_details', 'grace_period_days')
