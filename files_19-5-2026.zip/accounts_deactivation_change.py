"""
In dataviz_core/services/accounts.py

Add garbage_collector service injection and
set deletion_date when account is deactivated.
"""

# -----------------------------------------------------------------------
# 1. Add set_garbage_collector_service method to AccountService
# -----------------------------------------------------------------------

def set_garbage_collector_service(self, garbage_collector_service):
    """Inject garbage collector service."""
    self.garbage_collector_service = garbage_collector_service


# -----------------------------------------------------------------------
# 2. In __init__ add:
# -----------------------------------------------------------------------

self.garbage_collector_service = None


# -----------------------------------------------------------------------
# 3. In request_account_deactivation, after setting UPDATE_REQUESTED
#    and BEFORE firing async job, add:
# -----------------------------------------------------------------------

# Set deletion_date so garbage collector knows when grace period ends
# Grace period = account.grace_period_days (default 30 days)
if self.garbage_collector_service is not None:
    grace_period_days = getattr(account, "grace_period_days", 30)
    self.garbage_collector_service.set_deletion_date_for_account(
        account=account,
        grace_period_days=grace_period_days,
    )
    self.logger.info(
        f"Grace period set: account {owner_account_id} will move to "
        f"DELETING in {grace_period_days} days if not reactivated."
    )
