"""
Updated AccountDetails model.
Add grace_period_days column — how many days before
account moves from INACTIVE to DELETING automatically.
Range: 5-30 days (from PPT). Default: 30 days.
"""

from dataviz_core.models.sqlalchemy import (
    Model,
    Column,
    GUID,
    ResourceModel,
    relationship,
    String,
    Integer,
)


class AccountDetails(ResourceModel, Model):
    name = Column(String(1024), nullable=True)
    owner_account_id = Column(GUID, nullable=False)
    soft_limit = Column(
        Integer,
        nullable=False,
        default=5,
    )
    # Grace period in days before account moves from INACTIVE to DELETING.
    # Set by account team. Range 5-30 days (from PPT). Default 30 days.
    # Used by GarbageCollectorService to calculate deletion_date.
    grace_period_days = Column(
        Integer,
        nullable=False,
        default=30,
    )
    workspace = relationship(
        "Workspace",
        back_populates="account_details",
        uselist=False,
    )

    def __repr__(self):
        return (
            f"<<{self.__class__.__name__} "
            f"(id: {self.id}, name: {self.name})>"
        )
