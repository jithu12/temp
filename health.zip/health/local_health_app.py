"""
local_health_app.py
====================
Standalone local integration of the /health endpoint with local Redis.

Mirrors exactly how the real dataviz health service works:

  ┌─────────────────────────────────────────────────────────────────┐
  │  Background Thread  (simulates Celery beat worker)              │
  │  → runs all health checkers every CHECKER_INTERVAL seconds      │
  │  → writes result JSON  →  Redis key: dataviz:health:result      │
  └──────────────────────────────┬──────────────────────────────────┘
                                 │  Redis  localhost:6379
  ┌──────────────────────────────▼──────────────────────────────────┐
  │  Flask  GET /health                                             │
  │  → reads pre-computed result from Redis  (like get_health())    │
  │  → returns JSON + HTTP 200/503                                  │
  └─────────────────────────────────────────────────────────────────┘

Usage:
    python local_health_app.py

Then open:
    http://localhost:5000/health
    http://localhost:5000/health/live   ← simple liveness probe

Stop with Ctrl+C, then clean up:
    docker stop redis-local && docker rm redis-local
"""

from __future__ import annotations

import json
import logging
import os
import socket
import threading
import time
from typing import Any, Dict, List, Tuple

import redis
from flask import Flask, jsonify

# ── logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s  %(name)s  %(message)s",
)
logger = logging.getLogger("local_health_app")

# ── config (mirrors _build_datastore_details() in Core/health.py) ────────────
REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = int(os.getenv("REDIS_PORT", "6379"))
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", "") or None

APP_NAME    = "dataviz"
APP_VERSION = "1.0.0"
HEALTH_KEY  = f"{APP_NAME}:health:result"   # same key the real platform_health writes
HEALTH_TTL  = 600                            # seconds the key lives in Redis
CHECKER_INTERVAL = 30                        # seconds between checker runs (real app: 180)

# ── Redis client ──────────────────────────────────────────────────────────────
def _make_redis() -> redis.Redis:
    return redis.Redis(
        host=REDIS_HOST,
        port=REDIS_PORT,
        password=REDIS_PASSWORD,
        decode_responses=True,
        socket_connect_timeout=5,
    )

# ─────────────────────────────────────────────────────────────────────────────
#  Health Checkers  (mirrors Core/health_checkers.py)
# ─────────────────────────────────────────────────────────────────────────────

class CheckResult:
    """Mirrors HZStatus: OK / DEGRADED / KO."""
    def __init__(self, name: str, status: str, message: str = "", tags: List[str] = None):
        self.name    = name
        self.status  = status          # "OK" | "DEGRADED" | "KO"
        self.message = message
        self.tags    = tags or []

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"status": self.status, "tags": self.tags}
        if self.message:
            d["message"] = self.message
        return d


def check_redis(r: redis.Redis) -> CheckResult:
    """RedisHealthChecker — verifies the datastore used by platform_health."""
    try:
        r.ping()
        return CheckResult("redis_checker", "OK", tags=["redis"])
    except Exception as exc:
        return CheckResult("redis_checker", "KO", str(exc), tags=["redis"])


def check_kube() -> CheckResult:
    """Simulates _create_kube_checker — not available locally."""
    return CheckResult(
        "kube_cp_connectivity", "SKIPPED",
        "Not available in local dev environment", tags=["kube"]
    )


def check_vault() -> CheckResult:
    """Simulates _create_vault_checker — not available locally."""
    return CheckResult(
        "myvault_connectivity", "SKIPPED",
        "Not available in local dev environment", tags=["vault"]
    )


def check_postgres() -> CheckResult:
    """Simulates _create_postgres_checker — not available locally."""
    return CheckResult(
        "postgres_connectivity", "SKIPPED",
        "Not available in local dev environment", tags=["database"]
    )


def check_celery() -> CheckResult:
    """Simulates _create_celery_checker — not available locally."""
    return CheckResult(
        "celery_connectivity", "SKIPPED",
        "Not available in local dev environment", tags=["messaging"]
    )


def check_dns() -> CheckResult:
    """Simulates _create_dns_checker using a real DNS lookup."""
    try:
        socket.gethostbyname("google.com")   # basic DNS sanity
        return CheckResult("dns_connectivity", "OK", tags=["dns", "network"])
    except Exception as exc:
        return CheckResult("dns_connectivity", "KO", str(exc), tags=["dns", "network"])


def check_pki() -> CheckResult:
    """Simulates _create_pki_checker — not available locally."""
    return CheckResult(
        "pki_connectivity", "SKIPPED",
        "Not available in local dev environment", tags=["security", "pki"]
    )


def run_all_checks(r: redis.Redis) -> List[CheckResult]:
    """Run every checker — same list as create_health_checkers() in health_checkers.py."""
    return [
        check_redis(r),
        check_kube(),
        check_vault(),
        check_postgres(),
        check_celery(),
        check_dns(),
        check_pki(),
    ]


def _overall_status(results: List[CheckResult]) -> str:
    """
    Derive overall app status from individual checker results.
    Mirrors platform_health's ParentStatus roll-up logic:
      Any KO       → DOWN
      Any DEGRADED → DEGRADED
      All OK/SKIP  → OK
    """
    statuses = {r.status for r in results}
    if "KO" in statuses:
        return "DOWN"
    if "DEGRADED" in statuses:
        return "DEGRADED"
    return "OK"


# ─────────────────────────────────────────────────────────────────────────────
#  Background worker  (mirrors register_task_to_celery / Celery beat)
# ─────────────────────────────────────────────────────────────────────────────

def _health_writer_loop() -> None:
    """
    Runs in a daemon thread.
    Every CHECKER_INTERVAL seconds:
      1. Execute all checkers
      2. Serialise results to JSON
      3. Write to Redis under HEALTH_KEY  (with TTL so stale data expires)

    This is exactly what the Celery beat task does in production.
    """
    logger.info("Health writer thread started (interval=%ds, key=%s)", CHECKER_INTERVAL, HEALTH_KEY)
    r = _make_redis()

    while True:
        try:
            results  = run_all_checks(r)
            overall  = _overall_status(results)

            payload: Dict[str, Any] = {
                "status":      overall,
                "application": APP_NAME,
                "version":     APP_VERSION,
                "environment": "local-dev",
                "timestamp":   time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "checks":      {res.name: res.to_dict() for res in results},
            }

            r.set(HEALTH_KEY, json.dumps(payload), ex=HEALTH_TTL)
            logger.info("Health result written to Redis  [status=%s]", overall)

        except redis.exceptions.ConnectionError:
            logger.error("Redis connection lost — will retry in %ds", CHECKER_INTERVAL)
        except Exception as exc:
            logger.exception("Unexpected error in health writer: %s", exc)

        time.sleep(CHECKER_INTERVAL)


# ─────────────────────────────────────────────────────────────────────────────
#  Flask app  (mirrors api/health_controller.py)
# ─────────────────────────────────────────────────────────────────────────────

app = Flask(__name__)


def _get_health_from_redis() -> Tuple[Dict[str, Any], int]:
    """
    Mirrors core.health.get_health() — reads pre-computed result from Redis.
    Returns (payload_dict, http_status_code).
    """
    try:
        r   = _make_redis()
        raw = r.get(HEALTH_KEY)

        if raw is None:
            return {
                "status":  "UNKNOWN",
                "message": "Health result not yet available in Redis. "
                           "The writer thread may still be initialising — "
                           f"retry in {CHECKER_INTERVAL}s.",
            }, 503

        payload = json.loads(raw)

        # Map overall status → HTTP code  (same logic as the real Flask controller)
        http_code = 200
        if payload.get("status") in ("DOWN", "KO"):
            http_code = 503
        elif payload.get("status") == "DEGRADED":
            http_code = 200   # degraded is still serving, return 200

        return payload, http_code

    except redis.exceptions.ConnectionError as exc:
        logger.error("Redis unreachable in /health endpoint: %s", exc)
        return {"status": "ERROR", "message": f"Redis unreachable: {exc}"}, 503
    except Exception as exc:
        logger.exception("Unexpected error in /health: %s", exc)
        return {"status": "ERROR", "message": str(exc)}, 500


@app.route("/health", methods=["GET"])
def health():
    """
    GET /health
    Mirrors api/health_controller.py → health()
    Reads pre-computed health result from Redis and returns it as JSON.
    """
    logger.info("GET /health called")
    payload, http_code = _get_health_from_redis()
    logger.info("GET /health → status=%s  http=%d", payload.get("status"), http_code)
    return jsonify(payload), http_code


@app.route("/health/live", methods=["GET"])
def health_live():
    """
    GET /health/live
    Simple liveness probe — just checks Redis is reachable.
    Returns 200 OK  or  503 if Redis is down.
    """
    try:
        r = _make_redis()
        r.ping()
        return jsonify({"status": "UP", "redis": f"{REDIS_HOST}:{REDIS_PORT}"}), 200
    except Exception as exc:
        return jsonify({"status": "DOWN", "error": str(exc)}), 503


@app.route("/health/redis", methods=["GET"])
def health_redis_raw():
    """
    GET /health/redis
    Shows the raw JSON stored in Redis exactly as the Celery beat task writes it.
    """
    try:
        r   = _make_redis()
        raw = r.get(HEALTH_KEY)
        if raw is None:
            return jsonify({"message": f"Key '{HEALTH_KEY}' not found in Redis yet."}), 404
        return app.response_class(raw, mimetype="application/json"), 200
    except Exception as exc:
        return jsonify({"error": str(exc)}), 503


# ─────────────────────────────────────────────────────────────────────────────
#  Entry point
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logger.info("=" * 60)
    logger.info("  dataviz  local /health  –  connecting to Redis %s:%d", REDIS_HOST, REDIS_PORT)
    logger.info("=" * 60)

    # Verify Redis is reachable before starting
    try:
        _make_redis().ping()
        logger.info("Redis PING OK ✓")
    except redis.exceptions.ConnectionError as exc:
        logger.error("Cannot connect to Redis at %s:%d  →  %s", REDIS_HOST, REDIS_PORT, exc)
        logger.error("Start Redis first:  docker run -d --name redis-local -p 6379:6379 redis:7-alpine")
        raise SystemExit(1)

    # Start the background health-writer thread (mirrors Celery beat worker)
    writer = threading.Thread(target=_health_writer_loop, daemon=True, name="health-writer")
    writer.start()

    logger.info("Health writer thread running every %ds", CHECKER_INTERVAL)
    logger.info("Flask starting — endpoints:")
    logger.info("  GET http://localhost:5000/health        ← full health result")
    logger.info("  GET http://localhost:5000/health/live   ← liveness probe")
    logger.info("  GET http://localhost:5000/health/redis  ← raw Redis payload")
    logger.info("Press Ctrl+C to stop.")

    app.run(host="0.0.0.0", port=5000, debug=False, use_reloader=False)
