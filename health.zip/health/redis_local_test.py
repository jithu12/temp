"""
Redis Local Test Script
========================
Tests Redis connectivity exactly as the project's health service uses it.

Environment variables used (mirrors health.py / health_checkers.py):
  REDIS_HOST     - default: localhost
  REDIS_PORT     - default: 6379
  REDIS_PASSWORD - default: "" (no auth for local dev)

Run:
    python redis_local_test.py

Or with custom host/port:
    set REDIS_HOST=localhost && set REDIS_PORT=6379 && python redis_local_test.py
"""

import os
import sys
import json
import time

# ── configuration (mirrors _build_datastore_details() in health.py) ──────────
REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = int(os.getenv("REDIS_PORT", "6379"))
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", "")

print("=" * 60)
print("  Redis Local Test  –  dataviz health service")
print("=" * 60)
print(f"  Host     : {REDIS_HOST}")
print(f"  Port     : {REDIS_PORT}")
print(f"  Password : {'(set)' if REDIS_PASSWORD else '(none)'}")
print("=" * 60)

# ── import redis ─────────────────────────────────────────────────────────────
try:
    import redis
except ImportError:
    print("\n[ERROR] redis-py is not installed.")
    print("  Fix: pip install redis")
    sys.exit(1)

# ── connect ──────────────────────────────────────────────────────────────────
print("\n[1/5] Connecting to Redis …")
try:
    r = redis.Redis(
        host=REDIS_HOST,
        port=REDIS_PORT,
        password=REDIS_PASSWORD if REDIS_PASSWORD else None,
        decode_responses=True,
        socket_connect_timeout=5,
    )
    pong = r.ping()
    print(f"      PING → {pong}  ✓")
except redis.exceptions.ConnectionError as exc:
    print(f"\n[FAIL] Cannot reach Redis at {REDIS_HOST}:{REDIS_PORT}")
    print(f"       Error: {exc}")
    print("\n  Make sure the container is running:")
    print("    docker run -d --name redis-local -p 6379:6379 redis:7-alpine")
    sys.exit(1)

# ── basic SET / GET ───────────────────────────────────────────────────────────
print("\n[2/5] SET / GET …")
r.set("dataviz:test:key", "hello-redis", ex=30)
val = r.get("dataviz:test:key")
assert val == "hello-redis", f"Expected 'hello-redis', got {val!r}"
print(f"      SET dataviz:test:key = 'hello-redis'  ✓")
print(f"      GET dataviz:test:key = '{val}'  ✓")

# ── simulate the platform_health result stored by the Celery beat task ────────
print("\n[3/5] Simulating platform_health result write (Celery beat side) …")
HEALTH_KEY = "dataviz:health:result"
fake_health_payload = {
    "status": "OK",
    "application": "dataviz",
    "version": "1.0.0",
    "checks": {
        "redis_checker":       {"status": "OK",       "tags": ["redis"]},
        "postgres_connectivity": {"status": "OK",     "tags": ["database"]},
        "kube_cp_connectivity": {"status": "OK",      "tags": ["kube"]},
        "myvault_connectivity": {"status": "OK",      "tags": ["vault"]},
        "celery_connectivity":  {"status": "OK",      "tags": ["messaging"]},
        "dns_connectivity":     {"status": "OK",      "tags": ["dns", "network"]},
        "pki_connectivity":     {"status": "OK",      "tags": ["security", "pki"]},
    },
    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
}
r.set(HEALTH_KEY, json.dumps(fake_health_payload), ex=300)
print(f"      Wrote fake health payload to '{HEALTH_KEY}'  ✓")

# ── simulate get_health() call from Flask API ─────────────────────────────────
print("\n[4/5] Simulating get_health() read (Flask API side) …")
raw = r.get(HEALTH_KEY)
assert raw is not None, "Health key missing from Redis!"
result = json.loads(raw)
print(f"      Read back key '{HEALTH_KEY}'  ✓")
print(f"      Status  : {result['status']}")
print(f"      App     : {result['application']}  v{result['version']}")
print(f"      Checks  : {list(result['checks'].keys())}")

# ── RedisHealthChecker environment variable sanity check ─────────────────────
print("\n[5/5] Environment variable check (mirrors health_checkers.py) …")
missing = []
if "REDIS_HOST" not in os.environ:
    print("      REDIS_HOST  not set → will default to 'localhost' locally ✓")
else:
    print(f"      REDIS_HOST  = {os.environ['REDIS_HOST']}  ✓")
if "REDIS_PORT" not in os.environ:
    print("      REDIS_PORT  not set → will default to 6379 locally ✓")
else:
    print(f"      REDIS_PORT  = {os.environ['REDIS_PORT']}  ✓")
if "REDIS_PASSWORD" not in os.environ:
    print("      REDIS_PASSWORD not set → no auth (fine for local dev) ✓")
else:
    print(f"      REDIS_PASSWORD set  ✓")

# ── cleanup ───────────────────────────────────────────────────────────────────
r.delete("dataviz:test:key")
r.delete(HEALTH_KEY)

print("\n" + "=" * 60)
print("  ALL TESTS PASSED  ✓  Redis is working correctly.")
print("=" * 60)
print("""
Next steps:
  • Set env vars before running your app:
      set REDIS_HOST=localhost
      set REDIS_PORT=6379
      set REDIS_PASSWORD=

  • The Celery beat worker writes health results every 180s (default).
  • The Flask API reads them with core.health.get_health().

  • Stop the local Redis container when done:
      docker stop redis-local
      docker rm   redis-local
""")
